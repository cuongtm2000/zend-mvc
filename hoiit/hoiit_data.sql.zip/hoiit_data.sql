-- phpMyAdmin SQL Dump
-- version 2.11.11.3
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Feb 12, 2012 at 10:53 AM
-- Server version: 5.0.51
-- PHP Version: 5.2.17

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `hoiit_data`
--

-- --------------------------------------------------------

--
-- Table structure for table `hoiit_cats`
--

CREATE TABLE IF NOT EXISTS `hoiit_cats` (
  `cat_id` tinyint(4) NOT NULL auto_increment,
  `cat_name` varchar(45) NOT NULL,
  `cat_sort` tinyint(2) NOT NULL,
  `parent_id` tinyint(4) NOT NULL,
  PRIMARY KEY  (`cat_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=49 ;

--
-- Dumping data for table `hoiit_cats`
--

INSERT INTO `hoiit_cats` (`cat_id`, `cat_name`, `cat_sort`, `parent_id`) VALUES
(1, 'Information office', 1, 0),
(2, 'Programming', 2, 0),
(3, 'Python', 11, 2),
(4, 'Database', 4, 0),
(5, 'Web template', 5, 0),
(6, 'Word', 1, 1),
(7, 'Excel', 2, 1),
(8, 'Power point', 3, 1),
(9, 'Access', 4, 1),
(10, 'Php', 1, 2),
(14, 'Mysql', 1, 4),
(15, 'MSSQL', 2, 4),
(16, 'Javacript', 4, 2),
(17, 'Internet tips', 5, 1),
(19, 'Ajax Jquery - Mootools', 3, 2),
(21, 'Software', 6, 0),
(22, 'Software Graphics', 1, 21),
(23, 'Software Programming', 2, 21),
(27, 'Asp.net', 3, 2),
(28, '.NET', 1, 2),
(29, 'C/C++', 2, 2),
(30, 'C#', 3, 2),
(31, 'Java', 4, 2),
(32, 'Visual Basic', 5, 2),
(33, 'XHTML/CSS', 1, 5),
(34, 'Flash', 2, 5),
(36, 'Graphics', 5, 0),
(37, 'Photoshop', 1, 36),
(38, 'Flash - Flex', 5, 2),
(40, 'CSS - XHTML - HTML 5', 3, 2),
(41, 'Zend framework', 3, 10),
(42, 'CodeIgniter framework', 1, 10),
(43, 'Kohana framework', 2, 10),
(44, 'CakePHP framework', 4, 10),
(45, 'Symfony framework', 5, 10),
(46, 'Phpbb Forum', 13, 10),
(47, 'Yii framework', 6, 10),
(48, 'Drupal', 14, 10);

-- --------------------------------------------------------

--
-- Table structure for table `hoiit_comments`
--

CREATE TABLE IF NOT EXISTS `hoiit_comments` (
  `comment_id` int(11) NOT NULL auto_increment,
  `comment_title` varchar(100) NOT NULL,
  `comment_content` varchar(500) NOT NULL,
  `comment_enable` tinyint(1) NOT NULL default '1',
  `comment_date` timestamp NOT NULL default CURRENT_TIMESTAMP,
  `hoiit_usernames_username` varchar(40) NOT NULL,
  `hoiit_posts_post_id` int(11) NOT NULL,
  PRIMARY KEY  (`comment_id`),
  KEY `fk_hoiit_comments_hoiit_usernames1` (`hoiit_usernames_username`),
  KEY `fk_hoiit_comments_hoiit_posts1` (`hoiit_posts_post_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `hoiit_comments`
--

INSERT INTO `hoiit_comments` (`comment_id`, `comment_title`, `comment_content`, `comment_enable`, `comment_date`, `hoiit_usernames_username`, `hoiit_posts_post_id`) VALUES
(1, 'sasa', 'sasassa', 1, '2012-02-03 16:31:28', 'thanhansoft', 1);

-- --------------------------------------------------------

--
-- Table structure for table `hoiit_download`
--

CREATE TABLE IF NOT EXISTS `hoiit_download` (
  `download_id` int(11) NOT NULL auto_increment,
  `create_date` timestamp NOT NULL default CURRENT_TIMESTAMP,
  `link` varchar(500) NOT NULL,
  `down_type` tinyint(1) NOT NULL default '0',
  `enable` tinyint(1) NOT NULL,
  `hoiit_posts_post_id` int(11) NOT NULL,
  PRIMARY KEY  (`download_id`),
  KEY `fk_hoiit_download_hoiit_posts1` (`hoiit_posts_post_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `hoiit_download`
--


-- --------------------------------------------------------

--
-- Table structure for table `hoiit_logs`
--

CREATE TABLE IF NOT EXISTS `hoiit_logs` (
  `log_id` int(11) NOT NULL auto_increment,
  `create_date` timestamp NOT NULL default CURRENT_TIMESTAMP,
  `detail` varchar(500) NOT NULL,
  `hoiit_usernames_username` varchar(40) NOT NULL,
  PRIMARY KEY  (`log_id`),
  KEY `fk_hoiit_logs_hoiit_usernames1` (`hoiit_usernames_username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `hoiit_logs`
--


-- --------------------------------------------------------

--
-- Table structure for table `hoiit_nationals`
--

CREATE TABLE IF NOT EXISTS `hoiit_nationals` (
  `national_id` varchar(3) NOT NULL,
  `national_name` varchar(45) NOT NULL,
  PRIMARY KEY  (`national_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `hoiit_nationals`
--

INSERT INTO `hoiit_nationals` (`national_id`, `national_name`) VALUES
('VND', 'Việt Nam');

-- --------------------------------------------------------

--
-- Table structure for table `hoiit_posts`
--

CREATE TABLE IF NOT EXISTS `hoiit_posts` (
  `post_id` int(11) NOT NULL auto_increment,
  `post_title` varchar(100) NOT NULL,
  `post_img` varchar(60) default NULL,
  `post_detail` text NOT NULL,
  `post_sort` int(11) NOT NULL default '1',
  `post_demo` varchar(45) default NULL,
  `post_hit` varchar(45) NOT NULL default '0',
  `post_type` tinyint(1) NOT NULL default '0',
  `post_link` varchar(100) NOT NULL,
  `post_description` varchar(250) default NULL,
  `post_enable` tinyint(1) NOT NULL default '1',
  `post_create` timestamp NOT NULL default CURRENT_TIMESTAMP,
  `hoiit_cats_cat_id` tinyint(4) NOT NULL,
  `hoiit_usernames_username` varchar(40) NOT NULL,
  PRIMARY KEY  (`post_id`),
  KEY `fk_hoiit_posts_hoiit_cats1` (`hoiit_cats_cat_id`),
  KEY `fk_hoiit_posts_hoiit_usernames1` (`hoiit_usernames_username`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `hoiit_posts`
--

INSERT INTO `hoiit_posts` (`post_id`, `post_title`, `post_img`, `post_detail`, `post_sort`, `post_demo`, `post_hit`, `post_type`, `post_link`, `post_description`, `post_enable`, `post_create`, `hoiit_cats_cat_id`, `hoiit_usernames_username`) VALUES
(1, 'Working with request $_GET, $_POST with Yii framework', '', '<p>\r\n	You can work with request data directly using PHP superglobals such as $_SERVER, $_GET, or $_POST but the better way is to use Yii powerful CHttpRequest class that resolves inconsistencies among different web servers, manages cookies, provides some additional security, and has a nice set of OO methods.</p>\r\n<p>\r\n	You can access the request component in your web application by using Yii::app()-&gt;getRequest(). So, let''s review the most useful methods and their usage, methods that return different parts of the current URL. In the following table, returned parts are marked with a bold font.</p>\r\n<p>\r\n	getUrl http://cookbook.local<strong>/test/index?var=val</strong><br />\r\n	getHostInfo <strong>http://cookbook.local/</strong>test/index?var=val<br />\r\n	getPathInfo http://cookbook.local/<strong>test/index</strong>?var=val<br />\r\n	getRequestUri http://cookbook.local<strong>/test/index?var=val</strong><br />\r\n	getQueryString http://cookbook.local/test/index?<strong>var=val</strong></p>\r\n\r\n<p>\r\n	While PHP provides superglobals for both POST and GET, Yii way allows us to omit some additional checks:</p>\r\n<pre class="brush:php;">\r\nclass TestController extends CController\r\n{\r\n   public function actionIndex()\r\n   {\r\n      $request = Yii::app()-&gt;request;\r\n      $param = $request-&gt;getParam(''id'', 1);\r\n      // equals to\r\n      $param = isset($_REQUEST[''id'']) ? $_REQUEST[''id''] : 1;\r\n      $param = $request-&gt;getQuery(''id'');\r\n      // equals to\r\n      $param = isset($_GET[''id'']) ? $_GET[''id''] : null;\r\n      $param = $request-&gt;getPost(''id'', 1);\r\n      // equals to\r\n      $param = isset($_POST[''id'']) ? $_POST[''id''] : 1;\r\n   }\r\n}</pre>\r\n<p>\r\n	Enjoy</p>', 1, '', '68', 0, 'working-with-request-get-post-with-yii-framework', 'You can work with request data directly using PHP superglobals such as $_SERVER, $_GET, or $_POST but the better way is to use Yii powerful CHttpRequest class that resolves inconsistencies among different web servers, manages cookies', 1, '2012-02-03 13:26:46', 47, 'thanhansoft'),
(2, 'So sánh thời gian trong form với Yii - date field validation', '', '<p>\n	Chào tất cả thành viên</p>\n<p>\n	Đôi khi chúng sẽ làm ví dụ này trong trường hợp người dùng nhập vào "ngày bắt đầu, ngày kết thúc" nhưng vô tình hay cố ý họ sẽ nhập ngày kết thúc nhỏ hơn ngày bắt đầu. Vậy ứng dụng của chúng ta cần kiểm tra vấn đề này là so sánh giữa 2 ngày này, nếu ngày kết thúc nhỏ hơn sẽ xuất hiện thông báo. Cách làm như sau:</p>\n<p>\n	<strong>Bươc 1</strong>: Thêm 2 dòng này vào function rules:</p>\n<pre class="brush:php;">\npublic function rules(){\n// NOTE: you should only define rules for those attributes that\n// will receive user inputs.\nreturn array(\n  array(''start_date, end_date'', ''safe''),\n  array(''start_date, end_date'', ''type'', ''type'' =&gt; ''date'', ''message'' =&gt; ''{attribute}: is not a date!'', ''dateFormat'' =&gt; ''dd-MM-yyyy''),\n  array(''start_date'', ''compareDateRange'', ''type'' =&gt; ''date'', ''message'' =&gt; ''{attribute}: is not a date!'', ''dateFormat'' =&gt; ''dd-MM-yyyy''),\n);\n}</pre>\n<p>\n	<strong>Bước 2</strong>: Ta sẽ thêm 1 function vào <strong>bên dưới function rules</strong> như sau:</p>\n<pre class="brush:php;">\npublic function compareDateRange($attribute, $params) {\n  if(!empty($this-&gt;attributes[''start_date''])) {\n   if(strtotime($this-&gt;attributes[''end_date'']) &lt; strtotime($this-&gt;attributes[''start_date''])) {\n    $this-&gt;addError($attribute, ''The expired date can not be less/before posted date.'');\n   }\n  }\n\n}</pre>\n<p>\n	Ví dụ này 2 trường (field) trong CSDL mình dùng kiểu <strong>timestamp</strong></p>\n<p>\n	Hãy xem và test nhé, Chúc thành công</p>', 2, '', '60', 0, 'so-sanh-thoi-gian-trong-form-voi-yii-date-field-validation', 'Đôi khi chúng sẽ làm ví dụ này trong trường hợp người dùng nhập vào "ngày bắt đầu, ngày kết thúc" nhưng vô tình hay cố ý họ sẽ nhập ngày kết thúc nhỏ hơn ngày bắt đầu. Vậy ứng dụng của chúng ta cần kiểm tra vấn đề này là so sánh giữa 2 ngày này', 1, '2012-02-03 17:17:23', 47, 'thanhansoft'),
(3, '20 tuyệt chiêu thần chưởng hữu ích dành cho CSS Stylesheet', '', '<p>\n	Sau đây là vài mẹo và thủ thuật CSS mà thanhansoft nghĩ rằng tất cả các nhà phát triển web cần phải nhận thức. Bạn đã có thể biết nhiều người trong những thủ thuật. Tài liệu được lấy từ các nguồn khác nhau trên internet biên dịch dành cho người Việt</p>\n<p>\n	<strong>1. Tròn góc mà không có hình ảnh</strong><br />\n	Đây là một kỹ thuật đơn giản CSS làm tròn số các góc của Bảo hiểm tiền gửi bằng cách sử dụng một số thuộc tính css. Kỹ thuật này sẽ làm việc trong Firefox, Safari, Chrome và các trình duyệt tương thích khác CSS3. Kỹ thuật này sẽ không làm việc trong Internet Explorer.</p>\n<pre class="brush:css;">\ndiv{\n    -moz-border-radius: 10px;\n    -webkit-border-radius: 10px;\n    border-radius: 10px;\n    border: 1px solid #FF8855;\n}</pre>\n<p>\n	Ví dụ này chỉ bo góc bên trên, bên trái hoặc bên phải và dưới:</p>\n<pre class="brush:css;">\ndiv{\n    -moz-border-radius-topleft: 10px;\n    -webkit-border-top-left-radius: 10px;\n    border: 1px solid #FF8855;\n}</pre>\n<p>\n	<strong>Demo</strong>: <a href="http://www.viralpatel.net/blogs/demo/css-rounded-corner-div-table/">http://www.viralpatel.net/blogs/demo/css-rounded-corner-div-table/</a></p>\n<p>\n	<strong>2. Cú pháp CSS chỉ dùng cho IE</strong><br />\n	Sẽ có lúc bạn thấy IE hiển thị khác với các trình duyệt khác khi đó bạn cần tạo một mẫu riêng biệt hoàn toàn và đưa nó vào trong trang web bất cứ khi nào khách hàng đang sử dụng Internet Explorer.</p>\n<pre class="brush:xml;">\n&lt;!--[if IE]&gt;\n    &lt;link rel="stylesheet" type="text/css" href="ie-only.css" /&gt;\n&lt;![endif]--&gt;</pre>\n<p>\n	<strong>Dùng trong IE 7</strong></p>\n<pre class="brush:xml;">\n&lt;!--[if IE 7]&gt;\n    &lt;link href="IE-7-SPECIFIC.css" rel="stylesheet" type="text/css"&gt;\n&lt;![endif]--&gt;\n</pre>\n<p>\n	Xem thêm: <a href="http://viralpatel.net/blogs/2009/09/how-to-create-ie-specific-css-stylesheet.html">http://viralpatel.net/blogs/2009/09/how-to-create-ie-specific-css-stylesheet.html</a></p>\n<p>\n	<strong>3. Background cho textbox</strong><br />\n	Đôi lúc bạn sẽ cần đến chiêu này, hình nền được làm hình nền cho input có thể dùng ô tìm kiếm với khung tròn. Đơn giản chỉ cần sử dụng mẫu sau để thêm hình nền cho bất kỳ hộp nhập liệu.</p>\n<pre class="brush:css;">\ninput#sometextbox {\n    background-image:url(''back-image.gif'');\n    background-repeat:no-repeat;\n    padding-left:20px;\n}</pre>\n<p>\n	<strong>4. Cấu hình kích thước cho khung</strong><br />\n	Một lệnh rất tiện dụng CSS mà tồn tại là lệnh min-width, min-height, nhờ đó mà bạn có thể chỉ định chiều rộng tối thiểu cho các phần tử bất kỳ. Điều này có thể đặc biệt hữu ích để xác định chiều rộng tối thiểu cho một trang.</p>\n<pre class="brush:xml;">\n#container {\n    min-width: 600px;\n    width:expression(document.body.clientWidth &lt; 600? "600px": "auto" );\n}\n&lt;div id="container"&gt;\nDoan van cua ban\n&lt;/div&gt;</pre>\n<p>\n	Câu lệnh 2 dành cho IE mới hiểu được, các bạn hãy lưu ý</p>\n<p>\n	<strong>5. Mờ đục phần tử</strong><br />\n	Sử dụng mẫu sau để thực hiện một transperant phần tử bằng cách thiết lập mức độ đục.</p>\n<pre class="brush:css;">\n.transparent_class {\n    filter:alpha(opacity=50);\n    -moz-opacity:0.5;\n    -khtml-opacity: 0.5;\n    opacity: 0.5;\n}</pre>\n<p>\n	<strong>6. Thanh cuộn trong Firefox</strong><br />\n	Khi nội dung trang web của bạn không nhiều thì firefox sẽ không xuất hiện thanh cuộn, rất khác với IE, nhưng nếu bạn muốn hiển thị thanh cuộn đó khi nội dung ít bạn có thể dùng code dưới đây</p>\n<pre class="brush:css;">\n&lt;style type="text/css"&gt;\n        html{ overflow-y:scroll; }\n&lt;/style&gt;</pre>\n<p>\n	<strong>7. Quay text sử dụng CSS</strong><br />\n	Ví dụ dưới đây sẽ quay hình ảnh Grouplaptrinh ngược chiều kim đồng hồ 90 độ, đối với IE giá trị có thể là 0, 1, 2 hoặc 3, tương ứng 0, 90, 180 và 270</p>\n<pre class="brush:xml;">\n&lt;!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd"&gt;\n&lt;html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en"&gt;\n\n&lt;head&gt;\n&lt;meta http-equiv="content-type" content="text/html; charset=iso-8859-1" /&gt;\n&lt;meta name="author" content="Thanhansoft" /&gt;\n\n&lt;title&gt;Untitled 1&lt;/title&gt;\n    &lt;style type="text/css"&gt;\n    .rotate-style {\n        /* Safari */\n        -webkit-transform: rotate(-90deg);\n        /* Firefox */\n        -moz-transform: rotate(-90deg);\n        /* Internet Explorer */\n        filter: progid:DXImageTransform.Microsoft.BasicImage(rotation=3);\n    }\n    &lt;/style&gt;\n&lt;/head&gt;\n\n&lt;body&gt;\n\n&lt;img class="rotate-style" src="http://grouplaptrinh.com/template/adsense/images/logo.png" alt="" /&gt;\n\n&lt;/body&gt;\n&lt;/html&gt;</pre>\n<p>\n	<strong>8. Css dành cho thiết bị di động, điện thoai...</strong><br />\n	Một tài liệu CSS riêng biệt có thể được tạo ra cho PDA và điện thoại di động, và chỉ kích hoạt khi một trong những thiết bị này đang được sử dụng để truy cập vào trang web của bạn. Ngày càng có nhiều trang web đang tạo ra văn bản riêng CSS để in, vì vậy các trang web sẽ tự động trở thành in-thân thiện khi người dùng chọn để in chúng. Bạn cũng có thể làm tương tự cho các thiết bị cầm tay.<br />\n	Các lệnh sau đây được sử dụng để gọi đến các tài liệu CSS cho thiết bị cầm tay:</p>\n<pre class="brush:xml;">\n&lt;link type="text/css" rel="stylesheet" href="style.css" media="handheld" /&gt;</pre>\n<p>\n	<strong>9. Thay đổi màu nền khi bôi đen text</strong><br />\n	Chắc hẳn bạn vẫn hay bôi đen 1 đoạn text để copy nó sẽ có màu nên xanh, nhưng bạn có thể thay đổi nó đấy.</p>\n<pre class="brush:css;">\n/* Mozilla based browsers */\n::-moz-selection {\n       background-color: #FFA;\n       color: #000;\n}\n\n/* Works in Safari */\n::selection {\n       background-color: #FFA;\n       color: #000;\n}</pre>\n<p>\n	<strong>10. Bỏ các dấu chấm khi click vào link (liên kết)</strong><br />\n	Chấm biên giới xung quanh liên kết được một tính năng trình duyệt có khả năng tiếp cận nhất theo mặc định. Đó là cho những người dùng hay phải lựa chọn để điều hướng bằng bàn phím. Có một số người yêu cầu thanhansoft bỏ nó đi, tuy bực mình nhưng cũng giúp mình hoàn thiện, hãy để ý vụ này nhé. khó hình dung đấy</p>\n<pre class="brush:css;">\na:active {\n    outline: none;\n}</pre>\n<p>\n	<strong>11. Canh giữa màn hình website</strong><br />\n	Da phần các website có chiều rộng cố định thường dùng kỹ thuật canh giữa màn hình</p>\n<pre class="brush:css;">\n#page-wrap {\n     width: 800px;\n     margin: 0 auto;\n}\n&lt;body&gt;\n  &lt;div id="page-wrap"&gt;\n    &lt;!-- all websites HTML here --&gt;\n  &lt;/div&gt;\n&lt;/body&gt;</pre>\n<p>\n	<strong>12. CSS Drop Caps</strong><br />\n	Ký tự đầu sẽ to tổ bố so với các ký tự khác, code dưới đây bạn có thể tùy chỉnh lại font-size, width (chiều ngang) cho đúng với yêu cầu của bạn Demo: </p>\n<pre class="brush:css;">\np:first-letter {\n       font-size : 300%;\n       font-weight : bold;\n       float : left;\n       width : 1em;\n}</pre>\n<p>\n	Enjoy</p>', 3, '', '21', 0, '20-tuyet-chieu-than-chuong-huu-ich-danh-cho-css-stylesheet', '20 tuyệt chiêu hữu ích dành cho Css coder: Tròn góc mà không có hình ảnh, Cú pháp CSS chỉ dùng cho IE, Background cho textbox, Cấu hình kích thước cho khung, Mờ đục phần tử, Thanh cuộn trong Firefox, Quay text sử dụng CSS', 1, '2012-02-07 21:27:46', 40, 'thanhansoft');

-- --------------------------------------------------------

--
-- Table structure for table `hoiit_provinces`
--

CREATE TABLE IF NOT EXISTS `hoiit_provinces` (
  `province_id` int(11) NOT NULL auto_increment,
  `province_name` varchar(45) NOT NULL,
  `hoiit_nationals_national_id` varchar(3) NOT NULL,
  PRIMARY KEY  (`province_id`),
  KEY `fk_hoiit_provinces_hoiit_nationals` (`hoiit_nationals_national_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=64 ;

--
-- Dumping data for table `hoiit_provinces`
--

INSERT INTO `hoiit_provinces` (`province_id`, `province_name`, `hoiit_nationals_national_id`) VALUES
(1, 'An Giang', 'VND'),
(2, 'Bà rịa - Vũng tàu', 'VND'),
(3, 'Bạc Liêu', 'VND'),
(4, 'Bắc Cạn', 'VND'),
(5, 'Bắc Giang', 'VND'),
(6, 'Bắc Ninh', 'VND'),
(7, 'Bến Tre', 'VND'),
(8, 'Bình Dương', 'VND'),
(9, 'Bình Định', 'VND'),
(10, 'Bình Phước', 'VND'),
(11, 'Bình Thuận', 'VND'),
(12, 'Cà Mau', 'VND'),
(13, 'Cao Bằng', 'VND'),
(14, 'Cần Thơ', 'VND'),
(15, 'Đà  Nẵng', 'VND'),
(16, 'Đăk Lăk', 'VND'),
(17, 'Đắk Nông', 'VND'),
(18, 'Điện Biên', 'VND'),
(19, 'Đồng Nai', 'VND'),
(20, 'Đồng Tháp', 'VND'),
(21, 'Gia Lai', 'VND'),
(22, 'Hà Giang', 'VND'),
(23, 'Hà Nam', 'VND'),
(24, 'Hà Nội', 'VND'),
(25, 'Hà Tĩnh', 'VND'),
(26, 'Hải Dương', 'VND'),
(27, 'Hải Phòng', 'VND'),
(28, 'Hậu Giang', 'VND'),
(29, 'Hòa Bình', 'VND'),
(30, 'Thành phố Hồ Chí Minh', 'VND'),
(31, 'Hưng Yên', 'VND'),
(32, 'Khánh Hoà', 'VND'),
(33, 'Kiên Giang', 'VND'),
(34, 'Kon Tum', 'VND'),
(35, 'Lai Châu', 'VND'),
(36, 'Lạng Sơn', 'VND'),
(37, 'Lào Cai', 'VND'),
(38, 'Lâm Đồng', 'VND'),
(39, 'Long An', 'VND'),
(40, 'Nam Định', 'VND'),
(41, 'Nghệ An', 'VND'),
(42, 'Ninh Bình', 'VND'),
(43, 'Ninh Thuận', 'VND'),
(44, 'Phú Thọ', 'VND'),
(45, 'Phú Yên', 'VND'),
(46, 'Quảng Bình', 'VND'),
(47, 'Quảng Nam', 'VND'),
(48, 'Quảng Ngãi', 'VND'),
(49, 'Quảng Ninh', 'VND'),
(50, 'Quảng Trị', 'VND'),
(51, 'Sóc Trăng', 'VND'),
(52, 'Sơn La', 'VND'),
(53, 'Tây Ninh', 'VND'),
(54, 'Thái Bình', 'VND'),
(55, 'Thái Nguyên', 'VND'),
(56, 'Thanh Hoá', 'VND'),
(57, 'Thừa Thiên-Huế', 'VND'),
(58, 'Tiền Giang', 'VND'),
(59, 'Trà Vinh', 'VND'),
(60, 'Tuyên Quang', 'VND'),
(61, 'Vĩnh Long', 'VND'),
(62, 'Vĩnh Phúc', 'VND'),
(63, 'Yên Bái', 'VND');

-- --------------------------------------------------------

--
-- Table structure for table `hoiit_templates`
--

CREATE TABLE IF NOT EXISTS `hoiit_templates` (
  `template_id` varchar(6) NOT NULL,
  `template_name` varchar(45) NOT NULL,
  PRIMARY KEY  (`template_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `hoiit_templates`
--

INSERT INTO `hoiit_templates` (`template_id`, `template_name`) VALUES
('111111', '111111');

-- --------------------------------------------------------

--
-- Table structure for table `hoiit_usernames`
--

CREATE TABLE IF NOT EXISTS `hoiit_usernames` (
  `username` varchar(40) NOT NULL,
  `email` varchar(45) NOT NULL,
  `password` varchar(45) NOT NULL,
  `picture` varchar(60) default NULL,
  `detail` varchar(1000) default NULL,
  `phone` varchar(45) default NULL,
  `yahoo` varchar(45) default NULL,
  `skype` varchar(45) default NULL,
  `parent` varchar(40) default NULL,
  `group_code` varchar(45) NOT NULL,
  `reg_date` timestamp NOT NULL default CURRENT_TIMESTAMP,
  `user_role` varchar(45) NOT NULL,
  `code` varchar(15) default NULL,
  `enable` tinyint(1) NOT NULL,
  `hoiit_templates_template_id` varchar(6) NOT NULL,
  `hoiit_provinces_province_id` int(11) NOT NULL,
  PRIMARY KEY  (`username`),
  KEY `fk_hoiit_usernames_hoiit_templates1` (`hoiit_templates_template_id`),
  KEY `fk_hoiit_usernames_hoiit_provinces1` (`hoiit_provinces_province_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `hoiit_usernames`
--

INSERT INTO `hoiit_usernames` (`username`, `email`, `password`, `picture`, `detail`, `phone`, `yahoo`, `skype`, `parent`, `group_code`, `reg_date`, `user_role`, `code`, `enable`, `hoiit_templates_template_id`, `hoiit_provinces_province_id`) VALUES
('groupitsoft', 'groupitsoft@gmail.com', 'd98ce8d5776d4d1e601c781ab2ccee83', '', '', '01203171510', 'groupitsoft', '', '', 'Ajax Jquery - Mootools', '2012-02-06 08:35:04', 'user', NULL, 1, '111111', 19),
('khangninh', 'khangninh2005@yahoo.com', 'a1332da0ad957b5d5d7ecd182f85811a', 'khangninh.JPG', '', '0938114648', 'khangninh2005', 'khangninh2005', '', 'Php', '2012-02-03 21:30:51', 'user', NULL, 1, '111111', 19),
('thanhansoft', 'thanhansoft@gmail.com', 'e10adc3949ba59abbe56e057f20f883e', '', '', '', '', '', '', 'Php', '2012-02-02 15:50:15', 'user', NULL, 1, '111111', 19);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `hoiit_comments`
--
ALTER TABLE `hoiit_comments`
  ADD CONSTRAINT `fk_hoiit_comments_hoiit_posts1` FOREIGN KEY (`hoiit_posts_post_id`) REFERENCES `hoiit_posts` (`post_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_hoiit_comments_hoiit_usernames1` FOREIGN KEY (`hoiit_usernames_username`) REFERENCES `hoiit_usernames` (`username`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `hoiit_download`
--
ALTER TABLE `hoiit_download`
  ADD CONSTRAINT `fk_hoiit_download_hoiit_posts1` FOREIGN KEY (`hoiit_posts_post_id`) REFERENCES `hoiit_posts` (`post_id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `hoiit_logs`
--
ALTER TABLE `hoiit_logs`
  ADD CONSTRAINT `fk_hoiit_logs_hoiit_usernames1` FOREIGN KEY (`hoiit_usernames_username`) REFERENCES `hoiit_usernames` (`username`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `hoiit_posts`
--
ALTER TABLE `hoiit_posts`
  ADD CONSTRAINT `fk_hoiit_posts_hoiit_cats1` FOREIGN KEY (`hoiit_cats_cat_id`) REFERENCES `hoiit_cats` (`cat_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_hoiit_posts_hoiit_usernames1` FOREIGN KEY (`hoiit_usernames_username`) REFERENCES `hoiit_usernames` (`username`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `hoiit_provinces`
--
ALTER TABLE `hoiit_provinces`
  ADD CONSTRAINT `fk_hoiit_provinces_hoiit_nationals` FOREIGN KEY (`hoiit_nationals_national_id`) REFERENCES `hoiit_nationals` (`national_id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `hoiit_usernames`
--
ALTER TABLE `hoiit_usernames`
  ADD CONSTRAINT `fk_hoiit_usernames_hoiit_provinces1` FOREIGN KEY (`hoiit_provinces_province_id`) REFERENCES `hoiit_provinces` (`province_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_hoiit_usernames_hoiit_templates1` FOREIGN KEY (`hoiit_templates_template_id`) REFERENCES `hoiit_templates` (`template_id`) ON DELETE NO ACTION ON UPDATE NO ACTION;
