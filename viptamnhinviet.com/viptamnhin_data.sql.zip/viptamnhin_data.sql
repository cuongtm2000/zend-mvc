-- phpMyAdmin SQL Dump
-- version 2.11.11.3
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Nov 22, 2011 at 06:53 AM
-- Server version: 5.0.51
-- PHP Version: 5.2.17

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `viptamnhin_data`
--

-- --------------------------------------------------------

--
-- Table structure for table `dos_module_about`
--

CREATE TABLE IF NOT EXISTS `dos_module_about` (
  `record_id` int(11) NOT NULL auto_increment,
  `title` varchar(45) default NULL,
  `titleen` varchar(45) default NULL,
  `titlefr` varchar(45) default NULL,
  `content` text,
  `contenten` text,
  `contentfr` text,
  `hits` int(11) default '1',
  `posted_date` timestamp NULL default CURRENT_TIMESTAMP,
  `record_order` int(11) default '1',
  `extra_field1` varchar(45) default NULL,
  `extra_field2` varchar(45) default NULL,
  `hot` tinyint(1) NOT NULL default '0',
  `enable` tinyint(1) default '1',
  PRIMARY KEY  (`record_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=31 ;

--
-- Dumping data for table `dos_module_about`
--

INSERT INTO `dos_module_about` (`record_id`, `title`, `titleen`, `titlefr`, `content`, `contenten`, `contentfr`, `hits`, `posted_date`, `record_order`, `extra_field1`, `extra_field2`, `hot`, `enable`) VALUES
(30, 'Gioi thieu Viptamnhinviet', '', '', '&lt;p style=&quot;text-align:justify;&quot;&gt;\n	     &lt;span style=&quot;font-size:20px;&quot;&gt;&lt;strong&gt; CÔNG TY CỔ PHẦN TM- DV VIP TẦM NHÌN VIỆT&lt;/strong&gt;&lt;/span&gt;&lt;br /&gt;\n	    &lt;strong&gt;   &lt;span style=&quot;font-size:18px;&quot;&gt;T&lt;span style=&quot;font-size:14px;&quot;&gt;rụ sở: Lô L4, KP1, P. Bửu Long, Biên Hòa, Đồng Nai&lt;br /&gt;\n	       Điện thoại:&lt;br /&gt;\n	       Website: www.viptamnhinviet.com&lt;br /&gt;\n	       Email: viptamnhinviet@gmail.com&lt;/span&gt;&lt;/span&gt;&lt;/strong&gt;&lt;br /&gt;&lt;strong&gt;VIP TẦM NHÌN VIỆT&lt;/strong&gt;&lt;span style=&quot;font-size:12px;&quot;&gt; &lt;span style=&quot;font-size:14px;&quot;&gt;là một công ty truyền thông hoạt trong nhiều lĩnh vực như: Thiết kế website, quảng cáo doanh nghiệp, marketting online, đào tạo kỹ năng mềm, tổ chức sự kiện……. Công Ty được thành lập với sứ mệnh kết nối cộng đồng, làm giàu tri thức, kiến thức và tài chánh cho tất cả mọi người.&lt;br /&gt;\n	Nắm bắt được xu hướng Marketting Online toàn cầu công ty chúng tôi đã và đang nổ lực hết mình để trở thành một trong những tập đoàn lớn mạnh về Marketting Online tại Việt Nam phát triển bền vững gắn liền với nhiệm vụ kết nối cộng đồng.&lt;/span&gt;&lt;/span&gt;&lt;/p&gt;\n&lt;p style=&quot;text-align:justify;&quot;&gt;\n	&lt;span style=&quot;font-size:14px;&quot;&gt;&lt;strong&gt;&lt;span style=&quot;color:rgb(255,0,0);&quot;&gt;1/ Giới thiệu về dự án&lt;/span&gt; VIP TẦM NHÌN VIỆT:&lt;/strong&gt;&lt;/span&gt;&lt;br /&gt;\n	   &lt;span style=&quot;font-size:14px;&quot;&gt;Chúng tôi hoạt động với sứ mệnh “ Kết nối cộng đồng – nâng tầm cuộc sống”. &lt;strong&gt;VIP TẦM NHÌN VIỆT&lt;/strong&gt; là một trong những Công Ty tiên phong đưa ngành TMĐT phát triển lên một tầm cao mới với xu hướng kinh doanh  rõ ràng cụ thể. &lt;strong&gt;VIP TẦM NHÌN VIỆT&lt;/strong&gt; tập hợp được một đội ngũ điều hành xuất sắc, một tầm nhìn chiến lược quốc tế và đặc biêt kế hoạch trả thưởng đột phá hứa hẹn một tương lai bền vững, một cuộc sống đầy thịnh vượng dành cho tất cả mọi Thành Viên tham gia.&lt;/span&gt;&lt;/p&gt;\n&lt;p style=&quot;text-align:justify;&quot;&gt;\n	&lt;span style=&quot;font-size:14px;&quot;&gt;&lt;span style=&quot;color:rgb(255,0,0);&quot;&gt;&lt;strong&gt;2/ Công ty mang lại cho bạn điều gì?&lt;/strong&gt;&lt;/span&gt;&lt;/span&gt;&lt;br /&gt;\n	 &lt;span style=&quot;font-size:14px;&quot;&gt;   Một sân chơi công bằng và mang tính cộng đồng cao sẽ giúp bạn chinh phục đỉnh cao danh hiệu&lt;br /&gt;\n	Những dịch vụ tốt với  những dòng sản phẩm chất lượng cao.&lt;br /&gt;\n	    Một cơ hội làm việc với mức thu nhập cao không giới hạn và ổn định.&lt;/span&gt;&lt;/p&gt;\n&lt;p style=&quot;text-align:justify;&quot;&gt;\n	&lt;span style=&quot;font-size:14px;&quot;&gt;&lt;span style=&quot;color:rgb(255,0,0);&quot;&gt;&lt;strong&gt;3/ Tại sao phải chọn VIP TẦM NHÌN VIỆT&lt;/strong&gt;&lt;/span&gt;&lt;/span&gt;&lt;br /&gt;\n	   &lt;span style=&quot;font-size:14px;&quot;&gt; Chúng tôi tự hào vì đã  tạo ra một sân chơi an toàn và công bằng cho tất cả mọi người .&lt;br /&gt;\n	Kế hoạch trả thưởng cao và tiến bộ.&lt;br /&gt;\n	    Ngoài việc bạn có thể lãnh những khoản hoa hồng cao, bạn còn có những phần thưởng kèm theo rất có giá trị, nhưng trên hết bạn sẽ có được sức khỏe tốt với những dòng sản phẩm mà chúng tôi mang đến cho bạn .&lt;br /&gt;\n	    Là một môi trường năng động để bạn giao lưu học hỏi kinh nghiệm và hoàn thiện bản thân.&lt;/span&gt;&lt;/p&gt;\n&lt;p style=&quot;text-align:justify;&quot;&gt;\n	 &lt;/p&gt;\n&lt;p style=&quot;text-align:justify;&quot;&gt;\n	&lt;span style=&quot;font-size:14px;&quot;&gt;&lt;strong&gt;TẦM NHÌN - CHIẾN LƯỢC - MỤC TIÊU&lt;/strong&gt;&lt;/span&gt;&lt;/p&gt;\n&lt;p style=&quot;text-align:justify;&quot;&gt;\n	&lt;span style=&quot;font-size:14px;&quot;&gt;&lt;strong&gt; &lt;/strong&gt;&lt;/span&gt;&lt;span style=&quot;font-size:14px;&quot;&gt;• Xây dựng Website và gian hàng trực tuyến cho các doanh nghiệp.&lt;/span&gt;&lt;/p&gt;\n&lt;p style=&quot;text-align:justify;&quot;&gt;\n	&lt;span style=&quot;font-size:14px;&quot;&gt; • Xây dựng kênh bán lẻ sản phẩm &amp;amp; dịch vụ trực tuyến hàng đầu.&lt;/span&gt;&lt;/p&gt;\n&lt;p style=&quot;text-align:justify;&quot;&gt;\n	&lt;span style=&quot;font-size:14px;&quot;&gt; • Cung cấp các Giải Pháp Đầu Tư &amp;amp; Thương Mại Hóa Toàn Cầu.&lt;/span&gt;&lt;/p&gt;\n&lt;p style=&quot;text-align:justify;&quot;&gt;\n	&lt;span style=&quot;font-size:14px;&quot;&gt; • Kết nối cộng đồng gắn với các hoạt động xã hội.&lt;/span&gt;&lt;/p&gt;\n&lt;p style=&quot;text-align:justify;&quot;&gt;\n	&lt;span style=&quot;font-size:14px;&quot;&gt; • Là tổ chức hàng đầu về ứng dụng TMĐT vào nhiều lĩnh vực như kinh tế, giáo dục, văn hóa, xã hội.&lt;/span&gt;&lt;/p&gt;\n&lt;p style=&quot;text-align:justify;&quot;&gt;\n	&lt;span style=&quot;font-size:14px;&quot;&gt; • Trở thành đơn vị truyền thông đa phương tiện.&lt;/span&gt;&lt;/p&gt;\n&lt;p style=&quot;text-align:justify;&quot;&gt;\n	&lt;span style=&quot;font-size:14px;&quot;&gt; • Vươn lên tầm cao mới – Hội  nhập cùng thế giới.&lt;/span&gt;&lt;/p&gt;\n&lt;p style=&quot;text-align:justify;&quot;&gt;\n	&lt;span style=&quot;font-size:14px;&quot;&gt;&lt;strong&gt;1. Đối với thị trường:&lt;/strong&gt;&lt;/span&gt;&lt;/p&gt;\n&lt;p style=&quot;text-align:justify;margin-left:40px;&quot;&gt;\n	&lt;span style=&quot;font-size:14px;&quot;&gt;Cung cấp các giải pháp tối ưu về TMĐT mang lại lợi ích kinh tế cao cho các cá nhân, doanh nghiệp và nhà nước, đồng thời nâng cao được trình độ internet cho người tiêu dùng.&lt;/span&gt;&lt;/p&gt;\n&lt;p style=&quot;text-align:justify;&quot;&gt;\n	&lt;span style=&quot;font-size:14px;&quot;&gt;&lt;strong&gt;2. Đối với nhân viên, Thành viên:&lt;/strong&gt;&lt;/span&gt;&lt;/p&gt;\n&lt;p style=&quot;text-align:justify;margin-left:40px;&quot;&gt;\n	&lt;span style=&quot;font-size:14px;&quot;&gt;Xây dựng môi trường làm việc chuyên nghiệp, năng động, sáng tạo, tạo điều kiện thu nhập cao và cơ hội phát triển công bằng cho cán bộ công nhân viên, Thành viên. &lt;/span&gt;&lt;/p&gt;\n&lt;p style=&quot;text-align:justify;&quot;&gt;\n	&lt;span style=&quot;font-size:14px;&quot;&gt;&lt;strong&gt;3. Đối với xã hội:&lt;/strong&gt;&lt;/span&gt;&lt;/p&gt;\n&lt;p style=&quot;text-align:center;&quot;&gt;\n	&lt;span style=&quot;font-size:14px;&quot;&gt;&lt;img alt=&quot;&quot; src=&quot;/demo/public/userfiles/images/thuongmaidientu01.jpg&quot; style=&quot;width:338px;height:254px;&quot; /&gt;&lt;/span&gt;&lt;/p&gt;\n&lt;p&gt;\n	&lt;br /&gt;&lt;span style=&quot;font-size:14px;&quot;&gt;Với sự lớn mạnh của internet và những thành quả của thương mại điện tử, Công ty đã và đang thực hiện:&lt;/span&gt;&lt;/p&gt;\n&lt;p&gt;\n	&lt;br /&gt;&lt;span style=&quot;font-size:14px;&quot;&gt;• Xây dựng sàn giao dịch : C2C - B2C - B2B.&lt;/span&gt;&lt;/p&gt;\n&lt;p&gt;\n	&lt;br /&gt;&lt;span style=&quot;font-size:14px;&quot;&gt;• Xây dựng một hệ thống siêu thị trực tuyến, sàn đấu giá ... thanh toán trực tuyến và một ngân hàng Thương Mại Điện Tử.&lt;/span&gt;&lt;/p&gt;\n&lt;p&gt;\n	&lt;br /&gt;&lt;span style=&quot;font-size:14px;&quot;&gt;• Tạo lập hệ thống truyền thông đa phương tiện, một kênh thông tin của người tiêu dùng...&lt;/span&gt;&lt;/p&gt;\n&lt;p&gt;\n	&lt;br /&gt;&lt;span style=&quot;font-size:14px;&quot;&gt;• Cung cấp các giải pháp xây dựng và quảng bá thương hiệu.&lt;/span&gt;&lt;/p&gt;\n&lt;p&gt;\n	&lt;br /&gt;&lt;span style=&quot;font-size:14px;&quot;&gt;• Xây dựng hệ thống phân phối sản phẩm thông qua siêu thị TMĐT &lt;strong&gt;&lt;span style=&quot;color:rgb(0,0,0);&quot;&gt;VIP TẦM NHÌN VIỆT&lt;/span&gt;&lt;/strong&gt;.&lt;/span&gt;&lt;/p&gt;\n&lt;p&gt;\n	&lt;br /&gt;&lt;span style=&quot;font-size:14px;&quot;&gt;• Sàn đấu giá sản phẩm trực tuyến.&lt;/span&gt;&lt;/p&gt;\n&lt;p&gt;\n	&lt;br /&gt;&lt;span style=&quot;font-size:14px;&quot;&gt;• Chương trình mua hàng ưu đãi&lt;/span&gt;&lt;/p&gt;\n&lt;p&gt;\n	&lt;br /&gt;&lt;span style=&quot;font-size:14px;&quot;&gt;• Chương trình mua hàng tích điểm.&lt;/span&gt;&lt;/p&gt;\n&lt;p&gt;\n	&lt;br /&gt;&lt;span style=&quot;font-size:14px;&quot;&gt;• Các chương trình gameshow:&lt;/span&gt;&lt;/p&gt;\n&lt;p&gt;\n	&lt;br /&gt;&lt;span style=&quot;font-size:14px;&quot;&gt;Giờ vàng giảm giá, hội chợ trực tuyến, chọn giá sản phẩm&lt;/span&gt;…&lt;/p&gt;\n&lt;p style=&quot;text-align:center;&quot;&gt;\n	&lt;img alt=&quot;&quot; src=&quot;/public/userfiles/images/thuong%20hieu.jpg&quot; style=&quot;width:559px;height:452px;&quot; /&gt;&lt;br /&gt;&lt;br /&gt;&lt;span style=&quot;font-size:14px;&quot;&gt; Cùng với những thành công của các tập đoàn ứng dụng INTERNET trên Thế Giới và sự phát triển như vũ bão của mạng toàn cầu tại Việt Nam.&lt;strong&gt;&lt;span style=&quot;color:rgb(0,0,0);&quot;&gt; VIP TẦM NHÌN VIỆT&lt;/span&gt;&lt;/strong&gt; ra đời nhằm ứng dụng những tinh hoa của internet vào cuộc sống.&lt;/span&gt;&lt;/p&gt;\n', '', '', 870, '2011-08-16 01:32:39', 1, '', '', 0, 1);

-- --------------------------------------------------------

--
-- Table structure for table `dos_module_adv`
--

CREATE TABLE IF NOT EXISTS `dos_module_adv` (
  `record_id` int(11) NOT NULL auto_increment,
  `pic_thumb` varchar(50) NOT NULL default '',
  `title` varchar(50) NOT NULL default '',
  `titleen` varchar(50) default NULL,
  `titlefr` varchar(50) default NULL,
  `url` varchar(500) default NULL,
  `description` varchar(1000) default NULL,
  `create_date` timestamp NULL default CURRENT_TIMESTAMP,
  `start_date` timestamp NULL default NULL,
  `end_date` timestamp NULL default NULL,
  `hits` int(11) NOT NULL default '0',
  `record_order` int(11) default '1',
  `position` varchar(45) default NULL,
  `type` varchar(45) default NULL,
  `enable` tinyint(1) NOT NULL default '1',
  PRIMARY KEY  (`record_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=18 ;

--
-- Dumping data for table `dos_module_adv`
--

INSERT INTO `dos_module_adv` (`record_id`, `pic_thumb`, `title`, `titleen`, `titlefr`, `url`, `description`, `create_date`, `start_date`, `end_date`, `hits`, `record_order`, `position`, `type`, `enable`) VALUES
(5, '25117b.JPG', 'Quảng cáo trái', '', '', 'http://grouplaptrinh.com', '', '2011-11-07 08:29:10', '2011-11-06 16:00:00', '2011-11-09 16:00:00', 0, 2, 'left', '_bank', 1),
(9, 'nganhangnama.jpg', 'NGÂN HÀNG TM CP NAM Á', '', '', 'http://www.nab.com.vn/', '', '2011-11-08 03:07:47', '2011-11-07 16:00:00', '2011-11-29 16:00:00', 0, 7, 'center', '_parent', 1),
(10, '20110131_103022.jpg', 'CÔNG TY VÀNG BẠC ĐÁ QUÝ PHÚ NHUẬN ', '', '', 'http://www.pnj.com.vn/', '', '2011-11-08 03:33:04', '2011-11-07 16:00:00', '2011-11-29 16:00:00', 0, 8, 'center', '_parent', 1),
(11, 'cty-nang-luong-toan-cau.jpg', 'CTY TNHH MÔI TRƯỜNG PHƯƠNG NAM ', '', '', 'http://www.mayozone.net/', '', '2011-11-08 03:42:05', '2011-11-07 16:00:00', '2011-12-30 16:00:00', 0, 9, 'center', '_parent', 1),
(12, 'nang-luong-toan-cau.jpg', 'CTY TNHH CN - MT - NĂNG LƯỢNG TOÀN CẦU', '', '', 'http://nangluongtoancau.com/', '', '2011-11-08 03:49:23', '2011-11-07 16:00:00', '2011-12-30 16:00:00', 0, 10, 'center', '_parent', 1),
(13, 'dong-a.jpg', ' NGÂN HÀNG TM CP ĐÔNG Á ', '', '', 'http://www.dongabank.com.vn/', '', '2011-11-08 04:06:42', '2011-11-07 16:00:00', '2011-12-30 16:00:00', 0, 11, 'center', '_parent', 1),
(14, 'cty-song-hao.jpg', 'CTY TNHH TM SONG HAO', '', '', 'http://songhaovn.com/', '', '2011-11-08 04:09:23', '2011-11-07 16:00:00', '2011-12-30 16:00:00', 0, 12, 'center', '_parent', 1),
(15, 'logo_thuonghoi.png', 'cty thuong hoi', '', '', 'http://thuonghoi.com/demo/index/index/page/3', '', '2011-11-08 04:11:52', '2011-11-07 16:00:00', '2011-12-29 16:00:00', 0, 13, 'center', '_parent', 1),
(16, 'cty-long-viet.jpg', ' CÔNG TY MAY LONG VIỆT ', '', '', 'http://thuonghoi.com/demo/brands/index/view/i', '', '2011-11-08 13:52:47', '2011-11-07 16:00:00', '2011-12-07 16:00:00', 0, 14, 'center', '_parent', 1),
(17, 'images.jpg', 'VÍ ĐIỆN TỬ NGÂN LƯỢNG', '', '', 'http://www.nganluong.vn/', '', '2011-11-13 01:04:45', '2011-10-31 16:00:00', '2011-12-30 16:00:00', 0, 15, 'center', '_parent', 1);

-- --------------------------------------------------------

--
-- Table structure for table `dos_module_banner`
--

CREATE TABLE IF NOT EXISTS `dos_module_banner` (
  `banner_id` int(11) NOT NULL auto_increment,
  `banner_date` timestamp NOT NULL default CURRENT_TIMESTAMP,
  `banner_name` varchar(45) NOT NULL,
  `banner_url` varchar(45) default NULL,
  `banner_link` varchar(200) default NULL,
  `banner_order` int(11) NOT NULL default '1',
  `enable` tinyint(1) NOT NULL default '1',
  `position` varchar(45) NOT NULL,
  PRIMARY KEY  (`banner_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=22 ;

--
-- Dumping data for table `dos_module_banner`
--

INSERT INTO `dos_module_banner` (`banner_id`, `banner_date`, `banner_name`, `banner_url`, `banner_link`, `banner_order`, `enable`, `position`) VALUES
(11, '2011-10-27 12:54:13', 'Banner', 'baner_2.jpg', '', 6, 0, 'banner'),
(13, '2011-11-08 02:34:44', 'bener 3', 'baner_3.jpg', '', 8, 1, 'banner'),
(14, '2011-11-08 02:45:30', 'banner3', 'banner3.jpg', '', 7, 1, 'banner'),
(15, '2011-11-09 08:46:21', 'Hình 1', 'f1.jpg', 'http://thuonghoi.com/demo/', 1, 0, 'banner'),
(16, '2011-11-09 08:46:38', 'Hình 2', 'hinh-thong-bao.jpg', 'http://thuonghoi.com/demo/', 2, 0, 'banner'),
(17, '2011-11-09 08:46:55', 'Hình 3', 'f3.jpg', 'http://thuonghoi.com/demo/', 3, 0, 'banner'),
(18, '2011-11-09 08:47:09', 'Hình 4', 'f4.jpg', 'http://thuonghoi.com/demo/', 4, 0, 'banner'),
(19, '2011-11-09 08:56:32', 'Hình 5', 'f5.jpg', 'http://thuonghoi.com/demo/', 5, 0, 'banner'),
(20, '2011-11-09 09:01:11', 'Hình 6', 'f6.jpg', 'http://thuonghoi.com/demo/', 9, 1, 'banner'),
(21, '2011-11-16 09:27:17', 'HINH 10', 'o.jpg', '', 10, 1, 'banner');

-- --------------------------------------------------------

--
-- Table structure for table `dos_module_contact`
--

CREATE TABLE IF NOT EXISTS `dos_module_contact` (
  `record_id` int(11) NOT NULL auto_increment,
  `create_date` timestamp NOT NULL default CURRENT_TIMESTAMP,
  `title` varchar(70) NOT NULL,
  `titleen` varchar(70) default NULL,
  `titlefr` varchar(70) default NULL,
  `content` varchar(1000) NOT NULL,
  `contenten` varchar(5000) default NULL,
  `contentfr` varchar(5000) default NULL,
  `hot` tinyint(1) NOT NULL default '0',
  `enable` tinyint(1) NOT NULL default '1',
  PRIMARY KEY  (`record_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=11 ;

--
-- Dumping data for table `dos_module_contact`
--

INSERT INTO `dos_module_contact` (`record_id`, `create_date`, `title`, `titleen`, `titlefr`, `content`, `contenten`, `contentfr`, `hot`, `enable`) VALUES
(9, '2011-10-27 23:48:48', 'Liên hệ với chúng tôi', '', '', '&lt;p&gt;\n	&lt;span style=&quot;color:rgb(0,128,0);&quot;&gt;&lt;span style=&quot;font-size:14px;&quot;&gt;&lt;strong&gt;   CÔNG TY CỔ PHẦN TM-DV VIP TẦM NHÌN VIỆT&lt;/strong&gt;&lt;/span&gt;&lt;/span&gt;&lt;/p&gt;\n&lt;p&gt;\n	&lt;strong&gt;Trụ sở: LÔ L4, KP1, P.BỬU LONG, BIÊN HÒA ,ĐỒNG NAI&lt;/strong&gt;&lt;/p&gt;\n&lt;p&gt;\n	&lt;em&gt;Email: viptamnhinviet@gmail.com&lt;/em&gt;&lt;/p&gt;\n', '', '', 0, 1),
(10, '2011-10-31 02:15:32', 'Liên hệ trang chủ', '', '', '&lt;p&gt;\n	&lt;span style=&quot;color:#ff8c00;&quot;&gt;&lt;strong&gt;CÔNG TY CỔ PHẦN TM - DV VIP TẦM NHÌN VIỆT&lt;/strong&gt;&lt;br /&gt;\n	Trụ sở:LÔ L4, KP1, P.BỬU LONG, BIÊN HÒA ,ĐỒNG NAI&lt;br /&gt;\n	Điện thoại: 0613888767&lt;br /&gt;\n	Do Ủy ban nhân dân Thành phố Biên Hòa&lt;br /&gt;\n	 Sở Thông tin và Truyền thông cấp: số GPKD 3602648481&lt;/span&gt;&lt;/p&gt;\n&lt;p&gt;\n	&lt;span style=&quot;color:#ff8c00;&quot;&gt;MST: 3602648481&lt;br /&gt;\n	Cấp ngày 16 tháng 11 năm 2011&lt;/span&gt;&lt;/p&gt;\n', '', '', 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `dos_module_gallery`
--

CREATE TABLE IF NOT EXISTS `dos_module_gallery` (
  `record_id` int(11) NOT NULL auto_increment,
  `postdate` timestamp NOT NULL default CURRENT_TIMESTAMP,
  `pic_thumb` varchar(45) default NULL,
  `pic_full` varchar(45) default NULL,
  `title` varchar(100) default NULL,
  `titleen` varchar(100) default NULL,
  `titlefr` varchar(100) default NULL,
  `hits` int(11) default '0',
  `record_order` int(11) default '1',
  `enable` tinyint(1) NOT NULL default '1',
  `dos_module_gallery_cat_cat_id` int(11) NOT NULL,
  PRIMARY KEY  (`record_id`),
  KEY `fk_dos_module_gallery_dos_module_gallery_cat` (`dos_module_gallery_cat_cat_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `dos_module_gallery`
--


-- --------------------------------------------------------

--
-- Table structure for table `dos_module_gallery_cat`
--

CREATE TABLE IF NOT EXISTS `dos_module_gallery_cat` (
  `cat_id` int(11) NOT NULL auto_increment,
  `cat_parent_id` int(11) NOT NULL default '0',
  `pic_thumb` varchar(45) default NULL,
  `pic_full` varchar(45) default NULL,
  `cat_title` varchar(45) NOT NULL,
  `cat_titleen` varchar(45) default NULL,
  `cat_titlefr` varchar(45) default NULL,
  `preview` text,
  `previewen` text,
  `previewfr` text,
  `cat_order` int(11) NOT NULL default '1',
  `cat_extra1` varchar(45) default NULL,
  `cat_hot` tinyint(1) NOT NULL,
  `cat_enable` tinyint(1) NOT NULL default '1',
  PRIMARY KEY  (`cat_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=23 ;

--
-- Dumping data for table `dos_module_gallery_cat`
--

INSERT INTO `dos_module_gallery_cat` (`cat_id`, `cat_parent_id`, `pic_thumb`, `pic_full`, `cat_title`, `cat_titleen`, `cat_titlefr`, `preview`, `previewen`, `previewfr`, `cat_order`, `cat_extra1`, `cat_hot`, `cat_enable`) VALUES
(22, 0, NULL, NULL, 'Danh mục hình ảnh', '', '', '', '', '', 1, NULL, 0, 1);

-- --------------------------------------------------------

--
-- Table structure for table `dos_module_handbook`
--

CREATE TABLE IF NOT EXISTS `dos_module_handbook` (
  `record_id` int(11) NOT NULL auto_increment,
  `pic_thumb` varchar(45) default NULL,
  `title` varchar(100) NOT NULL,
  `titleen` varchar(100) default NULL,
  `titlefr` varchar(100) default NULL,
  `preview` text NOT NULL,
  `previewen` text,
  `previewfr` text,
  `content` text NOT NULL,
  `contenten` text,
  `contentfr` text,
  `author` varchar(45) default NULL,
  `hits` int(11) NOT NULL default '1',
  `postdate` timestamp NULL default CURRENT_TIMESTAMP,
  `record_order` int(11) NOT NULL default '1',
  `record_type` tinyint(1) NOT NULL default '0',
  `extra_field1` varchar(45) default NULL,
  `extra_field2` varchar(45) default NULL,
  `enable` tinyint(1) NOT NULL default '1',
  `dos_module_handbook_cat_cat_id` int(11) NOT NULL,
  PRIMARY KEY  (`record_id`),
  KEY `fk_dos_module_handbook_dos_module_handbook_cat` (`dos_module_handbook_cat_cat_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=19 ;

--
-- Dumping data for table `dos_module_handbook`
--

INSERT INTO `dos_module_handbook` (`record_id`, `pic_thumb`, `title`, `titleen`, `titlefr`, `preview`, `previewen`, `previewfr`, `content`, `contenten`, `contentfr`, `author`, `hits`, `postdate`, `record_order`, `record_type`, `extra_field1`, `extra_field2`, `enable`, `dos_module_handbook_cat_cat_id`) VALUES
(1, '20111117_190517.jpg', 'Internet đang làm thay đổi phương thức kinh doanh', '', '', '&lt;p&gt;\n	&lt;strong&gt;Công ty nghiên cứu Internet hàng đầu Forrester Research cho biết .&lt;/strong&gt;&lt;br /&gt;\n	 &lt;/p&gt;\n&lt;p&gt;\n	 &lt;/p&gt;\n', '', '', '&lt;p&gt;\n	&lt;span style=&quot;font-size:16px;&quot;&gt;&lt;strong&gt;Internet đang làm thay đổi phương thức kinh doanh như thế nào?&lt;/strong&gt;&lt;/span&gt;&lt;/p&gt;\n&lt;p&gt;\n	Công ty nghiên cứu Internet hàng đầu Forrester Research cho biết trong năm 1998 các công ty đã thực hiện một trị giá 43 tỷ USD về giao dịch thương mại điện tử B-B. Đến năm 2003, dự kiến sẽ đạt con số 1,3 nghìn tỷ USD, chiếm 9,4% doanh số của tất cả các giao dịch B-B. Nói chung, trong khi doanh số bán hàng B-C trên mạng còn rất nhỏ so với hình thức bán hàng B-C truyền thống, thì mạng Internet đang hàng ngày làm thay đổi nhanh chóng phương thức kinh doanh.&lt;/p&gt;\n&lt;p&gt;\n	•    Người mua hàng bây giờ có thể dễ dàng, với chi phí giảm hơn trước, so sánh giá cả và dịch vụ của các nhà cung cấp khác nhau trên thế giới.&lt;/p&gt;\n&lt;p&gt;\n	•    Mạng Internet giúp cho các doanh nghiệp có thể duy trì mối quan hệ trực tiếp với từng khách hàng riêng rẽ trong số lượng rất lớn khách hàng của mình. Thông tin về từng khách hàng riêng biệt được đưa vào quan hệ của công ty đối với khách hàng đó gồm các số liệu như doanh số bán hàng, tài khoản, tiếp thị.v.v. Trình độ cao về dịch vụ cung cấp cho khách hàng đã trở thành tiêu chuẩn cho thị trường tiêu dùng trên mạng.&lt;/p&gt;\n&lt;p&gt;\n	•    Nghiên cứu giá cả, chất lượng, kế hoạch giao hàng, cấu tạo hoặc các chi tiết của sản phẩm có thể thực hiện trên mạng Internet.&lt;/p&gt;\n&lt;p&gt;\n	•    Khách hàng có thể dễ dàng định rõ những yêu cầu riêng rẽ ngay trên mạng, cho phép làm theo đơn đặt hàng riêng các sản phẩm như ô tô, đồ trang sức, đĩa CD.v.v&lt;/p&gt;\n&lt;p&gt;\n	•    Nhờ chi phí tìm kiếm thấp hơn trước, số khách hàng mới tham gia vào thị trường này có nhiều khả năng được cung cấp đầy đủ thông tin về giá cả, tình hình cung ứng giống như các nhà cung cấp thường xuyên cho thị trường.&lt;/p&gt;\n&lt;p&gt;\n	•    Các hình thức khuyến mãi có thể tập trung vào từng cá nhân một cách có hiệu quả hơn so với các hình thức truyền thống trước đây (như TV, ca- ta- lô, quảng cáo trên báo).&lt;/p&gt;\n&lt;p&gt;\n	•    Người mua được mặc cả rất nhiều hoại hàng hóa và dịch vụ.&lt;/p&gt;\n&lt;p&gt;\n	Các site đấu giá, liên kết người mua hàng và đổi hàng đang xuất hiện ngày càng nhiều.&lt;/p&gt;\n&lt;p&gt;\n	•    Người mua có thể cùng tập hợp thành một nhóm để mua hàng nhằm mục đích hưởng phần chiết khấu số lượng.&lt;/p&gt;\n&lt;p&gt;\n	•    Các doanh nghiệp ảo tìm được khách hàng một cách nhanh hơn với chi phí rất thấp về mặt bằng cửa hiệu và nhân viên bán hàng.&lt;/p&gt;\n&lt;p&gt;\n	•    Các công ty trung gian trên Internet (như infor mediaries, vertical portale or e- marketers) có thể mang lại nhiều lợi ích cho người tiêu dùng (bất kể là công ty hay cá nhân) hơn so với đội ngũ những người môi giới truyền thống.&lt;/p&gt;\n&lt;p&gt;\n	•    Cạnh tranh trên phạm vi toàn cầu và sự dễ dàng trong việc so sánh giá cả sẽ làm cho nhiều công ty bán lẻ trên Internet có thể thành đạt với mức tăng giá ít.&lt;/p&gt;\n&lt;p&gt;\n	•    Các doanh nghiệp lớn và các hãng nổi tiếng đang thống trị Internet, tuy nhiên 30.000 doanh nghiệp nhỏ ở Mỹ, với doanh thu hàng năm dưới 10 triệu USD cũng đang bán hàng trên mạng Internet. Doanh thu của các doanh nghiệp vừa và nhỏ này dự kiến dạt 40,000 tỷ USD vào năm 2003.&lt;/p&gt;\n&lt;p&gt;\n	•    Thị trường Internet toàn cầu đưa lại cơ hội mới cho các nhà buôn nhỏ tại các nước phát triển và đang phát triển, nhưng đồng thời cũng đưa sự cạnh tranh toàn cầu tới các thị trường nhỏ, địa phương, những thị trường truyền thống của các nhà buôn nhỏ.&lt;/p&gt;\n&lt;p&gt;\n	•    Các nhà buôn trên mạng có thể biếu khách hàng một số sản phẩm dưới hình thức bán kèm hoặc là bán tiếp các sản phẩm đời sau với giá thấp hơn thậm chí tự động gửi đến trên cơ sở các thông tin thu thập qua mạng từ khách hàng. Ngày nay hiệu quả kinh tế liên quan chặt chẽ hơn với khả năng kiểm soát và chuyển thông tin và các giao dịch thương mại.&lt;/p&gt;\n&lt;p&gt;\n	•    Mạng Internet sẽ toàn cầu hoá nhanh chóng các thị trường và các ngành công nghiệp.&lt;/p&gt;\n&lt;p&gt;\n	•    Việc cung cấp các dịch vụ về ngân hàng, giáo dục, tư vấn, thiết kế, tiếp thị và các loại dịch vụ tương tự sẽ thay đổi một cách mạnh mẽ.&lt;/p&gt;\n&lt;p&gt;\n	•    Mạng Internet sẽ quảng bá các sáng chế nhanh hơn rất nhiều so với trước đây (vào những năm 1980, cần phải mất trung bình 10 năm để một sáng chế ở nước này được áp dụng ở nước khác).&lt;/p&gt;\n&lt;p&gt;\n	•    Mạng Internet giúp hạ chi phí. Một nghiên cứu mới đây của tập đoàn Giga Information Group Inc. cho rằng mức tiết kiệm trên toàn thế giới do các doanh nghiệp sử dụng thương mại điện tử sẽ tăng từ 17 tỷ USD của năm 1998 bên 1,25 nghìn tỷ USD năm 2002.&lt;/p&gt;\n&lt;p&gt;\n	•    Các nhà cung cấp nội địa và nước ngoài có thể dễ dàng liên kết chặt chẽ với nhau hơn trong dây chuyền cung ứng.&lt;/p&gt;\n&lt;p&gt;\n	Nhiều doanh nghiệp nhỏ có thể tăng thêm doanh thu bằng cách trở thành thành viên của các doanh nghiệp lớn hơn, như trong trường hợp site bán hàng trên mạng Amazon.com có 260.000 thành viên tham gia kết nối. Khi một khách hàng kích vào link và mua một mặt hàng nào đó trên Amazon, công ty thành viên được nhận hoa hồng từ 5%- 15%. Với hy vọng thu hút nhiều khách hàng đến với site của mình, các công ty lớn trên Internet đang giúp các công ty nhỏ xây dựng website của họ chỉ trong vòng vài ngày mà không đòi hỏi kỹ năng công nghệ nào với giá thành ban đầu khoảng 500 USD, sau đó hàng tháng phải trả từ 150-350 USD cho các công ty lớn. Mặc dù lợi ích mang lại cho các doanh nghiệp sừ dụng công nghệ thông tin và thương mại điện tử rất to lớn, nhiều doanh nghiệp vừa và nhỏ chưa tham gia vào các phương thức kinh doanh mới này. Tại Mỹ, theo một số nghiên cứu gần đây chỉ có 35% doanh nghiệp nhỏ sử dụng mạng Internet để thu thập thông tin, và một tỷ lệ phần trăm nhỏ hơn sử dụng Internet để mua bán hàng hoá, nguyên vật liệu hoặc để kết hợp với các công việc kinh doanh khác của họ.&lt;/p&gt;\n&lt;p&gt;\n	&lt;br /&gt;\n	( Nguồn: Sưu tầm trên internet //intracen.org )&lt;br /&gt;\n	Bài thuộc chuyên đề: Bí quyết Thương mại điện tử cho doanh nghiệp nhỏ và vừa&lt;/p&gt;\n', '', '', NULL, 1, '2011-11-15 10:59:30', 1, 0, NULL, NULL, 1, 15),
(10, '20111117_190540.jpg', 'BÍ QUYẾT THƯƠNG MẠI ĐIỆN TỬ', '', '', '&lt;p&gt;\n	&lt;strong&gt;Internet đang làm thay đổi phương thức kinh doanh như thế nào? &lt;/strong&gt;&lt;/p&gt;\n', '', '', '&lt;p&gt;\n	&lt;span style=&quot;font-size:16px;&quot;&gt;&lt;strong&gt;   Internet đang làm thay đổi phương thức kinh doanh như thế nào?&lt;/strong&gt;&lt;/span&gt;&lt;/p&gt;\n&lt;p&gt;\n	Công ty nghiên cứu Internet hàng đầu Forrester Research cho biết trong năm 1998 các công ty đã thực hiện một trị giá 43 tỷ USD về giao dịch thương mại điện tử B-B. Đến năm 2003, dự kiến sẽ đạt con số 1,3 nghìn tỷ USD, chiếm 9,4% doanh số của tất cả các giao dịch B-B. Nói chung, trong khi doanh số bán hàng B-C trên mạng còn rất nhỏ so với hình thức bán hàng B-C truyền thống, thì mạng Internet đang hàng ngày làm thay đổi nhanh chóng phương thức kinh doanh.&lt;/p&gt;\n&lt;p&gt;\n	•    Người mua hàng bây giờ có thể dễ dàng, với chi phí giảm hơn trước, so sánh giá cả và dịch vụ của các nhà cung cấp khác nhau trên thế giới.&lt;/p&gt;\n&lt;p&gt;\n	•    Mạng Internet giúp cho các doanh nghiệp có thể duy trì mối quan hệ trực tiếp với từng khách hàng riêng rẽ trong số lượng rất lớn khách hàng của mình. Thông tin về từng khách hàng riêng biệt được đưa vào quan hệ của công ty đối với khách hàng đó gồm các số liệu như doanh số bán hàng, tài khoản, tiếp thị.v.v. Trình độ cao về dịch vụ cung cấp cho khách hàng đã trở thành tiêu chuẩn cho thị trường tiêu dùng trên mạng.&lt;/p&gt;\n&lt;p&gt;\n	•    Nghiên cứu giá cả, chất lượng, kế hoạch giao hàng, cấu tạo hoặc các chi tiết của sản phẩm có thể thực hiện trên mạng Internet.&lt;/p&gt;\n&lt;p&gt;\n	•    Khách hàng có thể dễ dàng định rõ những yêu cầu riêng rẽ ngay trên mạng, cho phép làm theo đơn đặt hàng riêng các sản phẩm như ô tô, đồ trang sức, đĩa CD.v.v&lt;/p&gt;\n&lt;p&gt;\n	•    Nhờ chi phí tìm kiếm thấp hơn trước, số khách hàng mới tham gia vào thị trường này có nhiều khả năng được cung cấp đầy đủ thông tin về giá cả, tình hình cung ứng giống như các nhà cung cấp thường xuyên cho thị trường.&lt;/p&gt;\n&lt;p&gt;\n	•    Các hình thức khuyến mãi có thể tập trung vào từng cá nhân một cách có hiệu quả hơn so với các hình thức truyền thống trước đây (như TV, ca- ta- lô, quảng cáo trên báo).&lt;/p&gt;\n&lt;p&gt;\n	•    Người mua được mặc cả rất nhiều hoại hàng hóa và dịch vụ.&lt;/p&gt;\n&lt;p&gt;\n	Các site đấu giá, liên kết người mua hàng và đổi hàng đang xuất hiện ngày càng nhiều.&lt;/p&gt;\n&lt;p&gt;\n	•    Người mua có thể cùng tập hợp thành một nhóm để mua hàng nhằm mục đích hưởng phần chiết khấu số lượng.&lt;/p&gt;\n&lt;p&gt;\n	•    Các doanh nghiệp ảo tìm được khách hàng một cách nhanh hơn với chi phí rất thấp về mặt bằng cửa hiệu và nhân viên bán hàng.&lt;/p&gt;\n&lt;p&gt;\n	•    Các công ty trung gian trên Internet (như infor mediaries, vertical portale or e- marketers) có thể mang lại nhiều lợi ích cho người tiêu dùng (bất kể là công ty hay cá nhân) hơn so với đội ngũ những người môi giới truyền thống.&lt;/p&gt;\n&lt;p&gt;\n	•    Cạnh tranh trên phạm vi toàn cầu và sự dễ dàng trong việc so sánh giá cả sẽ làm cho nhiều công ty bán lẻ trên Internet có thể thành đạt với mức tăng giá ít.&lt;/p&gt;\n&lt;p&gt;\n	•    Các doanh nghiệp lớn và các hãng nổi tiếng đang thống trị Internet, tuy nhiên 30.000 doanh nghiệp nhỏ ở Mỹ, với doanh thu hàng năm dưới 10 triệu USD cũng đang bán hàng trên mạng Internet. Doanh thu của các doanh nghiệp vừa và nhỏ này dự kiến dạt 40,000 tỷ USD vào năm 2003.&lt;/p&gt;\n&lt;p&gt;\n	•    Thị trường Internet toàn cầu đưa lại cơ hội mới cho các nhà buôn nhỏ tại các nước phát triển và đang phát triển, nhưng đồng thời cũng đưa sự cạnh tranh toàn cầu tới các thị trường nhỏ, địa phương, những thị trường truyền thống của các nhà buôn nhỏ.&lt;/p&gt;\n&lt;p&gt;\n	•    Các nhà buôn trên mạng có thể biếu khách hàng một số sản phẩm dưới hình thức bán kèm hoặc là bán tiếp các sản phẩm đời sau với giá thấp hơn thậm chí tự động gửi đến trên cơ sở các thông tin thu thập qua mạng từ khách hàng. Ngày nay hiệu quả kinh tế liên quan chặt chẽ hơn với khả năng kiểm soát và chuyển thông tin và các giao dịch thương mại.&lt;/p&gt;\n&lt;p&gt;\n	•    Mạng Internet sẽ toàn cầu hoá nhanh chóng các thị trường và các ngành công nghiệp.&lt;/p&gt;\n&lt;p&gt;\n	•    Việc cung cấp các dịch vụ về ngân hàng, giáo dục, tư vấn, thiết kế, tiếp thị và các loại dịch vụ tương tự sẽ thay đổi một cách mạnh mẽ.&lt;/p&gt;\n&lt;p&gt;\n	•    Mạng Internet sẽ quảng bá các sáng chế nhanh hơn rất nhiều so với trước đây (vào những năm 1980, cần phải mất trung bình 10 năm để một sáng chế ở nước này được áp dụng ở nước khác).&lt;/p&gt;\n&lt;p&gt;\n	•    Mạng Internet giúp hạ chi phí. Một nghiên cứu mới đây của tập đoàn Giga Information Group Inc. cho rằng mức tiết kiệm trên toàn thế giới do các doanh nghiệp sử dụng thương mại điện tử sẽ tăng từ 17 tỷ USD của năm 1998 bên 1,25 nghìn tỷ USD năm 2002.&lt;/p&gt;\n&lt;p&gt;\n	•    Các nhà cung cấp nội địa và nước ngoài có thể dễ dàng liên kết chặt chẽ với nhau hơn trong dây chuyền cung ứng.&lt;/p&gt;\n&lt;p&gt;\n	Nhiều doanh nghiệp nhỏ có thể tăng thêm doanh thu bằng cách trở thành thành viên của các doanh nghiệp lớn hơn, như trong trường hợp site bán hàng trên mạng Amazon.com có 260.000 thành viên tham gia kết nối. Khi một khách hàng kích vào link và mua một mặt hàng nào đó trên Amazon, công ty thành viên được nhận hoa hồng từ 5%- 15%. Với hy vọng thu hút nhiều khách hàng đến với site của mình, các công ty lớn trên Internet đang giúp các công ty nhỏ xây dựng website của họ chỉ trong vòng vài ngày mà không đòi hỏi kỹ năng công nghệ nào với giá thành ban đầu khoảng 500 USD, sau đó hàng tháng phải trả từ 150-350 USD cho các công ty lớn. Mặc dù lợi ích mang lại cho các doanh nghiệp sừ dụng công nghệ thông tin và thương mại điện tử rất to lớn, nhiều doanh nghiệp vừa và nhỏ chưa tham gia vào các phương thức kinh doanh mới này. Tại Mỹ, theo một số nghiên cứu gần đây chỉ có 35% doanh nghiệp nhỏ sử dụng mạng Internet để thu thập thông tin, và một tỷ lệ phần trăm nhỏ hơn sử dụng Internet để mua bán hàng hoá, nguyên vật liệu hoặc để kết hợp với các công việc kinh doanh khác của họ.&lt;/p&gt;\n&lt;p&gt;\n	&lt;br /&gt;\n	( Nguồn: Sưu tầm trên internet //intracen.org )&lt;br /&gt;\n	Bài thuộc chuyên đề: Bí quyết Thương mại điện tử cho doanh nghiệp nhỏ và vừa&lt;/p&gt;\n', '', '', NULL, 1, '2011-11-17 10:39:43', 1, 0, NULL, NULL, 1, 15),
(11, '20111117_190602.jpg', 'Hãy lập kế hoạch để đạt mục tiêu trong thương mại điện tử ', '', '', '&lt;p&gt;\n	Bài viết này được rút ra từ cuốn “Những chiến lược marketing hùng mạnh hỗ trợ công việc kinh doanh” của Heidi Richarchs.&lt;/p&gt;\n', '', '', '&lt;p&gt;\n	                                                                          &lt;img alt=&quot;&quot; src=&quot;/public/userfiles/images/img-1222158210-2.jpg&quot; style=&quot;width:250px;height:186px;&quot; /&gt;&lt;/p&gt;\n&lt;p&gt;\n	         Bài viết này được rút ra từ cuốn “Những chiến lược marketing hùng mạnh hỗ trợ công việc kinh doanh” của Heidi Richarchs.&lt;br /&gt;\n	         Richarchs còn là tác giả của 7 cuốn sách khác nữa. Cô cũng là người sáng lập và lãnh đạo hiệp hội thương mại điện tử, tổ chức internet quốc tế tại website&lt;br /&gt;\n	www.wecai.org, một tổ chức thương mại của phụ nữ trên web. Dưới đây là một số kinh nghiệm về thương mại điện tử của cô.Trước khi trở thành trở thành một nhà kinh doanh trực tuyến trên internet, tôi đã từng là chủ một doanh nghiệp. Thời gian đầu, tôi sở hữu một trung tâm chăm sóc trẻ em nổi tiếng hoạt động được ít nhất hai năm.Sau đó, tôi mua một cửa hàng hoa tuy nhỏ nhưng đã có ít nhất 300 khách hàng và phát triển nó tới ngày hôm nay. Một trong số những thành công lớn nhất của cửa hàng đó là phi vụ kinh doanh cung cấp hoa thường niên cho những công ty được trao giải thưởng ở miền Nam Florida với hơn 7000 khách hàng. Để phục vụ tốt hơn những nhu cầu của khách hàng, chúng tôi đã đưa công việc kinh doanh lên mạng Internet. Ngoài bức thành vững chắc hỗ trợ cửa hàng đó, càng ngày chúng tôi càng nhận được sự quan tâm nhiều hơn từ những khách hàng dạo chơi qua Internet&lt;br /&gt;\n	          Còn bạn thì sao? Bạn có đang hoặc đã sở hữu một công việc kinh doanh theo kiểu truyền thống hay hành nghề theo một kiểu chuyên nghiệp? Đó là sự thành công ư? Trừ khi bạn được sinh ra dưới một ngôi sao may mắn, bạn hầu như chắc chắn đã có rất nhiều dự định. Một kế hoạch kinh doanh, một kế hoạch marketing, có thể thậm chí là một kế hoạch liên tiếp để thực hiện công việc kinh doanh của bạn.&lt;br /&gt;\n	           Có thể bạn đã từng nghe nói về những con số thống kê như hơn một nửa các doanh nghiệp nhỏ đã từng thất bại trong năm đầu tiên và trong những số đó, chỉ có 25% chống chọi được qua 5 năm. Theo youngbiz.com thì con số đó có thể ít hơn đối với ngành thương mại điện tử.&lt;br /&gt;\n	           Bạn có thể có một website rất tuyệt vời với rất nhiều hình ảnh và âm thanh sống động nhưng nếu mọi người không biết tới sự hiện diện của bạn, thì bạn sẽ không có nổi một vài vị khách viếng thăm nào chứ chưa nói đến khách hàng.&lt;br /&gt;\n	           Kế hoạch chính là chìa khoá để thành công trong kinh doanh. Amazon.com cũng đã từng có kế hoạch, Bill Gates cũng đã có kế hoạch, eDiets cũng có kế hoạch, và tôi đánh cuộc rằng họ vẫn còn có những kế hoạch tiếp theo. Một khi đã dấn thân vào con đường kinh doanh trên internet, bạn cần phải lên kế hoạch marketing để có được kết quả kinh doanh tốt. Sự thách thức lớn nhất đối với bạn sẽ được tìm thấy ở thời điểm lập kế hoạch. Tuy nhiên, nếu bạn không không tìm được thời cơ ngay lúc đó, bạn cũng vẫn còn nhiều cơ hội sau đó và kinh doanh thì không thể nói trước được điều gì.&lt;br /&gt;\n	           Không giống như việc kinh doanh buôn bán, thương mại điện tử thường được hỗ trợ về mặt tài chính từ các nhà đầu tư. Do vậy, các doanh nghiệp kinh doanh internet đã thiết lập một kế hoạch marketing cho riêng họ. Chúng ta sẽ bắt đầu từ đâu? Trước tiên bạn hãy tự hỏi chính bản thân mình những câu hỏi đó. Bạn muốn bắt đầu tại đâu trong 1 năm, 5 năm hay10 năm? Bạn muốn có bao nhiêu khách hàng hoặc hơn nữa, bạn muốn kiếm được bao nhiêu tiền? Những khách hàng của bạn là ai? Bạn có biết họ cần và mong đợi điều gì? Bạn có thể mang lại điều đó cho họ không? Những đối thủ cạnh tranh của bạn đang làm gì? Bạn đang làm gì để đối phó với địch thủ của mình? Bạn sẽ xúc tiến công việc kinh doanh như thế nào?giờ hãy xây dựng kế hoạch marketing cho website của mình.&lt;br /&gt;\n	          Hãy đặt bút xuống viết! Bạn không chỉ có kế hoạch mà còn phải viết nó ra! Hãy lấy một quyển sổ ghi chép hay sổ ý tưởng và viết ra như: mơ ước của bạn, những chiến lược kinh doanh, những mục tiêu và sắp xếp thứ tự thời gian để thực hiện những mục tiêu này. Hãy giữ quyển sổ này và đồng thời ghi cả vào máy vi tính của bạn để tham khảo thực hiện. Nó sẽ giúp bạn lưu lại những vấn đề trọng tâm&lt;/p&gt;\n&lt;p&gt;\n	                                                                         &lt;img alt=&quot;&quot; src=&quot;/public/userfiles/images/1300376057_wq-money-woman.jpg&quot; style=&quot;width:258px;height:214px;&quot; /&gt;.&lt;br /&gt;\n	          Mơ ước của bạn cho công việc kinh doanh là gì?&lt;br /&gt;\n	          Đó chính là những gì bạn mong đợi website của mình thực hiện được. Hãy bày tỏ những mơ ước của bạn trong quyển sổ đó. Tôi đã bày tỏ mơ ước cho cửa hàng hoa của tôi là: “Tạo được những lợi nhuận hợp lý trên Internet bằng cách phát triển chất lượng sản phẩm, dịch vụ vận chuyển đặc biệt, giá cả thì sẽ do khách hàng chi trả.”&lt;br /&gt;\n	           Những mục tiêu của bạn là gì? Bạn nghĩ rằng bạn có thể thực hiện mục tiêu gì khi gặp một chút khó khăn có thể giải quyết được? Nếu những mục tiêu đó quá dễ dàng, bạn sẽ không có lợi ích gì ngoài quá trình thực hiện kế hoạch. Và bạn có thể còn mất tiền. Bạn có thể thu lợi nhuận khoảng 20% trong 3 tháng không? Có thể tăng gấp đôi số lượng khách hàng trong 6 tháng không? Vậy thì hãy viết tất cả ra sổ tay của bạn.&lt;br /&gt;\n	Những bước bạn cần để đạt được những mục tiêu là gì? Bạn phải bán được bao nhiêu để đạt được mục tiêu của mình? Trước hết bạn biết được lãi ròng mà bạn thu được để định rõ con số này. Sau đó bạn phải tính toán làm cách nào tìm được những khách hàng để biến mục tiêu của bạn thành hiện thực.&lt;br /&gt;\n	           Chiến lược marketing của bạn là gì? Hãy bắt đầu với những mục tiêu đó và bạn sẽ biết bạn có thể đạt được điều gì. Bạn sẽ tìm kiếm thị trường cho mình như thế nào? Bạn có sử dụng sự tối ưu của các phương tiện tìm kiếm kiếm, thư điện tử, hoạt động mạng, quảng cáo trên các website có liên quan, quảng cáo trên tạp chí thương mại, hay viết những bài báo đăng trên những website báo điện tử không? Hãy tham gia các diễn đàn trực tuyến, mạng truyền thông nước ngoài, các nhóm thảo luận. Kể cả đưa URL (địa chỉ internet) của bạn vào các file ký nhận.&lt;br /&gt;\n	            Quy trình thời gian để thực hiện những mục tiêu của bạn là gì? Ghi lại thời gian dành cho mỗi mục tiêu vào sổ ghi chép. Tiếp đến với mỗi mục tiêu, bạn hãy viết ra thời gian bắt đầu và kết thúc khi bạn đặt kế hoạch để thực hiện mục tiêu. Những ghi chép về chiến lược marketing là những gì bạn sẽ phải sử dụng đến.&lt;br /&gt;\n	Bạn có giữ lại những theo dõi về kết quả marketing của bạn không? Nếu bạn đang làm bất kỳ hoạt động quảng cáo nào dù đó là trực tuyến hay không trực tuyến, hãy ghi kết quả. Bạn có thể theo dõi công việc quảng cáo trực tuyến bằng cách sử dụng các phần mềm kiểm tra như adtrackz.com, để theo dõi tất cả các liên kết bạn đầu tư trực tuyến. Phân tích số liệu thống kê trên website để tìm ra những vị khách đã tìm đến bạn. Đối với quảng cáo không trực tuyến, đặt những mật mã hoặc dòng lệnh trong mục quảng cáo của bạn để tiện theo dõi. Các mẫu đơn đặt hàng nên có một vị trí để xác nhận mật mã, phục vụ cho việc nhận biết những vị khách đã mua hàng. Chúng tôi sử dụng mật mã là các ký tự trên tất cả các mục quảng cáo/ những tài liệu marketing.&lt;br /&gt;\n	           Kết quả đầu tư của bạn là gì? Những chiến lược marketing đã lấy đi của bạn bao nhiêu tiền? Bạn đã bị thua lỗ bao nhiêu tiền? Hãy trừ con số thứ nhất và thứ hai, còn lại đó chính là tiền lãi (hoặc tiền lỗ) của bạn.&lt;br /&gt;\n	Hãy ghi nhớ những chiến lược marketing đã thực hiện và không thực hiện được. Nếu lần thứ nhất không mang lại thành công cho bạn thì hãy mạo hiểm hơn ở lần thứ hai này. Bạn nên thay đổi một vài chiến lược để giành được kết quả cao. Hãy thử xem! Trừ khi bạn không còn khả năng về mặt tài chính!&lt;br /&gt;\n	        .&lt;/p&gt;\n', '', '', NULL, 1, '2011-11-18 02:03:55', 1, 0, NULL, NULL, 1, 14);
INSERT INTO `dos_module_handbook` (`record_id`, `pic_thumb`, `title`, `titleen`, `titlefr`, `preview`, `previewen`, `previewfr`, `content`, `contenten`, `contentfr`, `author`, `hits`, `postdate`, `record_order`, `record_type`, `extra_field1`, `extra_field2`, `enable`, `dos_module_handbook_cat_cat_id`) VALUES
(13, NULL, '	Văn bản pháp luật ', '', '', '&lt;p style=&quot;text-align:center;&quot;&gt;\n	&lt;span style=&quot;font-size:14px;&quot;&gt;&lt;strong&gt;QUYẾT ĐỊNH&lt;/strong&gt;&lt;/span&gt;&lt;/p&gt;\n&lt;p style=&quot;text-align:center;&quot;&gt;\n	&lt;span style=&quot;font-size:14px;&quot;&gt;&lt;strong&gt;Phê duyệt Kế hoạch tổng thể phát triển thương mại điện tử&lt;/strong&gt;&lt;/span&gt;&lt;/p&gt;\n&lt;p style=&quot;text-align:center;&quot;&gt;\n	&lt;span style=&quot;font-size:14px;&quot;&gt;&lt;strong&gt;giai đoạn 2011 - 2015&lt;/strong&gt;&lt;/span&gt;&lt;/p&gt;\n', '', '', '&lt;table border=&quot;1&quot; cellpadding=&quot;1&quot; cellspacing=&quot;1&quot; style=&quot;width:731px;height:118px;&quot;&gt;&lt;tbody&gt;&lt;tr&gt;&lt;td&gt;\n				&lt;p style=&quot;text-align:center;&quot;&gt;\n					&lt;span style=&quot;font-size:16px;&quot;&gt;&lt;strong&gt;THỦ TƯỚNG CHÍNH &lt;/strong&gt;&lt;/span&gt;&lt;/p&gt;\n				&lt;p style=&quot;text-align:center;&quot;&gt;\n					&lt;span style=&quot;font-size:16px;&quot;&gt;&lt;strong&gt;  PHỦ&lt;/strong&gt;&lt;/span&gt;&lt;br /&gt;\n					___________&lt;br /&gt;&lt;strong&gt;&lt;span style=&quot;font-size:12px;&quot;&gt;Số: 1073/QĐ-TTg&lt;/span&gt;&lt;/strong&gt;&lt;/p&gt;\n			&lt;/td&gt;\n			&lt;td style=&quot;text-align:center;&quot;&gt;\n				&lt;span style=&quot;font-size:16px;&quot;&gt;&lt;strong&gt;CỘNG HÒA XÃ HỘI CHỦ NGHĨA VIỆT NAM&lt;br /&gt;\n				   Độc lập - Tự do - Hạnh phúc&lt;/strong&gt;&lt;br /&gt;\n				   _______________________________&lt;/span&gt;&lt;br /&gt;\n				             &lt;strong&gt;  &lt;span style=&quot;font-size:12px;&quot;&gt;Hà Nội, ngày 12 tháng 7 năm 2010&lt;/span&gt;&lt;/strong&gt;&lt;/td&gt;\n		&lt;/tr&gt;&lt;/tbody&gt;&lt;/table&gt;&lt;p style=&quot;text-align:center;&quot;&gt;\n	&lt;span style=&quot;font-size:18px;&quot;&gt;&lt;strong&gt;QUYẾT ĐỊNH&lt;/strong&gt;&lt;/span&gt;&lt;/p&gt;\n&lt;p style=&quot;text-align:center;&quot;&gt;\n	&lt;span style=&quot;font-size:14px;&quot;&gt;&lt;strong&gt;Phê duyệt Kế hoạch tổng thể phát triển thương mại điện tử&lt;/strong&gt;&lt;/span&gt;&lt;/p&gt;\n&lt;p style=&quot;text-align:center;&quot;&gt;\n	&lt;span style=&quot;font-size:14px;&quot;&gt;&lt;strong&gt;giai đoạn 2011 - 2015&lt;/strong&gt;&lt;/span&gt;&lt;/p&gt;\n&lt;p style=&quot;text-align:center;&quot;&gt;\n	&lt;span style=&quot;font-size:14px;&quot;&gt;&lt;strong&gt;_________&lt;/strong&gt;&lt;/span&gt;&lt;/p&gt;\n&lt;p&gt;\n	 &lt;/p&gt;\n&lt;p style=&quot;text-align:center;&quot;&gt;\n	&lt;span style=&quot;font-size:18px;&quot;&gt;&lt;strong&gt;THỦ TƯỚNG CHÍNH PHỦ&lt;/strong&gt;&lt;/span&gt;&lt;/p&gt;\n&lt;p&gt;\n	&lt;strong&gt;Căn cứ Luật Tổ chức Chính phủ ngày 25 tháng 12 năm 2001;&lt;/strong&gt;&lt;/p&gt;\n&lt;p&gt;\n	&lt;strong&gt;Căn cứ Luật Giao dịch điện tử ngày 29 tháng 11 năm 2005;&lt;/strong&gt;&lt;/p&gt;\n&lt;p&gt;\n	&lt;strong&gt;Căn cứ Luật Công nghệ thông tin ngày 29 tháng 6 năm 2006;&lt;/strong&gt;&lt;/p&gt;\n&lt;p&gt;\n	&lt;strong&gt;Căn cứ Nghị định số 57/2006/NĐ-CP ngày 09 tháng 6 năm 2006 của Chính phủ về thương mại điện tử;&lt;/strong&gt;&lt;/p&gt;\n&lt;p&gt;\n	&lt;strong&gt;Xét đề nghị của Bộ trưởng Bộ Công Thương,&lt;/strong&gt;&lt;/p&gt;\n&lt;p&gt;\n	&lt;strong&gt;QUYẾT ĐỊNH:&lt;/strong&gt;&lt;/p&gt;\n&lt;p&gt;\n	&lt;strong&gt;Điều 1. Phê duyệt Kế hoạch tổng thể phát triển thương mại điện tử giai đoạn 2011 - 2015 với mục tiêu và nội dung chủ yếu sau:&lt;/strong&gt;&lt;/p&gt;\n&lt;p&gt;\n	&lt;strong&gt;A. MỤC TIÊU&lt;/strong&gt;&lt;/p&gt;\n&lt;p&gt;\n	&lt;strong&gt;I. Mục tiêu tổng quát&lt;/strong&gt;&lt;/p&gt;\n&lt;p&gt;\n	&lt;strong&gt;Thương mại điện tử được sử dụng phổ biến và đạt mức tiên tiến trong các nước thuộc Hiệp hội các quốc gia Đông Nam Á (ASEAN), góp phần nâng cao năng lực cạnh tranh của doanh nghiệp và năng lực cạnh tranh quốc gia, thúc đẩy quá trình công nghiệp hóa, hiện đại hóa đất nước.&lt;/strong&gt;&lt;/p&gt;\n&lt;p&gt;\n	&lt;strong&gt;II. Mục tiêu cụ thể&lt;/strong&gt;&lt;/p&gt;\n&lt;p&gt;\n	&lt;strong&gt;Các mục tiêu cụ thể cần đạt được vào năm 2015:&lt;/strong&gt;&lt;/p&gt;\n&lt;p&gt;\n	&lt;strong&gt;1. Tất cả doanh nghiệp lớn tiến hành giao dịch thương mại điện tử loại hình doanh nghiệp với doanh nghiệp, trong đó:&lt;/strong&gt;&lt;/p&gt;\n&lt;p&gt;\n	&lt;strong&gt;a) 100% doanh nghiệp sử dụng thường xuyên thư điện tử trong hoạt động sản xuất kinh doanh;&lt;/strong&gt;&lt;/p&gt;\n&lt;p&gt;\n	&lt;strong&gt;b) 80% doanh nghiệp có trang thông tin điện tử, cập nhật thường xuyên thông tin hoạt động và quảng bá sản phẩm của doanh nghiệp;&lt;/strong&gt;&lt;/p&gt;\n&lt;p&gt;\n	&lt;strong&gt;c) 70% doanh nghiệp tham gia các trang thông tin điện tử bán hàng (gọi tắt là website thương mại điện tử) để mua bán các sản phẩm hàng hóa và dịch vụ liên quan tới hoạt động sản xuất kinh doanh của doanh nghiệp;&lt;/strong&gt;&lt;/p&gt;\n&lt;p&gt;\n	&lt;strong&gt;d) 5% doanh nghiệp tham gia các mạng kinh doanh điện tử theo mô hình trao đổi chứng từ điện tử dựa trên chuẩn trao đổi dữ liệu điện tử;&lt;/strong&gt;&lt;/p&gt;\n&lt;p&gt;\n	&lt;strong&gt;đ) 20% doanh nghiệp ứng dụng các phần mềm chuyên dụng trong hoạt động quản lý sản xuất và kinh doanh;&lt;/strong&gt;&lt;/p&gt;\n&lt;p&gt;\n	&lt;strong&gt;e) Hình thành một số sở giao dịch hàng hóa trực tuyến đối với những sản phẩm sản xuất tại Việt Nam chiếm tỷ trọng cao trên thị trường thế giới;&lt;/strong&gt;&lt;/p&gt;\n&lt;p&gt;\n	&lt;strong&gt;g) Hình thành một số doanh nghiệp kinh doanh dịch vụ thương mại điện tử lớn có uy tín trong nước và khu vực.&lt;/strong&gt;&lt;/p&gt;\n&lt;p&gt;\n	&lt;strong&gt;2. Tất cả doanh nghiệp nhỏ và vừa tiến hành giao dịch thương mại điện tử loại hình doanh nghiệp với người tiêu dùng hoặc doanh nghiệp với doanh nghiệp, trong đó:&lt;/strong&gt;&lt;/p&gt;\n&lt;p&gt;\n	&lt;strong&gt;a) 100% doanh nghiệp sử dụng thư điện tử trong hoạt động sản xuất  kinh doanh;&lt;/strong&gt;&lt;/p&gt;\n&lt;p&gt;\n	&lt;strong&gt;b) 45% doanh nghiệp có trang thông tin điện tử, cập nhật định kỳ thông tin hoạt động và quảng bá sản phẩm của doanh nghiệp;&lt;/strong&gt;&lt;/p&gt;\n&lt;p&gt;\n	&lt;strong&gt;c) 30% doanh nghiệp tham gia các website thương mại điện tử để mua bán các sản phẩm hàng hóa và dịch vụ liên quan tới hoạt động sản xuất kinh doanh của doanh nghiệp.&lt;/strong&gt;&lt;/p&gt;\n&lt;p&gt;\n	&lt;strong&gt;3. Bước đầu hình thành các tiện ích hỗ trợ người tiêu dùng tham gia thương mại điện tử loại hình doanh nghiệp với người tiêu dùng, trong đó:&lt;/strong&gt;&lt;/p&gt;\n&lt;p&gt;\n	&lt;strong&gt;a) 70% các siêu thị, trung tâm mua sắm và cơ sở phân phối hiện đại cho phép người tiêu dùng thanh toán không dùng tiền mặt khi mua hàng;&lt;/strong&gt;&lt;/p&gt;\n&lt;p&gt;\n	&lt;strong&gt;b) 50% các đơn vị cung cấp dịch vụ điện, nước, viễn thông và truyền thông chấp nhận thanh toán phí dịch vụ của các hộ gia đình qua phương tiện điện tử;&lt;/strong&gt;&lt;/p&gt;\n&lt;p&gt;\n	&lt;strong&gt;c) 30% cơ sở kinh doanh trong các lĩnh vực thương mại dịch vụ như vận tải, văn hóa, thể thao và du lịch phát triển các kênh giao dịch điện tử phục vụ người tiêu dùng.&lt;/strong&gt;&lt;/p&gt;\n&lt;p&gt;\n	&lt;strong&gt;4. Phần lớn dịch vụ công liên quan tới hoạt động sản xuất kinh doanh được cung cấp trực tuyến, trong đó:&lt;/strong&gt;&lt;/p&gt;\n&lt;p&gt;\n	&lt;strong&gt;a) Cung cấp trực tuyến từ mức độ 3 trở lên 80% dịch vụ công liên quan tới xuất nhập khẩu trước năm 2013, 40% đạt mức 4 vào năm 2015;&lt;/strong&gt;&lt;/p&gt;\n&lt;p&gt;\n	&lt;strong&gt;b) Cung cấp trực tuyến từ mức độ 3 trở lên dịch vụ thủ tục hải quan điện tử trước năm 2013;&lt;/strong&gt;&lt;/p&gt;\n&lt;p&gt;\n	&lt;strong&gt;c) Cung cấp trực tuyến từ mức độ 3 trở lên các dịch vụ liên quan tới thuế, bao gồm khai nộp thuế giá trị gia tăng và thuế thu nhập cá nhân trước năm 2013;&lt;/strong&gt;&lt;/p&gt;\n&lt;p&gt;\n	&lt;strong&gt;d) Cung cấp trực tuyến từ mức độ 3 trở lên các thủ tục đăng ký kinh doanh và đầu tư trước năm 2013, bao gồm thủ tục cấp giấy chứng nhận đăng ký doanh nghiệp, cấp giấy chứng nhận đầu tư, cấp giấy chứng nhận đăng ký hoạt động chi nhánh, văn phòng đại diện;&lt;/strong&gt;&lt;/p&gt;\n&lt;p&gt;\n	&lt;strong&gt;đ) Cung cấp trực tuyến từ mức độ 3 trở lên 50% các dịch vụ công liên quan tới thương mại và hoạt động sản xuất kinh doanh trước năm 2014, đến hết năm 2015 có 20% đạt mức độ 4.&lt;/strong&gt;&lt;/p&gt;\n&lt;p&gt;\n	&lt;strong&gt;B. NỘI DUNG&lt;/strong&gt;&lt;/p&gt;\n&lt;p&gt;\n	&lt;strong&gt;I. Hoàn thiện hệ thống văn bản quy phạm pháp luật về thương mại điện tử&lt;/strong&gt;&lt;/p&gt;\n&lt;p&gt;\n	&lt;strong&gt;Rà soát, bổ sung, sửa đổi và ban hành mới các chính sách, văn bản quy phạm pháp luật để hỗ trợ, tạo điều kiện cho sự phát triển của thương mại điện tử và phù hợp với thông lệ quốc tế và các cam kết quốc tế của Việt Nam.&lt;/strong&gt;&lt;/p&gt;\n&lt;p&gt;\n	&lt;strong&gt;1. Các văn bản quy phạm pháp luật liên quan tới việc thừa nhận giá trị pháp lý của chứng từ điện tử:&lt;/strong&gt;&lt;/p&gt;\n&lt;p&gt;\n	&lt;strong&gt;a) Văn bản quy phạm pháp luật thừa nhận giá trị pháp lý của hóa đơn, chứng từ kế toán ở dạng chứng từ điện tử khi đáp ứng các tiêu chuẩn cụ thể để hỗ trợ doanh nghiệp thực hiện các nghiệp vụ thuế và kế toán khi triển khai hoạt động mua, bán trực tuyến hàng hóa hoặc dịch vụ;&lt;/strong&gt;&lt;/p&gt;\n&lt;p&gt;\n	&lt;strong&gt;b) Văn bản quy phạm pháp luật thừa nhận giá trị pháp lý của hồ sơ, đơn, giấy xác nhận ở dạng chứng từ điện tử khi đáp ứng các tiêu chuẩn cụ thể để hỗ trợ thực hiện một phần hoặc toàn bộ quy trình đăng ký kinh doanh, đăng ký đầu tư, đấu thầu mua sắm qua các phương tiện điện tử;&lt;/strong&gt;&lt;/p&gt;\n&lt;p&gt;\n	&lt;strong&gt;c) Văn bản quy phạm pháp luật thừa nhận giá trị pháp lý của chứng từ hợp đồng mua bán hàng hóa và cung ứng dịch vụ, các loại giấy phép hay chứng nhận khác ở dạng chứng từ điện tử khi đáp ứng các tiêu chuẩn cụ thể để thuận lợi hóa thương mại quốc tế và triển khai thương mại không giấy tờ (paperless trading).&lt;/strong&gt;&lt;/p&gt;\n&lt;p&gt;\n	&lt;strong&gt;2. Văn bản quy phạm pháp luật quy định kinh doanh dịch vụ thương mại điện tử là một ngành, nghề kinh doanh có mã đăng ký riêng.&lt;/strong&gt;&lt;/p&gt;\n&lt;p&gt;\n	&lt;strong&gt;3. Các văn bản quy phạm pháp luật về thuế:&lt;/strong&gt;&lt;/p&gt;\n&lt;p&gt;\n	&lt;strong&gt;a) Các chính sách, văn bản quy phạm pháp luật ưu đãi về thuế giá trị gia tăng và thuế thu nhập doanh nghiệp để tạo môi trường thuận lợi cho các doanh nghiệp kinh doanh thương mại điện tử và khuyến khích người tiêu dùng mua bán trực tuyến;&lt;/strong&gt;&lt;/p&gt;\n&lt;p&gt;\n	&lt;strong&gt;b) Các quy định về mã sản phẩm và trị giá tính thuế hải quan đối với xuất khẩu, nhập khẩu các sản phẩm số hóa phù hợp với thông lệ quốc tế và các cam kết quốc tế của Việt Nam.&lt;/strong&gt;&lt;/p&gt;\n&lt;p&gt;\n	&lt;strong&gt;4. Văn bản quy phạm pháp luật về bảo vệ người tiêu dùng: các quy định bảo vệ người tiêu dùng và bảo đảm cho người tiêu dùng khi tham gia giao dịch thương mại điện tử được bảo vệ về mặt luật pháp theo chuẩn mực quốc tế như trong giao dịch thương mại truyền thống.&lt;/strong&gt;&lt;/p&gt;\n&lt;p&gt;\n	&lt;strong&gt;5. Văn bản quy phạm pháp luật về quản lý website thương mại điện tử: các quy định về đăng ký, quản lý website thương mại điện tử trên cơ sở tạo lập môi trường kinh doanh minh bạch, cạnh tranh.&lt;/strong&gt;&lt;/p&gt;\n&lt;p&gt;\n	&lt;strong&gt;6. Văn bản quy phạm pháp luật về an toàn thông tin:&lt;/strong&gt;&lt;/p&gt;\n&lt;p&gt;\n	&lt;strong&gt;a) Văn bản quy phạm pháp luật về an toàn thông tin trong giao dịch thương mại điện tử;&lt;/strong&gt;&lt;/p&gt;\n&lt;p&gt;\n	&lt;strong&gt;b) Các tiêu chuẩn, quy chuẩn kỹ thuật quốc gia áp dụng đối với các bên tham gia giao dịch thương mại điện tử phù hợp với quy mô giao dịch và chuẩn mực quốc gia và quốc tế;  &lt;/strong&gt;&lt;/p&gt;\n&lt;p&gt;\n	&lt;strong&gt;c) Văn bản quy phạm pháp luật quy định về bảo vệ thông tin cá nhân phù hợp pháp luật liên quan, đảm bảo thông tin cá nhân trong giao dịch thương mại điện tử được bảo vệ về mặt luật pháp theo chuẩn mực quốc tế và các cam kết quốc tế của Việt Nam.&lt;/strong&gt;&lt;/p&gt;\n&lt;p&gt;\n	&lt;strong&gt;7. Văn bản quy phạm pháp luật về giải quyết tranh chấp, vi phạm pháp luật trong thương mại điện tử:&lt;/strong&gt;&lt;/p&gt;\n&lt;p&gt;\n	&lt;strong&gt;a) Văn bản quy phạm pháp luật quy định giá trị pháp lý làm chứng cứ của chứng từ điện tử;&lt;/strong&gt;&lt;/p&gt;\n&lt;p&gt;\n	&lt;strong&gt;b) Văn bản quy phạm pháp luật về giải quyết tranh chấp bằng trọng tài trong hoạt động thương mại điện tử, bao gồm cơ chế giải quyết tranh chấp trực tuyến;&lt;/strong&gt;&lt;/p&gt;\n&lt;p&gt;\n	&lt;strong&gt;c) Chế tài đối với các hành vi vi phạm pháp luật về thương mại điện tử; thẩm quyền và cơ chế thanh tra, kiểm tra và xử lý vi phạm hành chính về thương mại điện tử của cơ quan quản lý nhà nước về thương mại điện tử;&lt;/strong&gt;&lt;/p&gt;\n&lt;p&gt;\n	&lt;strong&gt;d) Các tội phạm trong lĩnh vực công nghệ cao và trong thương mại điện tử vào Bộ Luật Hình sự.&lt;/strong&gt;&lt;/p&gt;\n&lt;p&gt;\n	&lt;strong&gt;8. Các văn bản quy phạm pháp luật khác:&lt;/strong&gt;&lt;/p&gt;\n&lt;p&gt;\n	&lt;strong&gt;a) Văn bản quy phạm pháp luật về sở hữu trí tuệ phù hợp thông lệ quốc tế và tạo thuận lợi cho sự phát triển của thương mại điện tử;&lt;/strong&gt;&lt;/p&gt;\n&lt;p&gt;\n	&lt;strong&gt;b) Văn bản quy phạm pháp luật điều chỉnh các đối tượng phát sinh trong hoạt động thương mại điện tử;&lt;/strong&gt;&lt;/p&gt;\n&lt;p&gt;\n	&lt;strong&gt;c) Các chính sách, văn bản quy phạm pháp luật khuyến khích các hoạt động kinh doanh dịch vụ trực tuyến;&lt;/strong&gt;&lt;/p&gt;\n&lt;p&gt;\n	&lt;strong&gt;d) Các chính sách, văn bản quy phạm pháp luật để triển khai các mô hình thanh toán trực tuyến.&lt;/strong&gt;&lt;/p&gt;\n&lt;p&gt;\n	&lt;strong&gt;II. Phát triển nguồn nhân lực về thương mại điện tử&lt;/strong&gt;&lt;/p&gt;\n&lt;p&gt;\n	&lt;strong&gt;1. Phổ biến, tuyên truyền nâng cao nhận thức về lợi ích của thương mại điện tử:&lt;/strong&gt;&lt;/p&gt;\n&lt;p&gt;\n	&lt;strong&gt;a) Xây dựng các chương trình tập huấn cán bộ quản lý kinh tế ở Trung ương và địa phương và các chương trình bồi dưỡng chuyên sâu cho đội ngũ cán bộ chuyên trách về thương mại điện tử;&lt;/strong&gt;&lt;/p&gt;\n&lt;p&gt;\n	&lt;strong&gt;b) Phổ biến, tuyên truyền về lợi ích và kỹ năng ứng dụng thương mại điện tử cho các doanh nghiệp, người tiêu dùng các ngành sản xuất và dịch vụ chính; quảng bá các doanh nghiệp điển hình thành công trong ứng dụng và cung cấp dịch vụ thương mại điện tử.&lt;/strong&gt;&lt;/p&gt;\n&lt;p&gt;\n	&lt;strong&gt;2. Đẩy mạnh đào tạo chính quy về thương mại điện tử:&lt;/strong&gt;&lt;/p&gt;\n&lt;p&gt;\n	&lt;strong&gt;a) Ban hành chương trình khung về đào tạo thương mại điện tử trong các trường đại học, cao đẳng và trung học chuyên nghiệp; tăng cường giảng dạy kỹ năng ứng dụng thương mại điện tử trong các trường dạy nghề;&lt;/strong&gt;&lt;/p&gt;\n&lt;p&gt;\n	&lt;strong&gt;b) Ứng dụng đào tạo trực tuyến trong hoạt động đào tạo thương mại điện tử theo hướng khuyến khích các tổ chức đầu tư, phát triển công nghệ đào tạo trực tuyến, hỗ trợ các trường đại học và doanh nghiệp liên kết trong việc thiết kế nội dung, giáo trình đào tạo trực tuyến. Hỗ trợ về vốn và các ưu đãi về thuế nhằm đẩy nhanh hình thức đào tạo trực tuyến.&lt;/strong&gt;&lt;/p&gt;\n&lt;p&gt;\n	&lt;strong&gt;III. Cung cấp trực tuyến các dịch vụ công liên quan tới hoạt động sản xuất kinh doanh&lt;/strong&gt;&lt;/p&gt;\n&lt;p&gt;\n	&lt;strong&gt;Đẩy mạnh cung cấp trực tuyến các dịch vụ công liên quan tới hoạt động sản xuất kinh doanh theo đúng các cam kết quốc tế về thương mại không giấy tờ trong các lĩnh vực:&lt;/strong&gt;&lt;/p&gt;\n&lt;p&gt;\n	&lt;strong&gt;1. Thuế, hải quan, xuất nhập khẩu, đầu tư, đăng ký kinh doanh và các dịch vụ công khác liên quan trực tiếp tới hoạt động sản xuất kinh doanh.&lt;/strong&gt;&lt;/p&gt;\n&lt;p&gt;\n	&lt;strong&gt;2. Cung cấp trực tuyến thông tin về thị trường nước ngoài bằng tiếng Việt cho các doanh nghiệp Việt Nam và thông tin về thị trường Việt Nam cho các doanh nghiệp nước ngoài bằng tiếng Anh và một số tiếng nước ngoài phổ biến khác.&lt;/strong&gt;&lt;/p&gt;\n&lt;p&gt;\n	&lt;strong&gt;3. Trao đổi các chứng từ điện tử liên quan tới hoạt động quản lý xuất nhập khẩu hàng hóa và dịch vụ với nước ngoài.&lt;/strong&gt;&lt;/p&gt;\n&lt;p&gt;\n	&lt;strong&gt;4. Cung cấp thông tin về các dự án sử dụng vốn nhà nước, thông tin về đấu thầu trong mua sắm chính phủ và từng bước tiến hành đấu thầu mua sắm chính phủ trực tuyến:&lt;/strong&gt;&lt;/p&gt;\n&lt;p&gt;\n	&lt;strong&gt;a) Trước năm 2012, tất cả các cơ quan nhà nước từ Trung ương tới địa phương cung cấp thông tin về các dự án sử dụng vốn nhà nước, thông tin về đấu thầu trong mua sắm chính phủ lên trang thông tin điện tử của mình hoặc của cơ quan chức năng;&lt;/strong&gt;&lt;/p&gt;\n&lt;p&gt;\n	&lt;strong&gt;b) Đến hết năm 2015, tất cả kế hoạch đấu thầu, thông báo mời thầu, kết quả đấu thầu, danh sách nhà thầu tham gia được đăng tải trên mạng đấu thầu quốc gia; khoảng 20% số gói thầu mua sắm hàng hóa, xây lắp và dịch vụ tư vấn sử dụng vốn nhà nước được thực hiện qua mạng; thí điểm hình thức mua sắm chính phủ tập trung trên hệ thống mạng đấu thầu quốc gia.&lt;/strong&gt;&lt;/p&gt;\n&lt;p&gt;\n	&lt;strong&gt;5. Công khai thông tin liên quan tới doanh nghiệp và hoạt động sản xuất kinh doanh:&lt;/strong&gt;&lt;/p&gt;\n&lt;p&gt;\n	&lt;strong&gt;a) Công khai và tạo điều kiện thuận lợi cho doanh nghiệp tiếp cận các thông tin liên quan tới doanh nghiệp, bao gồm cơ sở dữ liệu về đăng ký thành lập, chia tách, sáp nhập, giải thể, phá sản doanh nghiệp; cơ sở dữ liệu về thuế; cơ sở dữ liệu về quản lý xuất nhập khẩu như khai hải quan, chứng nhận xuất xứ, cấp phép nhập khẩu; cơ sở dữ liệu về quản lý thị trường và quản lý cạnh tranh;&lt;/strong&gt;&lt;/p&gt;\n&lt;p&gt;\n	&lt;strong&gt;b) Kết nối trực tuyến các cơ sở dữ liệu liên quan tới doanh nghiệp giữa Bộ Tài chính, Bộ Kế hoạch và Đầu tư, Bộ Công Thương và các Bộ, ngành khác trước năm 2015.&lt;/strong&gt;&lt;/p&gt;\n&lt;p&gt;\n	&lt;strong&gt;IV. Phát triển và ứng dụng công nghệ, dịch vụ thương mại điện tử&lt;/strong&gt;&lt;/p&gt;\n&lt;p&gt;\n	&lt;strong&gt;1. Ban hành các chính sách, biện pháp khuyến khích đầu tư phát triển và chuyển giao công nghệ hỗ trợ thương mại điện tử:&lt;/strong&gt;&lt;/p&gt;\n&lt;p&gt;\n	&lt;strong&gt;a) Chính sách khuyến khích doanh nghiệp sử dụng phần mềm mã nguồn mở khi triển khai các ứng dụng thương mại điện tử;&lt;/strong&gt;&lt;/p&gt;\n&lt;p&gt;\n	&lt;strong&gt;b) Chính sách và giải pháp khuyến khích người tiêu dùng mua bán trực tuyến các sản phẩm số hoá; thúc đẩy phát triển thương mại điện tử và công nghiệp nội dung số;&lt;/strong&gt;&lt;/p&gt;\n&lt;p&gt;\n	&lt;strong&gt;c) Khuyến khích các tổ chức, doanh nghiệp kinh doanh dịch vụ cho thuê thiết bị tính toán, phần mềm và các dịch vụ công nghệ thông tin và viễn thông khác;&lt;/strong&gt;&lt;/p&gt;\n&lt;p&gt;\n	&lt;strong&gt;d) Khuyến khích phát triển hoạt động thương mại dựa trên công nghệ di động (mobile commerce), các dịch vụ số hóa cung cấp thông qua các thiết bị đầu cuối di động (điện thoại di động, thiết bị dữ liệu cá nhân PDA, thiết bị vi tính bỏ túi pocket PC, v.v…);&lt;/strong&gt;&lt;/p&gt;\n&lt;p&gt;\n	&lt;strong&gt;đ) Khuyến khích nghiên cứu, chuyển giao công nghệ phục vụ phát triển thanh toán trực tuyến; khuyến khích các doanh nghiệp phát triển các tiện ích thanh toán qua phương tiện điện tử hỗ trợ người mua hàng.&lt;/strong&gt;&lt;/p&gt;\n&lt;p&gt;\n	&lt;strong&gt;2. Phát triển các dịch vụ tích hợp dựa trên công nghệ tiên tiến:&lt;/strong&gt;&lt;/p&gt;\n&lt;p&gt;\n	&lt;strong&gt;a) Khuyến khích cung cấp trên cơ sở thương mại các dịch vụ dựa vào Hệ thống thông tin địa lý (GIS), Hệ thống định vị toàn cầu (GPS);&lt;/strong&gt;&lt;/p&gt;\n&lt;p&gt;\n	&lt;strong&gt;b) Nghiên cứu, phát triển và chuyển giao các công nghệ được sử dụng nhiều trong hoạt động thương mại (công nghệ nhận dạng theo tần số radio RFID, mã số mã vạch, thẻ thông minh, v.v…).&lt;/strong&gt;&lt;/p&gt;\n&lt;p&gt;\n	&lt;strong&gt;3. Ban hành và phổ biến các tiêu chuẩn, quy chuẩn sử dụng trong thương mại điện tử:&lt;/strong&gt;&lt;/p&gt;\n&lt;p&gt;\n	&lt;strong&gt;a) Các tiêu chuẩn, quy chuẩn kỹ thuật quốc gia về chuẩn trao đổi dữ liệu điện tử ứng dụng trong thương mại điện tử tới các doanh nghiệp và các tổ chức đào tạo về thương mại điện tử;&lt;/strong&gt;&lt;/p&gt;\n&lt;p&gt;\n	&lt;strong&gt;b) Hỗ trợ thí điểm một số doanh nghiệp ứng dụng chuẩn trao đổi dữ liệu điện tử trong hoạt động sản xuất kinh doanh để tạo mạng kinh doanh điện tử giữa các doanh nghiệp này và nhân rộng mô hình mạng kinh doanh điện tử tới nhiều doanh nghiệp.&lt;/strong&gt;&lt;/p&gt;\n&lt;p&gt;\n	&lt;strong&gt;4. Phát triển các hoạt động thương mại dựa trên công nghệ thẻ trong các dịch vụ giao thông công cộng, phân phối, văn hóa, thể thao, giải trí, du lịch.&lt;/strong&gt;&lt;/p&gt;\n&lt;p&gt;\n	&lt;strong&gt;5. Triển khai các hoạt động về an toàn thông tin trong giao dịch thương mại điện tử theo các mục tiêu, giải pháp trong Quy hoạch phát triển an toàn thông tin số quốc gia.&lt;/strong&gt;&lt;/p&gt;\n&lt;p&gt;\n	&lt;strong&gt;a) Nâng cao nhận thức về tầm quan trọng của an toàn thông tin, quyền lợi, nghĩa vụ và trách nhiệm của các bên tham gia giao dịch thương mại điện tử trong việc đảm bảo an toàn thông tin, lợi ích của việc sử dụng chữ ký số và dịch vụ chứng thực chữ ký số trong hoạt động thương mại điện tử;&lt;/strong&gt;&lt;/p&gt;\n&lt;p&gt;\n	&lt;strong&gt;b) Phát triển các tổ chức cung cấp dịch vụ chứng thực chữ ký số công cộng để đến năm 2015 có một số tổ chức của Việt Nam được các tổ chức chứng thực chữ ký số có uy tín của nước ngoài thừa nhận;&lt;/strong&gt;&lt;/p&gt;\n&lt;p&gt;\n	&lt;strong&gt;c) Phát triển các tổ chức cung cấp dịch vụ chứng thực cho website thương mại điện tử; khuyến khích các tổ chức, doanh nghiệp, cá nhân ứng dụng các công nghệ bảo mật tiên tiến để thông tin trao đổi trên môi trường mạng máy tính được đảm bảo an toàn;&lt;/strong&gt;&lt;/p&gt;\n&lt;p&gt;\n	&lt;strong&gt;d) Đẩy mạnh hoạt động cấp chứng nhận website thương mại điện tử uy tín để đến năm 2015, có ít nhất 5% website thương mại điện tử được cấp chứng nhận website thương mại điện tử uy tín; phổ biến lợi ích của hoạt động này đối với các doanh nghiệp và người tiêu dùng; khuyến khích các tổ chức cấp chứng nhận website thương mại điện tử uy tín hợp tác, trao đổi kinh nghiệm với các tổ chức cấp chứng nhận website thương mại điện tử uy tín của nước ngoài và thừa nhận lẫn nhau về nhãn tín nhiệm (trustmark).&lt;/strong&gt;&lt;/p&gt;\n&lt;p&gt;\n	&lt;strong&gt;V. Nâng cao hiệu quả và năng lực quản lý nhà nước&lt;/strong&gt;&lt;/p&gt;\n&lt;p&gt;\n	&lt;strong&gt;1. Nâng cao năng lực quản lý nhà nước về thương mại điện tử tại các địa phương:&lt;/strong&gt;&lt;/p&gt;\n&lt;p&gt;\n	&lt;strong&gt;Ủy ban nhân dân các tỉnh, thành phố trực thuộc Trung ương chỉ đạo cơ quan chức năng tăng cường quản lý nhà nước về thương mại điện tử; chủ động tạo môi trường thuận lợi cho các doanh nghiệp tại địa phương ứng dụng thương mại điện tử; tăng cường hỗ trợ doanh nghiệp ứng dụng thương mại điện tử vào hoạt động quảng bá, tiếp thị, giới thiệu sản phẩm, tham gia giao dịch trực tuyến, đổi mới phương thức kinh doanh, cải tiến quy trình quản lý.&lt;/strong&gt;&lt;/p&gt;\n&lt;p&gt;\n	&lt;strong&gt;2. Xây dựng lực lượng cán bộ có chuyên môn đáp ứng được công tác quản lý nhà nước về thương mại điện tử ở Trung ương và địa phương. Thường xuyên tổ chức bồi dưỡng, nâng cao kiến thức và có kế hoạch đào tạo chuyên sâu cho cán bộ chuyên trách thương mại điện tử cấp Sở; tăng cường trao đổi, học tập kinh nghiệm từ các quốc gia tiên tiến về thương mại điện tử, liên kết hợp tác trong các chương trình đào tạo nguồn nhân lực cho cơ quan quản lý nhà nước về thương mại điện tử.&lt;/strong&gt;&lt;/p&gt;\n&lt;p&gt;\n	&lt;strong&gt;3. Xây dựng cơ chế, bộ máy phù hợp để giải quyết kịp thời những tranh chấp và vấn đề phát sinh trong thương mại điện tử; nâng cao năng lực của bộ máy thực thi pháp luật để xử lý kịp thời các hành vi vi phạm trong thương mại điện tử.&lt;/strong&gt;&lt;/p&gt;\n&lt;p&gt;\n	&lt;strong&gt;a) Hỗ trợ các tổ chức cung cấp dịch vụ cấp chứng nhận website thương mại điện tử uy tín xây dựng quy trình, bộ máy giải quyết tranh chấp theo quy định của pháp luật hiện hành và thông lệ quốc tế;&lt;/strong&gt;&lt;/p&gt;\n&lt;p&gt;\n	&lt;strong&gt;b) Khuyến khích Hiệp hội Thương mại điện tử Việt Nam và các tổ chức xã hội nghề nghiệp tham gia các hình thức giải quyết tranh chấp trên cơ sở hòa giải và tuân thủ pháp luật, nhằm bảo vệ lợi ích hợp pháp của người tiêu dùng;&lt;/strong&gt;&lt;/p&gt;\n&lt;p&gt;\n	&lt;strong&gt;c) Nâng cao năng lực của Trọng tài thương mại;&lt;/strong&gt;&lt;/p&gt;\n&lt;p&gt;\n	&lt;strong&gt;d) Thành lập Tổ chức thanh tra chuyên ngành về thương mại điện tử;&lt;/strong&gt;&lt;/p&gt;\n&lt;p&gt;\n	&lt;strong&gt;đ) Đào tạo, nâng cao năng lực chuyên môn cho cán bộ thuộc các ngành công an, tòa án, kiểm sát để xử lý đúng pháp luật các hành vi vi phạm trong hoạt động thương mại điện tử.&lt;/strong&gt;&lt;/p&gt;\n&lt;p&gt;\n	&lt;strong&gt;4. Triển khai hoạt động thống kê về thương mại điện tử và các hoạt động hỗ trợ thương mại điện tử:&lt;/strong&gt;&lt;/p&gt;\n&lt;p&gt;\n	&lt;strong&gt;a) Trước năm 2012 ban hành các tiêu chí, phương pháp thống kê thương mại điện tử theo đúng quy định tại Luật Thống kê. Kiện toàn bộ máy tổ chức từ Trung ương tới địa phương để triển khai hoạt động thống kê về thương mại điện tử;&lt;/strong&gt;&lt;/p&gt;\n&lt;p&gt;\n	&lt;strong&gt;b) Từ năm 2012 công bố Sách trắng về thương mại điện tử Việt Nam với các số liệu thống kê tình hình triển khai ứng dụng thương mại điện tử trên toàn quốc, nhằm hỗ trợ hoạt động quản lý nhà nước, hoạt động kinh doanh và hội nhập quốc tế về thương mại điện tử;&lt;/strong&gt;&lt;/p&gt;\n&lt;p&gt;\n	&lt;strong&gt;c) Hỗ trợ Hiệp hội Thương mại điện tử Việt Nam và các tổ chức xã hội nghề nghiệp xây dựng chỉ số sẵn sàng ứng dụng thương mại điện tử theo doanh nghiệp và địa phương, xếp hạng website thương mại điện tử.&lt;/strong&gt;&lt;/p&gt;\n&lt;p&gt;\n	&lt;strong&gt;5. Tăng cường hợp tác quốc tế về thương mại điện tử:&lt;/strong&gt;&lt;/p&gt;\n&lt;p&gt;\n	&lt;strong&gt;a) Chủ động tham gia hợp tác quốc tế về thương mại điện tử và các lĩnh vực liên quan với các tổ chức kinh tế thương mại quốc tế và khu vực, các tổ chức thương mại của Liên Hiệp quốc, các tổ chức thương mại đa phương, song phương và các đối tác thương mại khác;&lt;/strong&gt;&lt;/p&gt;\n&lt;p&gt;\n	&lt;strong&gt;b) Khuyến khích các tổ chức xã hội nghề nghiệp, các doanh nghiệp hợp tác với các đối tác nước ngoài tạo môi trường phát triển thương mại điện tử quốc tế, tăng cường hoạt động kinh doanh trực tuyến qua biên giới và chuyển giao công nghệ.&lt;/strong&gt;&lt;/p&gt;\n&lt;p&gt;\n	&lt;strong&gt;6. Đẩy mạnh hoạt động xây dựng chính sách, chương trình, dự án tổng thể hỗ trợ cộng đồng doanh nghiệp hiện diện trên môi trường Internet, xây dựng thương hiệu trực tuyến, triển khai hoạt động tiếp thị điện tử… nhằm giúp doanh nghiệp thay đổi phương thức sản xuất kinh doanh, ứng dụng cách thức quản lý và điều hành tiên tiến.&lt;/strong&gt;&lt;/p&gt;\n&lt;p&gt;\n	&lt;strong&gt;7. Xây dựng giải thưởng quốc gia về thương mại điện tử, đưa tiêu chí phát triển thương mại điện tử vào chỉ tiêu đánh giá xếp hạng năng lực cạnh tranh cấp tỉnh của các địa phương.&lt;/strong&gt;&lt;/p&gt;\n&lt;p&gt;\n	&lt;strong&gt;8. Đảm bảo tính đồng bộ và liên thông thông tin giữa các Bộ, ngành trong các hoạt động quản lý nhà nước liên quan đến doanh nghiệp, tiến tới hình thành các cơ sở dữ liệu quốc gia dùng chung cho các lĩnh vực hải quan, thuế, quản lý doanh nghiệp, quản lý hoạt động xuất nhập khẩu, tài chính tín dụng, thống kê. Chia sẻ thông tin về tài nguyên Internet giữa Bộ Thông tin và Truyền thông với Bộ Công Thương nhằm tăng cường công tác quản lý nhà nước đối với các website thương mại điện tử.&lt;/strong&gt;&lt;/p&gt;\n&lt;p&gt;\n	&lt;strong&gt;C. KINH PHÍ THỰC HIỆN&lt;/strong&gt;&lt;/p&gt;\n&lt;p&gt;\n	&lt;strong&gt;I. Nguồn vốn thực hiện Kế hoạch tổng thể được đảm bảo từ các nguồn: vốn ngân sách nhà nước, vốn doanh nghiệp, vốn vay từ các tổ chức tín dụng, tài trợ quốc tế và nguồn vốn huy động hợp pháp khác theo quy định của pháp luật.&lt;/strong&gt;&lt;/p&gt;\n&lt;p&gt;\n	&lt;strong&gt;II. Đối với nguồn vốn ngân sách nhà nước thực hiện theo phân cấp ngân sách nhà nước hiện hành, cụ thể như sau:&lt;/strong&gt;&lt;/p&gt;\n&lt;p&gt;\n	&lt;strong&gt;1. Các dự án, nhiệm vụ thuộc phạm vi chi của các Bộ, cơ quan ngang Bộ, cơ quan thuộc Chính phủ do ngân sách trung ương đảm bảo và được bố trí trong dự toán chi ngân sách hàng năm của cơ quan.&lt;/strong&gt;&lt;/p&gt;\n&lt;p&gt;\n	&lt;strong&gt;2. Các dự án, nhiệm vụ thuộc phạm vi chi của Ủy ban nhân dân tỉnh, thành phố trực thuộc Trung ương do ngân sách địa phương đảm bảo và được bố trí trong ngân sách hàng năm của địa phương.&lt;/strong&gt;&lt;/p&gt;\n&lt;p&gt;\n	&lt;strong&gt;Điều 2. Tổ chức thực hiện&lt;/strong&gt;&lt;/p&gt;\n&lt;p&gt;\n	&lt;strong&gt;1. Kế hoạch tổng thể phát triển thương mại điện tử được tổ chức thực hiện gắn kết và đồng bộ với các chiến lược, quy hoạch, kế hoạch phát triển các lĩnh vực thuộc ngành công thương và các ngành kinh tế, đặc biệt là lĩnh vực xuất khẩu, phân phối và các ngành dịch vụ khác; các chiến lược, quy hoạch, kế hoạch, đề án, chương trình phát triển và ứng dụng công nghệ thông tin và truyền thông; các chương trình cải cách hành chính và ứng dụng công nghệ thông tin trong hoạt động của cơ quan nhà nước.&lt;/strong&gt;&lt;/p&gt;\n&lt;p&gt;\n	&lt;strong&gt;2. Căn cứ Kế hoạch tổng thể này, các Bộ, cơ quan ngang Bộ, cơ quan thuộc Chính phủ, Ủy ban nhân dân tỉnh, thành phố trực thuộc Trung ương có trách nhiệm:&lt;/strong&gt;&lt;/p&gt;\n&lt;p&gt;\n	&lt;strong&gt;a) Xây dựng và tổ chức thẩm định, phê duyệt, bố trí ngân sách theo phân cấp hiện hành để triển khai kế hoạch phát triển thương mại điện tử của Bộ, cơ quan, địa phương mình giai đoạn 2011 - 2015; hàng năm gửi Bộ Công Thương trước ngày 31 tháng 12 để tổng hợp báo cáo Thủ tướng Chính phủ;&lt;/strong&gt;&lt;/p&gt;\n&lt;p&gt;\n	&lt;strong&gt;b) Kiểm tra, đánh giá và báo cáo định kỳ hàng năm và đột xuất tình hình thực hiện Kế hoạch tổng thể này theo hướng dẫn và yêu cầu của Bộ Công Thương để tổng hợp báo cáo Thủ tướng Chính phủ.&lt;/strong&gt;&lt;/p&gt;\n&lt;p&gt;\n	&lt;strong&gt;3. Bộ Công Thương có trách nhiệm:&lt;/strong&gt;&lt;/p&gt;\n&lt;p&gt;\n	&lt;strong&gt;a) Chủ trì, phối hợp các Bộ, cơ quan ngang Bộ, cơ quan thuộc Chính phủ, Ủy ban nhân dân tỉnh, thành phố trực thuộc Trung ương tổ chức triển khai thực hiện Quyết định này, hàng năm tổng hợp tình hình triển khai và đề xuất các giải pháp vượt thẩm quyền trình Thủ tướng Chính phủ quyết định, tổng kết tình hình thực hiện vào năm kết thúc Kế hoạch tổng thể;&lt;/strong&gt;&lt;/p&gt;\n&lt;p&gt;\n	&lt;strong&gt;b) Sửa đổi, bổ sung các văn bản quy phạm pháp luật thuộc lĩnh vực kinh doanh xuất nhập khẩu theo hướng thừa nhận giá trị pháp lý của các chứng từ điện tử; ban hành các văn bản quy phạm pháp luật chi tiết các quy định trong pháp luật bảo vệ người tiêu dùng và các văn bản quy phạm pháp luật liên quan nhằm bảo vệ người tiêu dùng tham gia thương mại điện tử;&lt;/strong&gt;&lt;/p&gt;\n&lt;p&gt;\n	&lt;strong&gt;c) Ban hành, sửa đổi, bổ sung các quy định liên quan tới việc đăng ký, quản lý website thương mại điện tử; các chính sách và văn bản quy phạm pháp luật nhằm khuyến khích các hoạt động kinh doanh dịch vụ trực tuyến;&lt;/strong&gt;&lt;/p&gt;\n&lt;p&gt;\n	&lt;strong&gt;d) Chủ trì, phối hợp với các Bộ ngành liên quan nghiên cứu, đề xuất ban hành các văn bản quy phạm pháp luật điều chỉnh những đối tượng mới phát sinh trong hoạt động thương mại điện tử;&lt;/strong&gt;&lt;/p&gt;\n&lt;p&gt;\n	&lt;strong&gt;đ) Đẩy mạnh cung cấp trực tuyến từ mức độ 3 trở lên các thủ tục liên quan tới xuất nhập khẩu và những dịch vụ công khác liên quan tới thương mại;&lt;/strong&gt;&lt;/p&gt;\n&lt;p&gt;\n	&lt;strong&gt;e) Chủ trì, phối hợp với Ủy ban nhân dân các tỉnh, thành phố trực thuộc Trung ương, Phòng Thương mại và Công nghiệp Việt Nam, Hiệp hội Thương mại điện tử Việt Nam và các tổ chức xã hội nghề nghiệp triển khai các hoạt động tuyên truyền, phổ biến về thương mại điện tử; nghiên cứu xây dựng các mô hình thương mại điện tử và khuyến khích doanh nghiệp tham gia.&lt;/strong&gt;&lt;/p&gt;\n&lt;p&gt;\n	&lt;strong&gt;4. Bộ Thông tin và Truyền thông có trách nhiệm:&lt;/strong&gt;&lt;/p&gt;\n&lt;p&gt;\n	&lt;strong&gt;a) Phối hợp với Bộ Công Thương triển khai đồng bộ Kế hoạch này với các chiến lược, quy hoạch, kế hoạch, đề án, chương trình phát triển công nghệ thông tin và truyền thông, gắn kết sự phát triển của thương mại điện tử với Chính phủ điện tử;&lt;/strong&gt;&lt;/p&gt;\n&lt;p&gt;\n	&lt;strong&gt;b) Ban hành các chính sách, biện pháp khuyến khích đầu tư phát triển và chuyển giao công nghệ hỗ trợ thương mại điện tử;&lt;/strong&gt;&lt;/p&gt;\n&lt;p&gt;\n	&lt;strong&gt;c) Đẩy mạnh việc triển khai dịch vụ chứng thực chữ ký số và triển khai dịch vụ chứng thực cho website thương mại điện tử;&lt;/strong&gt;&lt;/p&gt;\n&lt;p&gt;\n	&lt;strong&gt;d) Chủ trì, phối hợp với Bộ Công Thương và Bộ Công an thực hiện các biện pháp đảm bảo an toàn thông tin trong giao dịch thương mại điện tử.&lt;/strong&gt;&lt;/p&gt;\n&lt;p&gt;\n	&lt;strong&gt;5. Bộ Kế hoạch và Đầu tư có trách nhiệm:&lt;/strong&gt;&lt;/p&gt;\n&lt;p&gt;\n	&lt;strong&gt;a) Chủ trì, phối hợp với Bộ Công Thương bố trí vốn đầu tư phát triển hàng năm cho các Bộ, cơ quan ngang Bộ, cơ quan thuộc Chính phủ để thực hiện các dự án, nhiệm vụ thuộc Kế hoạch tổng thể; gửi Bộ Tài chính để tổng hợp theo quy định của Luật Ngân sách nhà nước;&lt;/strong&gt;&lt;/p&gt;\n&lt;p&gt;\n	&lt;strong&gt;b) Sửa đổi, bổ sung các văn bản quy phạm pháp luật thuộc lĩnh vực đầu tư, đăng ký kinh doanh theo hướng thừa nhận giá trị pháp lý của các hồ sơ ở dạng chứng từ điện tử;&lt;/strong&gt;&lt;/p&gt;\n&lt;p&gt;\n	&lt;strong&gt;c) Đẩy mạnh cung cấp trực tuyến từ mức độ 3 trở lên các thủ tục đăng ký kinh doanh và đầu tư cũng như các thủ tục khác liên quan tới hoạt động sản xuất kinh doanh của doanh nghiệp;&lt;/strong&gt;&lt;/p&gt;\n&lt;p&gt;\n	&lt;strong&gt;d) Rà soát, sửa đổi, bổ sung danh mục ngành, nghề kinh doanh sử dụng trong đăng ký kinh doanh các loại hình kinh doanh dịch vụ thương mại điện tử;&lt;/strong&gt;&lt;/p&gt;\n&lt;p&gt;\n	&lt;strong&gt;đ) Chủ trì triển khai dự án ứng dụng thương mại điện tử trong mua sắm chính phủ; hoàn thiện khung pháp lý về đấu thầu trực tuyến và phối hợp với các Bộ, ngành, địa phương triển khai hoạt động đấu thầu trực tuyến trong mua sắm chính phủ.&lt;/strong&gt;&lt;/p&gt;\n&lt;p&gt;\n	&lt;strong&gt;6. Bộ Tài chính có trách nhiệm:&lt;/strong&gt;&lt;/p&gt;\n&lt;p&gt;\n	&lt;strong&gt;a) Chủ trì, phối hợp với Bộ Công Thương bố trí kinh phí thường xuyên hàng năm cho các Bộ, cơ quan ngang Bộ, cơ quan thuộc Chính phủ để thực hiện các dự án, nhiệm vụ thuộc Kế hoạch tổng thể; tổng hợp chung trình cấp có thẩm quyền quyết định theo quy định của Luật Ngân sách nhà nước;&lt;/strong&gt;&lt;/p&gt;\n&lt;p&gt;\n	&lt;strong&gt;b) Sửa đổi, bổ sung các văn bản quy phạm pháp luật thuộc lĩnh vực tài chính theo hướng thừa nhận giá trị pháp lý của hóa đơn, chứng từ kế toán ở dạng chứng từ điện tử;&lt;/strong&gt;&lt;/p&gt;\n&lt;p&gt;\n	&lt;strong&gt;c) Rà soát, sửa đổi, bổ sung, ban hành mới các văn bản quy phạm pháp luật về thuế theo hướng tạo môi trường thuận lợi cho các doanh nghiệp kinh doanh thương mại điện tử và khuyến khích người tiêu dùng mua bán trực tuyến;&lt;/strong&gt;&lt;/p&gt;\n&lt;p&gt;\n	&lt;strong&gt;d) Chủ trì, phối hợp với các Bộ, ngành liên quan rà soát, sửa đổi, bổ sung các quy định về mã sản phẩm và trị giá tính thuế hải quan đối với xuất khẩu, nhập khẩu các sản phẩm số hóa phù hợp với thông lệ quốc tế và các cam kết quốc tế của Việt Nam;&lt;/strong&gt;&lt;/p&gt;\n&lt;p&gt;\n	&lt;strong&gt;đ) Đẩy mạnh cung cấp trực tuyến từ mức độ 3 trở lên các dịch vụ hải quan, thuế và các thủ tục liên quan tới hoạt động sản xuất kinh doanh của doanh nghiệp.&lt;/strong&gt;&lt;/p&gt;\n&lt;p&gt;\n	&lt;strong&gt;7. Bộ Giáo dục và Đào tạo chủ trì, phối hợp với các Bộ, ngành liên quan xây dựng và ban hành chương trình khung về đào tạo thương mại điện tử trong các trường đại học, cao đẳng và trung học chuyên nghiệp; có chính sách khuyến khích đào tạo chính quy về thương mại điện tử tại các trường đại học, cao đẳng, gắn kết hoạt động đào tạo với thực tiễn sản xuất kinh doanh của doanh nghiệp.&lt;/strong&gt;&lt;/p&gt;\n&lt;p&gt;\n	&lt;strong&gt;Điều 3. Quyết định này có hiệu lực thi hành kể từ ngày ký.&lt;/strong&gt;&lt;/p&gt;\n&lt;p&gt;\n	&lt;strong&gt;Điều 4. Các Bộ trưởng, Thủ trưởng cơ quan ngang Bộ, Thủ trưởng cơ quan thuộc Chính phủ, Chủ tịch Ủy ban nhân dân các tỉnh, thành phố trực thuộc Trung ương chịu trách nhiệm thi hành Quyết định này./.&lt;/strong&gt;&lt;/p&gt;\n&lt;p&gt;\n	 &lt;/p&gt;\n&lt;p&gt;\n	&lt;strong&gt;Nơi nhận:&lt;br /&gt;\n	- Ban Bí thư Trung ương Đảng;&lt;br /&gt;\n	- Thủ tướng, các Phó Thủ tướng Chính phủ;&lt;br /&gt;\n	- Các Bộ, cơ quan ngang Bộ, cơ quan thuộc CP;&lt;br /&gt;\n	- VP BCĐ TW về phòng, chống tham nhũng;&lt;br /&gt;\n	- HĐND, UBND các tỉnh, thành phố trực thuộc TW;&lt;br /&gt;\n	- Văn phòng TW và các Ban của Đảng;&lt;br /&gt;\n	- Văn phòng Chủ tịch nước;&lt;br /&gt;\n	- Hội đồng Dân tộc và các UB của Quốc hội;&lt;br /&gt;\n	- Văn phòng Quốc hội;&lt;br /&gt;\n	- Tòa án nhân dân tối cao;&lt;br /&gt;\n	- Viện Kiểm sát nhân dân tối cao;&lt;br /&gt;\n	- UB Giám sát tài chính QG;&lt;br /&gt;\n	- Kiểm toán Nhà nước;&lt;br /&gt;\n	- Ngân hàng Chính sách Xã hội;&lt;br /&gt;\n	- Ngân hàng Phát triển Việt Nam;&lt;br /&gt;\n	- Ủy ban TW Mặt trận Tổ quốc Việt Nam;&lt;br /&gt;\n	- Cơ quan Trung ương của các đoàn thể;&lt;br /&gt;\n	- VPCP: BTCN, các PCN, Cổng TTĐT,&lt;/strong&gt;&lt;/p&gt;\n&lt;p&gt;\n	&lt;strong&gt;  các Vụ, Cục, đơn vị trực thuộc, Công báo;&lt;br /&gt;\n	- Lưu: Văn thư, KTTH (5b). N&lt;/strong&gt;&lt;/p&gt;\n&lt;p&gt;\n	&lt;strong&gt;KT. THỦ TƯỚNG&lt;/strong&gt;&lt;/p&gt;\n&lt;p&gt;\n	&lt;strong&gt;PHÓ THỦ TƯỚNG&lt;/strong&gt;&lt;/p&gt;\n&lt;p&gt;\n	 &lt;/p&gt;\n&lt;p&gt;\n	&lt;strong&gt;(Đã ký)&lt;/strong&gt;&lt;/p&gt;\n&lt;p&gt;\n	&lt;strong&gt;Hoàng Trung Hải&lt;/strong&gt;&lt;/p&gt;\n&lt;p&gt;\n	&lt;strong&gt;Hiện thuộc tính văn bản&lt;/strong&gt;&lt;/p&gt;\n&lt;p&gt;\n	&lt;strong&gt;Số văn bản  1073&lt;br /&gt;\n	Ký hiệu  QĐ-TTG&lt;br /&gt;\n	Ngày ban hành  12/07/2010&lt;br /&gt;\n	Người ký  Hoàng Trung Hải&lt;br /&gt;\n	Trích yếu  Phê duyệt Kế hoạch tổng thể phát triển thương mại điện tử giai đoạn 2011 - 2015&lt;br /&gt;\n	Cơ quan ban hành  Thủ tướng Chính phủ&lt;br /&gt;\n	Phân loại  Quyết định&lt;/strong&gt;&lt;/p&gt;\n&lt;p&gt;\n	&lt;strong&gt;  Tệp đính kèm&lt;br /&gt;\n	QD1073TTG.DOC&lt;/strong&gt;&lt;/p&gt;\n&lt;p&gt;\n	&lt;strong&gt;  Các văn bản khác&lt;br /&gt;\n	      Về việc phê chuẩn kết quả bầu cử bổ sung Thành viên Ủy ban nhân dân tỉnh Quảng Bình nhiệm kỳ 2004 - 2011 (09/07/2010)&lt;br /&gt;\n	      V/v phê chuẩn kết quả miễn nhiệm Thành viên Ủy ban nhân dân tỉnh Quảng Bình nhiệm kỳ 2004 - 2011 (09/07/2010)&lt;br /&gt;\n	      V/v tặng thưởng Bằng khen của Thủ tướng Chính phủ (09/07/2010)&lt;br /&gt;\n	      Phê duyệt Điều chỉnh, bổ sung Quy hoạch thăm dò, khai thác và sử dụng khoáng sản làm xi măng ở Việt Nam đến năm 2020 (09/07/2010)&lt;br /&gt;\n	      V/v tặng thưởng Bằng khen của Thủ tướng Chính phủ (09/07/2010)&lt;br /&gt;\n	      V/v tặng thưởng Cờ thi đua của Chính phủ (09/07/2010)&lt;br /&gt;\n	      V/v tặng thưởng Cờ thi đua của Chính phủ (09/07/2010)&lt;br /&gt;\n	      V/v tặng thưởng Bằng khen của Thủ tướng Chính phủ (09/07/2010)&lt;br /&gt;\n	      V/v tặng thưởng Bằng khen của Thủ tướng Chính phủ (09/07/2010)&lt;br /&gt;\n	      V/v tặng thưởng Cờ thi đua của Chính phủ (09/07/2010)&lt;/strong&gt;&lt;/p&gt;\n', '', '', NULL, 1, '2011-11-18 02:19:38', 1, 1, NULL, NULL, 1, 15);
INSERT INTO `dos_module_handbook` (`record_id`, `pic_thumb`, `title`, `titleen`, `titlefr`, `preview`, `previewen`, `previewfr`, `content`, `contenten`, `contentfr`, `author`, `hits`, `postdate`, `record_order`, `record_type`, `extra_field1`, `extra_field2`, `enable`, `dos_module_handbook_cat_cat_id`) VALUES
(14, 'm.jpg', 'Sản phẩm của bạn có thích hợp với thương mại điện tử không?', '', '', '&lt;p&gt;\n	Các sản phẩm phù hợp nhất với việc bán hàng trên Internet là các hàng hoá được công nhận hay các sản phẩm có nhãn hiệu&lt;/p&gt;\n', '', '', '&lt;p&gt;\n	&lt;img alt=&quot;&quot; src=&quot;/public/userfiles/images/solution_Philippine-Outsourcing-Team.png&quot; style=&quot;width:192px;height:188px;&quot; /&gt;&lt;/p&gt;\n&lt;p&gt;\n	Các sản phẩm phù hợp nhất với việc bán hàng trên Internet là các hàng hoá được công nhận hay các sản phẩm có nhãn hiệu.&lt;br /&gt;\n	+ Bước đầu tiên để xây dựng một site thương mại điện tử là xác định liệu các hàng hoá của bạn có thích hợp với, việc bán hàng trên Internet không.&lt;br /&gt;\n	+ Các sản phẩm phù hợp nhất với việc bán hàng trênInternet là các hàng hoá được công nhận hay các sản phẩm có nhãn hiệu.&lt;br /&gt;\n	+ Nếu một sản phẩm dễ tìm thấy trên thị trường thì phải có một lý do bổ sung hay thuyết phục nào đó để làm cho khách hàng muốn mua nó trên web site.&lt;br /&gt;\n	+ Nếu sản phẩm của bạn nhằm vào thị trường ngách, lý do quyết định để bán hàng trên Internet có thể là sự truy nhập đến một thị trường rộng hơn.&lt;br /&gt;\n	Nếu công ty đã tạo dựng được danh tiếng trong khu vực hay trên thị trường quốc tế thì cần sử dụng danh tiếng này để mở rộng thị trường của bạn khi bán hàng trên Internet.&lt;br /&gt;\n	+ Phải đảm bảo không có những giới hạn pháp lý đối với việc bán sản phẩm trên Internet.&lt;br /&gt;\n	Các sản phẩm phù hợp nhất với việc bán hàng trên Internet là các hàng hoá được công nhận hay các sản phẩm có nhãn hiệu. Các sản phẩm hàng hoá là các sản phẩm mà khách hàng quen thuộc do đó biết được họ đang mua gì, mặc dù chưa nhìn thấy, thậm chí là chưa bao giờ nghe thấy về nhà sản xuất. PC là một ví dụ điển hình về hàng hoá. Một nhà sản xuất PC có thể cung cấp các quy cách sản phẩm và liệt kê các thành phần (ví dụ như bộ xử lý Intel Pentium, hệ điều hành Microsoft) của PC và khách hàng có thể hiểu được chức năng và chất lượng của sản phẩm này.&lt;br /&gt;\n	Nhãn hiệu xác định ngay nhà sản xuất và chất lượng sản phẩm. Coca-cola và Mcdonal và những nhãn hiệu được nhận ra ngay trên toàn thế giới. Sách là các sản phẩm có nhãn hiệu hiện đang được bán trên Internet. Sách bao gồm tên của nhà xuất bản và tên của tác giả. Những người tiêu dùng đến một web site mới không cần phải hỏi mà có thể xác định ngay được chất lượng của một cuốn sách của Robert Ludum do nhà xuất bản Bantam xuất bản.&lt;br /&gt;\n	Nếu một sản phẩm dễ tìm thấy trên thị trường thì phải có một lý do bổ sung hay thuyết phục nào đó để làm cho khách hàng muốn mua nó trên web site. Peapod.com là một site bán hàng tạp hoá trên Internet (www.peapod.com). Vì các cửa hàng tạp hoá dễ tìm thấy ở phần lớn các địa phương nên để thành công, Peapod đã phải cung cấp tiện nghi tốt hơn việc mua bán tại các cửa hàng tạp hoá trong địa phương. Peapod đã tạo ra các dịch vụ thuận lợi thông qua việc đặt hàng trực tuyến và giao hàng tại nhà. Những khách hàng quan tâm đến các dịch vụ này thấy Peapod là một thị trường hấp dẫn.&lt;br /&gt;\n	Các công ty khác sử dụng một site thương mại điện tử để tìm kiếm các thị trường không bình thường hoặc đặc biệt. Internet cho phép họ mở rộng quy mô thị trường của mình. Headroom là một nhà sản xuất các headphone chất lượng cao. Headroom có một website, www.headphone.com, mà thông qua đó công ty bán các headphone của mình trên Internet. Các headphone mà công ty sản xuất và bán thường không có ở phần lớn các cửa hàng audio. Những người quan tâm đến các thiết bị audio chất lượng cao sẽ tìm kiếm sản phẩm đặc biệt như vậy. Những người tiêu dùng quan tâm đến các thiết bị audio chất lượng cao là một nhóm nhỏ, họ ở rải rác khắp nơi.&lt;br /&gt;\n	Headroom thấy sự hiện diện trực tuyến sẽ giúp cho công ty truy nhập đến thị trường rất khó xác định này và cần phải phục vụ bằng các cửa hàng bán lẻ.&lt;br /&gt;\n	Các khách hàng có thể đặt dấu hỏi về chất lượng không được nhìn thấy và tính hợp pháp của việc mua hàng trên Internet từ một công ty mà họ không biết. Họ có thể nghi ngờ không biết một sản phẩm mua từ một web site không quen biết có được chuyển đến nhà hay cơ quan của họ không. Nếu sản phẩm không thuộc loại hàng hoá hay có nhãn hiệu hay công ty không nổi tiếng thì cần phải cung cấp thông tin hỗ trợ cho khách hàng của mình sao cho khách hàng có thể hiểu được chất lượng và tin rằng bạn sẽ chuyển hàng cho họ.&lt;br /&gt;\n	Các công ty đã tạo được uy tín khu vực và quốc tế có thể sử dụng uy tín này để mở rộng thị trường của mình khi bán hàng trên Internet. Một khách hàng mua một sản phẩm từ một công ty quốc tế như Disney hay một công ty nằm ở các vùng đã chọn ví dụ như trong khu vực của công ty Macy có thể đã làm quen với hình ảnh công ty và tin tưởng vào đó. Khi mua hàng từ một công ty đã quen biết, người tiêu dùng tin tưởng sản phẩm sẽ được chuyển đến cho họ.&lt;br /&gt;\n	Việc hiểu biết những hạn chế pháp lý của sản phẩm là cần thiết khi tạo ra một site thương mại điện tử. Do luật lệ của các bang, các công ty kinh doanh bất động sản ở Mỹ không thể bán ngoài biên giới bang của mình. Điều này hạn chế thông tin có thể thể hiện trên một site khảo hàng trực tuyến. Một công ty kinh doanh bất động sản bán một khu cộng đồng đã quy hoạch có thể cung cấp cho những người mua hàng tiềm năng thông tin về bất động sản, đi dạo thăm các nhà, số liệu thống kê về khu cộng đồng này và thông tin về những tiện nghi và dịch vụ, nhưng không thể cung cấp bản cáo bạch trực tuyến. Mục tiêu của một site khảo hàng trực tuyến đối với một công ty kinh doanh bất động sản là marketing đến những khách hàng tiềm năng ở các bang khác là cung cấp cho họ thông tin đủ để thu hút sự quan tâm của họ. Mục tiêu của dịch vụ khảo hàng trực tuyến là tạo ra những manh mối mà những nhà kinh doanh bất động sản địa phương có thể tìm đến. Sau đây là một số câu hỏi cơ bản mà bạn cần phải trả lời để đánh giá xem liệu sản phẩm của mình có thích hợp với thương mại điện tử trực tuyến không. Câu trả lời ''''không'''' không có nghĩa là sản phẩm không thích hợp với thương mại điện tử; nó chỉ có nghĩa rằng bạn cần tập trung sự chú ý vào đâu khi phát triển site thương mại điện tử của mình.&lt;br /&gt;\n	Bảng câu hỏi đối với các công ty bán sản phẩm trên Interne&lt;/p&gt;\n&lt;p&gt;\n	&lt;img alt=&quot;&quot; src=&quot;/public/userfiles/images/worldexport.jpg&quot; style=&quot;width:212px;height:164px;&quot; /&gt;&lt;/p&gt;\n&lt;table border=&quot;1&quot; cellpadding=&quot;1&quot; cellspacing=&quot;1&quot; style=&quot;width:500px;&quot;&gt;&lt;tbody&gt;&lt;tr&gt;&lt;td&gt;\n				&lt;p&gt;\n					Mọi người có dễ dàng hiểu được sản phẩm khi không nhìn thấy không?&lt;br /&gt;\n					Sản phẩm hay công ty có tiếng tăm hay nhãn hiệu?&lt;/p&gt;\n				&lt;p&gt;\n					&lt;br /&gt;\n					có thể định dạng nhân khẩu những người mua sản phẩm của mình không?&lt;/p&gt;\n				&lt;p&gt;\n					&lt;br /&gt;\n					Liệu mọi người có cảm thấy tiện lợi hơn khi mua hàng của  bạn từ máy tính để bàn ở nhà hay ở cơ quan so với việc mua qua điện thoại, fax hay đến tận nơi mua không?&lt;/p&gt;\n				&lt;p&gt;\n					&lt;br /&gt;\n					Bạn có khả năng tiếp cận được thị trưởng tiềm năng không? Có những người muốn mua sản phẩm của bạn nếu họ có thể truy nhập đến kênh phân phối không ?&lt;/p&gt;\n				&lt;p&gt;\n					&lt;br /&gt;\n					Việc bán các sản phẩm của mình trực tuyến từ website đến người tiêu dùng và các doanh nghiệp có hợp pháp không ?  &lt;/p&gt;\n			&lt;/td&gt;\n			&lt;td&gt;\n				&lt;p&gt;\n					Có - Bạn cần rõ ràng đơn giản khi giải thích sản phẩm trên web site của mình.&lt;br /&gt;\n					Không - Bạn cần phải có tư liệu bổ sung để cung cấp cho các khách hàng tiềm năng thông tin về sản phẩm của mình&lt;/p&gt;\n				&lt;p&gt;\n					&lt;br /&gt;\n					Có - Bạn có thể sử dụng danh tiếng của mình để cung cấp cho các khách hàng tiềm năng sự an toàn khi họ mua hàng hoá từ một công ty nổi tiếng.&lt;br /&gt;\n					Không - Cung cấp các chào hàng trả tiền sau và thông tin viện dẫn để làm cho khách hàng cảm thấy dễ chịu (ví dụ, cung cấp một danh sách những khách hàng nổi tiếng, cung cấp các bài báo tích cực nói về công ty, cung cấp chứng thực của khách hàng).&lt;/p&gt;\n				&lt;p&gt;\n					&lt;br /&gt;\n					Có - Định dạng nhân khẩu và nhu cầu khách hàng để tạo ra một site khảo hàng trực tuyến và quảng cáo sản phẩm bằng cách sử dụng các cửa ngách  (ni che portal).&lt;/p&gt;\n				&lt;p&gt;\n					&lt;br /&gt;\n					Không - Tiến hành nghiên cứu thị trưởng nhiều hơn. Nếu đoạn thị trường của bạn rất lớn thì hãy xác định một đoạn thị trưởng ban đầu nhỏ hơn.&lt;br /&gt;\n					Có - Hãy xây dựng một site mua hàng trực tuyến.&lt;br /&gt;\n					Không - Bạn có thể sử dụng site của mình để cung cấp cho khách hàng thông tin sản phẩm và dịch vụ khách hàng.&lt;br /&gt;\n					Có - Bạn đã có một kênh phân phối tốt. Có thể sử dụng thương mại điện tử để tăng cưởng kênh này và cung cấp bất kỳ dịch vụ gì dễ truy nhập cho các khách hàng của mình.&lt;br /&gt;\n					Không - Bạn có thể mở rộng quy mô thị trường và các dịch vụ của mình bằng cách cung cấp các dịch vụ thương mại điện tử &lt;/p&gt;\n				&lt;p&gt;\n					      &lt;br /&gt;\n					Có - Bạn có thể sử dụng site của mình để tiến hành kinh doanh thông qua một dịch vụ mua hàng trực tuyến.&lt;/p&gt;\n				&lt;p&gt;\n					&lt;br /&gt;\n					Không - Site của bạn có thể tập trung vào việc cung cấp thông tin sản phẩm, hỗ trợ khách hàng và dịch vụ khách hàng.&lt;/p&gt;\n			&lt;/td&gt;\n		&lt;/tr&gt;&lt;/tbody&gt;&lt;/table&gt;&lt;p&gt;\n	 &lt;/p&gt;\n', '', '', NULL, 1, '2011-11-18 02:34:07', 1, 0, NULL, NULL, 1, 15),
(15, '1022076.jpg', 'Tài nguyên &quot;thương mại điện tử&quot; bị bỏ quên? ', '', '', '&lt;p&gt;\n	Thương mại điện tử chính là một nguồn tài nguyên khổng lồ, không những nó không bị cạn kiệt khi được khai thác như các loại tài nguyên thiên nhiên mà trong kỷ nguyên công nghệ thông tin và viễn thông phát triển như vũ bão, nó ngày càng phong phú và đa dạng hơn.&lt;/p&gt;\n', '', '', '&lt;p&gt;\n	                                                        &lt;img alt=&quot;&quot; src=&quot;/public/userfiles/images/2011-11-17_190540.jpg&quot; style=&quot;width:102px;height:94px;&quot; /&gt;&lt;/p&gt;\n&lt;p&gt;\n	Tài nguyên &quot;thương mại điện tử&quot; bị bỏ quên?&lt;br /&gt;\n	Thương mại điện tử chính là một nguồn tài nguyên khổng lồ, không những nó không bị cạn kiệt khi được khai thác như các loại tài nguyên thiên nhiên mà trong kỷ nguyên công nghệ thông tin và viễn thông phát triển như vũ bão, nó ngày càng phong phú và đa dạng hơn.&lt;br /&gt;\n	Tuy nhiên, bất cập chính là ở chỗ chúng ta quên khai thác nó hoặc mới chỉ khai thác được ở dạng bề mặt. Và tất nhiên, chúng ta đang lãng phí một “đòn bẩy” cho phát triển kinh tế.&lt;br /&gt;\n	Chưa xác định được “trữ lượng”&lt;br /&gt;\n	Đó chính là quan điểm của ông Trần Thanh Hải, Phó vụ trưởng Vụ Thương mại điện tử (Bộ Thương mại) trong cuộc trao đổi với VnEconomy.&lt;br /&gt;\n	Ông Hải cho biết, chúng ta đã bắt đầu biết và làm quen với khái niệm thương mại điện tử từ năm 1997-1998 và ngày 15/9 Thủ tướng Chính phủ đã ban hành kế hoạch tổng thể thương mại điện tử giai đoạn 2006-2010, nhưng thực chất cho đến nay vẫn chưa có chính sách nào mang tầm cỡ vĩ mô cho việc khai thác nguồn tài nguyên khổng lồ này.&lt;br /&gt;\n	Hằng năm, Vụ Thương mại Điện tử – cơ quan được Chính phủ giao làm đầu mối cho các chiến lược phát triển thương mại điện tử, đều thực hiện một công trình, tạm coi là sách trắng về thương mại điện tử. Trong đó, báo cáo sẽ tổng hợp các số liệu, thống kê về thương mại điện tử. Song, hiện tại các chương trình phát triển, các giải pháp cho việc khai thác tổng hợp số liệu, thống kê thương mại điện tử vẫn đang rối rắm và lộn xộn như một mớ bòng bong.&lt;br /&gt;\n	Do đó, đối tượng chính mang lại giá trị lớn cho nền kinh tế là cộng đồng doanh nghiệp và bản thân các cơ quan Nhà nước đều gặp không ít khó khăn.&lt;br /&gt;\n	Nhà báo người Mỹ Thomas L. Friedman, một trong những chuyên gia hàng đầu thế giới về kinh tế toàn cầu hóa cũng đã khẳng định trong cuốn sách xếp hạng best seller “The Lexus and Olive”: thương mại điện tử là một nguyên liệu quan trọng, như một tài nguyên, nó sẵn sàng cho bất kỳ ai khai thác, là cái chung ai cũng có thể nắm bắt, có thể biến nó thành tài sản của mình.&lt;br /&gt;\n	Giá trị từ thương mại điện tử&lt;br /&gt;\n	Vậy nguồn tài nguyên này sẽ mang lại cho doanh nghiệp, các cơ quan Nhà nước, tổ chức hiệp hội và hàng triệu cá nhân sử dụng nó những lợi ích gì? Ông Trần Thanh Hải cho rằng, mỗi doanh nghiệp đều có thể tận dụng nó, cụ thể là các phương tiện như website, email, các sàn giao dịch điện tử… như một công cụ quảng cáo vô cùng hữu hiệu mà chi phí bỏ ra rất nhỏ.&lt;br /&gt;\n	Ngoài ra, nó cũng được coi là phương tiện thay thế cho hàng loạt các loại hình giao dịch thông thường. Chẳng hạn, thay vì phải tìm cách này hay cách kia như gọi điện thoại, cử nhân viên đi thu thập thông tin, cập nhật thị trường, cơ chế chính sách mới…, chỉ cần thông qua các trang web đã có thể nắm bắt được tất cả những thứ đó, thậm chí có thể trực tiếp giao dịch mua bán và thanh toán qua hệ thống ngân hàng.&lt;br /&gt;\n	Tất nhiên, lợi ích mà thương mại điện tử mang lại rất nhiều mà đến cả cơ quan quản lý lớn nhất của Nhà nước về thương mại điện tử cũng chưa nắm bắt được toàn bộ.&lt;br /&gt;\n	Minh chứng cho nhận định trên, ông Nguyễn Hữu Tuấn, phụ trách cổng thương mại điện tử quốc gia (Bộ Thương mại) cho biết: Thông qua cổng thương mại điện tử http://www.ecvn.gov.vn/, các doanh nghiệp sẽ được hỗ trợ xuất khẩu, hỗ trợ giao dịch và miễn phí hoàn toàn 3 năm.&lt;br /&gt;\n	Ngoài việc được hỗ trợ trực tuyến, các doanh nghiệp cũng được hỗ trợ ngoại tuyến bằng các hình thức chính sách, văn bản thông qua hệ thống cơ quan của Bộ Thương mại và các Thương vụ tại nước ngoài. Cổng thương mại điện tử quốc gia cũng như một “con triện” đảm bảo cho tính minh bạch, mức độ uy tín và khả năng thực của các doanh nghiệp khi đã được phép lên sàn. Hiện nay cổng thương mại điện tử đã có khoảng 300 doanh nghiệp tham gia, dự kiến đến 6/2006 sẽ có khoảng 500 doanh nghiệp tham gia.&lt;br /&gt;\n	Hiện không ít các doanh nghiệp đã tìm được bạn hàng xuất khẩu và xuất khẩu nhiều lô hàng có giá trị lớn thông qua sàn điện tử chính thống của quốc gia này. Cũng theo ông Tuấn, Ban quản lý cổng thương mại điện tử cũng liên tục cập nhật thêm những tính năng và hình thức hỗ trợ khác cho đơn vị tham gia.&lt;br /&gt;\n	Để cụ thể hơn, có thể lấy một vài điển hình cụ thể như xã chuyên trồng rau quả sạch Quỳnh Lương (Quỳnh Lưu – Nghệ An) vừa ra mắt trang http://www.quynhluong.gov.vn/ một cách rất chuyên nghiệp và bước đầu đã tạo nên những hiệu quả kinh doanh nhất định; Công ty Cổ phần Dược Hậu Giang đã sử dụng trang web của mình rất tốt, vừa là kênh quảng cáo, trao đổi thông tin, tư vấn khách hàng, giao dịch và liên lạc; hoặc như một công ty trong Bình Định đã ký hợp đồng với 1 doanh nghiệp ở Hà Nội về phân urê…&lt;br /&gt;\n	Bên cạnh đó, hiện nay cả nước đã có khoảng 60 sàn giao dịch điện tử chuyên nghiệp và một số trong đó đã tạo được tiếng vang lớn. Ông Nguyễn Hòa Bình, quản lý sàn giao dịch chodientu.com khẳng định, các sàn chuyên nghiệp như chodientu.com chủ yếu dành cho loại hình giao dịch B2C (doanh nghiệp với khách hàng) và C2C (khách hàng với khách hàng), chỉ cần đăng ký và rao bán hàng hóa, sản phẩm thậm chí là thông tin tuyển dụng (hiện miễn phí) chắc chắn cơ hội thành công được nhân lên gấp bội so với việc chạy đôn chạy đáo đi tìm người cần mua, cần bán.&lt;br /&gt;\n	Khai thác thế nào?&lt;br /&gt;\n	Tuy nhiên, câu hỏi làm thế nào để khai thác được hết tiềm năng của nguồn tài nguyên này mới thật sự đau đầu.&lt;/p&gt;\n&lt;p&gt;\n	                                                                             &lt;img alt=&quot;&quot; src=&quot;/public/userfiles/images/D.jpeg&quot; style=&quot;width:223px;height:145px;&quot; /&gt;&lt;br /&gt;\n	Phó vụ trưởng Vụ Thương mại Điện tử cho biết, hiện vụ đang tiến hành 2 chương trình là điều tra hiện trạng ứng dụng thương mại điện tử trong doanh nghiệp, trước mắt là phục vụ cho việc soạn thảo Báo cáo thương mại điện tử 2005; chương trình thứ 2 là tiến hành xếp hạng các website thương mại điện tử hiện có.&lt;br /&gt;\n	Đây là những việc làm thực sự cần thiết nhằm tạo một “đòn bẩy” cho nhận thức về thương mại điện tử của doanh nghiệp và người dân. Bởi lẽ hiện người tiêu dùng thật khó biết được website nào uy tín, trung thực và đáng tin cậy. Song, một khó khăn cần phải thừa nhận là Vụ Thương mại Điện tử tự làm những việc này nên chưa thể chính xác, diện chưa rộng, chưa đủ và phương pháp cũng chưa thực sự chuyên nghiệp, kinh nghiệm xử lý chưa nhiều.&lt;br /&gt;\n	Cũng theo ông Hải, cái khó là hiện nay nhận thức về thương mại điện tử của doanh nghiệp còn hạn chế, đơn cử là các doanh nghiệp lập website chỉ như một thứ trang sức, vài tháng thậm chí cả năm trời mà giao diện trang chủ vẫn nguyên si, không có thông tin gì mới trong khi thông tin về chính sách, hoạt động sản xuất, kinh doanh, thị trường trong nước và quốc tế liên tục cập nhật, chi phí cho website cũng chanửg đáng bao nhiêu.&lt;br /&gt;\n	Trở ngại tiếp theo chính là thói quen giao dịch trực tiếp và thanh toán bằng tiền mặt của đa số doanh nghiệp và người tiêu dùng. Từ đó, họ ít khi nghĩ đến việc tìm kiếm thông tin và giao dịch, mua bán, thanh toán qua internet.&lt;br /&gt;\n	Trở ngại thứ ba, theo ông Hải là về chính sách, thủ tục hành chính. Đơn cử là việc lập website phải có được giấy phép của Bộ Văn hóa Thông tin. Một ngày có hàng chục doanh nghiệp lập website trong khi thời gian chờ phép khá lâu nên dễ xảy ra việc không xin phép (và thực tế hiện đa phần các website không phép).&lt;br /&gt;\n	Tất nhiên, sau giấy phép là yêu cầu về an toàn thông tin và vi phạm luật pháp, sai lệch về văn hóa tư tưởng. Song thực tế hàng trăm website mới có vài cái vi phạm, nếu vì 1- 2 cái đó mà làm chậm cho tất cả doanh nghiệp thì qúa lãng phí. Thậm chí cổng thương mại điện tử http://www.ecvn.gov.vn/ của Bộ Thương mại cũng phải xin phép rất lâu.&lt;br /&gt;\n	Theo các chuyên gia, mặc dù hiện trạng về khai thác thương mại điện tử ở nước ta còn nhiều hạn chế, song việc phát triển và khai thác nó dường như là một con đương tất yếu. Bởi lẽ trong kỷ nguyên toàn cầu hóa, khi khoa học kỹ thuật, đặc biệt là công nghệ thông tin phát triển chóng mặt, liên tục cập nhật công nghệ mới, khi dòng thông tin trôi qua internet không chờ một ai thì nếu không theo kịp và tận dụng được nó thì mỗi doanh nghiệp, cá nhân sẽ bị đẩy vào guồng máy đào thải.&lt;br /&gt;\n	Từ đó, hô hào chỉ là chuyện “lý thuyết”, còn những bài học nhãn tiền như những thất bại khi quên mất trong tay mình có thương mại điện tử hay là những thành công thực tế từ các doanh nghiệp biết tận dụng khả năng của thương mại điện tử như xã Quỳnh Lương, công ty Cổ phần Dược Hậu Giang… kể trên, có lẽ không ai có thể tiếp tục đứng ngoài cuộc. Cộng với những chính sách đang được cố gắng hoàn thiện, thiết nghĩ giá trị do thương mại điện tử mang lại sẽ không ảm đạm như hôm nay.&lt;br /&gt;\n	Theo thời báo kinh tế Việt Nam.&lt;/p&gt;\n', '', '', NULL, 1, '2011-11-18 05:57:23', 1, 0, NULL, NULL, 1, 15),
(16, '20111117_1905175.jpg', 'Tin thương mại điện tử ', '', '', '&lt;p&gt;\n	 Lesbie Gordon tìm cách bán sản phẩm của Hudson Valley trên mạng khi chỉ có ít vốn liếng, thời gian cũng như kỹ năng vi tính. Tuy nhiên cô rất kỳ vọng ở ngành kinh doanh thương mại điện tử như một tuyệt chiêu với đầy đủ sức mạnh và được thị trường đón nhận. “Điều quan trọng nhất đối với chúng tôi là tìm được một giải pháp có chi phí thấp nhất mà không phải hy sinh chất lượng,&lt;/p&gt;\n', '', '', '&lt;p&gt;\n	Lesbie Gordon tìm cách bán sản phẩm của Hudson Valley trên mạng khi chỉ có ít vốn liếng, thời gian cũng như kỹ năng vi tính. Tuy nhiên cô rất kỳ vọng ở ngành kinh doanh thương mại điện tử như một tuyệt chiêu với đầy đủ sức mạnh và được thị trường đón nhận. “Điều quan trọng nhất đối với chúng tôi là tìm được một giải pháp có chi phí thấp nhất mà không phải hy sinh chất lượng, tính tinh tế hay tính linh hoạt”, cô Gordon, 31 tuổi, phát biểu như vậy.&lt;br /&gt;\n	Gordon cũng đã tìm được  website thương mại điện tử có chi phí khá thấp trên Homestead.com. Menlo Park, khu công nghệ cao Homestead ở California thu của cô 150 USD một tháng tiền phí trang chủ Madeinthehudsonvalley.com. Cô sử dụng các chức năng thiết kế trang web của Homestead để xây dựng trang web riêng, tận dụng các dịch vụ tiếp thị của nhà cung cấp.&lt;br /&gt;\n	Ngoài việc tiết kiệm được 10 000 USD chi phí lập trình trang web riêng Gordon còn rất thỏa mãn với kết quả đạt được. “Công dụng của chúng cũng tương đương với trang Amazon.com cả về hình thức lẫn ý nghĩa”. Cô nói.&lt;br /&gt;\n	Việc tìm kiếm một trang web thương mại điện tử có chi phí thấp hiện không còn nhiều lựa chọn như ba năm trước đây, đó là đánh giá của ông Kneko Burney, giám đốc kinh doanh dịch vụ và cơ sở hạ tầng của công ty nghiên cứu In – Stat MDR. Nhưng điều đó không phải là bất lợi. Nhiều nhà cung cấp dịch vụ đã bỏ nghề để chuyển sang làm việc cho những công ty lớn hơn, tiềm năng hơn, đưa ra thị trường những sản phẩm mang tính chiến lược hơn, bền vững hơn, ông Burney nói.&lt;br /&gt;\n	Bán hàng trực tuyến vẫn là một ý tưởng kinh doanh tốt đối với các doanh nghiệp nhỏ, các phương án không mấy tốn kém để mở một trang trực tuyến riêng cũng rất phong phú và hiệu quả. Để giúp các bạn ra quyết định, chúng tôi đã lựa chọn và giới thiệu năm giải pháp thương mại điện tử tiêu biểu với chi phí tương đối thấp.&lt;br /&gt;\n	Năm trang web có thể lựa chọn để khởi nghiệp.&lt;br /&gt;\n	1. bCentral&lt;br /&gt;\n	bCentral của Microsoft chào bán trọn gói với giá trang chủ là 49,95 USD và trang thương mại điện tử là 24,95 USD một tháng. Chi phí cài đặt là 35 USD. Chương trình thương mại điện tử này cho phép bạn bắt đầu bằng một vài bản mẫu, và sử dụng một số thao tác để nhập logo hay catalog cho sản phẩm của bạn. Ở đó cũng có đầy đủ các công đoạn chọn hàng, bán và đặt hàng, tự động xác nhận đơn đặt hàng bằng e-mail, thông báo việc vận chuyển tới khách hàng và các dịch vụ hậu mãi. Bạn có thể tính cả chi phí điện thoại. Sẽ tốt hơn nếu bạn miễn phí dịch vụ trong tháng đầu khai trương.&lt;br /&gt;\n	Ưu điểm: Không phải chịu chi phí bán hàng, cho phép bạn liệt kê đầy đủ tên sản phẩm trên một vài trang web mua bán hay đấu giá khác như eBay, MSN hay uBid.&lt;br /&gt;\n	Nhược điểm: Hạn chế về phương tiện vận chuyển, thiếu dịch vụ thiết lập các kênh truyền quan trọng.&lt;/p&gt;\n&lt;p&gt;\n	                                                                         &lt;img alt=&quot;&quot; src=&quot;/public/userfiles/images/img-1222158210-2.jpg&quot; style=&quot;width:250px;height:186px;&quot; /&gt;&lt;/p&gt;\n&lt;p&gt;\n	Mạng eBay đưa ra ba mức giá, dựa trên mức độ khuyếch trương sản phẩm trên mạng eBay. Trang cơ bản có mức giá 9,95 USD một tháng chỉ cung cấp một vài danh mục đơn điệu, không có thông tin về vận chuyển và bán hàng. Trang nâng cao có giá là 49,95 USD cho phép truy cập tới các địa chỉ ưu tiên tìm kiếm các sản phẩm có liên quan với nhau và vài báo cáo hàng tháng. Trang cao giá nhất và cũng rất đáng tin cậy được chào ở mức 500 USD, được liệt kê trong danh mục của mạng eBay, eBay đã đổ tiền vào thương mại điện tử để đăng tải các kết quả tìm kiếm và đặt logo trên mạng eBay để được hàng triệu khách hàng biết tới.&lt;br /&gt;\n	Ưu điểm: Chi phí cho trang cơ bản là rất thấp, được truyền tới 42 triệu khách sử dụng mạng eBay.&lt;br /&gt;\n	Nhược điểm: Các chức năng lưu trữ sơ sài, trang cơ bản trông giống cuộc bán đấu giá.&lt;br /&gt;\n	3. Trang bán hàng Homestead&lt;br /&gt;\n	Giải pháp thương mại điện tử Homestead chào giá từ 29,99 USD đến 130 USD một tháng phụ thuộc vào số lượng sản phẩm đem bán và hệ thống sử dụng là cơ bản hay nâng cao. Cả hai mức đều bao gồm trang chủ, kèm theo các chức năng khởi động, phần mềm, thiết kế web, bản mẫu và hệ thống quản lý hàng hoá thuận tiện và dễ dàng sử dụng. Bạn có thể ấn định các mức giá bán khác nhau cho sản phẩm phân loại theo thuộc tính như kích cỡ hay màu sắc, gửi xác nhận đơn đặt hàng bằng e-mail, giảm giá bán cho khách mua số lượng lớn và các tiện ích khác.&lt;br /&gt;\n	Mạng Homestead kết nối với nhiều hệ thống tài khoản bán hàng trực tuyến lớn cho phép thanh toán bằng thẻ tín dụng, nếu bạn chưa có tài khoản thì Homestead mở cho bạn với chi phí 22,95 USD một tháng. Các chức năng tiêu chuẩn gồm thống kê số lần truy cập trang web và dịch vụ kỹ thuật tìm kiếm. Ngoài ra nếu muốn các trợ giúp tăng cường, bạn phải trả từ 4,99 đến 69,99 USD một tháng .&lt;br /&gt;\n	Ưu điểm: Dễ dàng xây dựng trang web, phục vụ khách hàng chu đáo.&lt;br /&gt;\n	Nhược điểm: Vẫn còn một số nét của trang web miễn phí, các chức năng khuyếch trương còn sơ sài.&lt;br /&gt;\n	Tag: thiết kế website, quảng bá website, tư vấn thiết kế web, quảng lí cấp cao, mạng xã hội, nghệ thuật bán hàng&lt;br /&gt;\n	Highlandsoft.com.vn _nguồn sưu tầm&lt;/p&gt;\n', '', '', NULL, 1, '2011-11-18 06:11:07', 1, 0, NULL, NULL, 1, 15),
(17, '20111117_1905405.jpg', 'Xu hướng thương mại điện tử ngày một tăng cao', '', '', '&lt;p&gt;\n	Internet phát triển mạnh mẽ sẽ là động lực để thúc đẩy sự tăng trưởng buôn bán trên phạm vi toàn cầu. Các nước trên thế giới đã và đang sẵn sàng nhập cuộc. Dự báo trong thời gian tới, thương mại điện tử sẽ đem lại cho các doanh nghiệp một nguồn lợi nhuận khổng lồ.&lt;/p&gt;\n', '', '', '&lt;p&gt;\n	                                                             &lt;img alt=&quot;&quot; src=&quot;/public/userfiles/images/2011-11-17_190540.jpg&quot; style=&quot;width:102px;height:94px;&quot; /&gt;]&lt;/p&gt;\n&lt;p&gt;\n	Doanh thu từ bán hàng qua mạng sẽ chiếm một phần lớn.&lt;br /&gt;\n	Bán hàng qua mạng Internet không mất nhiều thời gian đã trở nên phổ biến giữa khách hàng và các nhà kinh doanh trong những năm gần đây, đặc biệt là trong kỷ nguyên tới. Thực tế cho thấy năm 1999, doanh thu bán hàng từ thương mại điện tử đã chiếm một phần quan trọng trong tổng doanh thu tại hầu hết các công ty trên thế giới. Qua đợt khảo sát gần đây, các giao dịch thương mại điện tử chiếm 9% doanh thu hằng năm tại 300 công ty. Con số này được thay đổi từ 6% tại các công ty có qui mô vừa và nhỏ tới 13% tại các công ty lớn. Cũng trong năm 1999, số người Mỹ đã tiến hành các thủ tục giao dịch, mua hàng trên mạng là 39 triệu ngời (tăng gấp đôi so với năm 1998), 34% số hộ gia đình người Mỹ đã nối mạng Internet và 17% trong số đó đã tiến hành mua hàng qua mạng.&lt;br /&gt;\n	Theo các chuyên gia trong lĩnh vực công nghệ thông tin, doanh thu từ bán hàng qua mạng Internet sẽ tiếp tục tăng trong năm tới và sẽ giữ mức ổn định trong vài năm tiếp theo.&lt;br /&gt;\n	Thách thức từ thương mại điện tử&lt;br /&gt;\n	Mặc dù bán hàng qua mạng Internet đang phát triển một cách nhanh chóng nhưng cũng phải cần nhiều thời gian để có thể đạt được doanh thu cao của hầu hết các công ty. Đã có những lo ngại về sự cạnh tranh với thương mại điện tử của các đối thủ trong thế giới kinh doanh truyền thống. Tùy từng ngành công nghiệp khác nhau sẽ phải đối đầu với những thách thức khác nhau trong năm 2000 trong ngành công nghiệp máy tính, 60% chuyên gia công nghệ thông tin lo lắng về các hoạt động thương mại điện tử của các đối thủ cạnh tranh hơn các phương thức kinh doanh truyền thống xưa nay. Tuy nhiên, các ngành sản xuất và dịch vụ khác thì chỉ có khoảng 30% lo ngại về dạng kinh doanh qua thương mại điện tử của đối thủ.&lt;br /&gt;\n	Thương mại điện tử toàn cầu đang phát triển mạnh&lt;br /&gt;\n	Với khu vực thị trường nội địa to lớn, nhiều công ty của Mỹ còn chậm trong việc bán hàng ra toàn thế giới. Hiện nay, chỉ có khoảng 12% lượng hàng bán ra từ các công ty lớn của Mỹ ra thị trường nước ngoài. Nhưng theo xu hướng phát triển tất yếu, con số này đang có chiều hướng gia tăng và dự báo sẽ tăng 15% trong hai năm tới.&lt;br /&gt;\n	Một số nước ở Châu Á CŨNG ĐANG TÍCH CỰC trong cuộc chạy đua với các quốc gia phát triển. Trong vòng 5 năm tới, số luợng người châu Á truy cập vào mạng Internet sẽ vượt quá tổng số người truy cập ở châu Âu và Bắc Mỹ gộp lại. Dự kiến doanh thu mua bán hàng trên mạng Internet tại châu Á sẽ tăng lên rất nhiều, chiếm 1/4 thu nhập thơng mại Internet trên toàn cầu (khoảng 1.400 tỉ USD vào năm 2003). Các công ty lớn với nguồn hàng ổn định luôn mong muốn mở rộng thị trường, rất tích cực trong việc triển khai thương mại điện tử, tăng cường việc bán hàng ra toàn cầu, đồng thời triển khai việc mua hàng hóa và dịch vụ từ nguồn bên ngoài.&lt;/p&gt;\n', '', '', NULL, 1, '2011-11-18 06:32:30', 1, 0, NULL, NULL, 1, 14);
INSERT INTO `dos_module_handbook` (`record_id`, `pic_thumb`, `title`, `titleen`, `titlefr`, `preview`, `previewen`, `previewfr`, `content`, `contenten`, `contentfr`, `author`, `hits`, `postdate`, `record_order`, `record_type`, `extra_field1`, `extra_field2`, `enable`, `dos_module_handbook_cat_cat_id`) VALUES
(18, 'images8.jpg', 'Thương Mại Điện Tử là gì ? ', '', '', '&lt;p&gt;\n	    &lt;span style=&quot;color:#000080;&quot;&gt;&lt;span style=&quot;font-size:14px;&quot;&gt;  &lt;/span&gt;&lt;/span&gt;&lt;span style=&quot;font-size:14px;&quot;&gt;Có nhiều khái niệm về thương mại điện tử (TMĐT), nhưng hiểu một cách tổng quát, TMĐT là việc tiến hành một phần hay toàn bộ hoạt động thương mại bằng những phương tiện điện tử. TMĐT vẫn mang bản chất như các hoạt động thương mại truyền thống. Tuy nhiên, thông qua các phương tiện điện tử mới, các hoạt động thương mại được thực hiện nhanh hơn, hiệu quả hơn, giúp tiết kiệm chi phí và mở rộng không gian kinh doanh.&lt;/span&gt;&lt;/p&gt;\n', '', '', '&lt;p&gt;\n	&lt;span style=&quot;color:#0000cd;&quot;&gt;&lt;span style=&quot;font-size:18px;&quot;&gt;&lt;strong&gt;Thương Mại Điện Tử là gì ?&lt;/strong&gt;&lt;/span&gt;&lt;/span&gt;&lt;/p&gt;\n&lt;p&gt;\n	&lt;br /&gt;&lt;span style=&quot;font-size:14px;&quot;&gt;&lt;strong&gt;1. Thương mại điện tử là gì ?&lt;/strong&gt;&lt;/span&gt;&lt;/p&gt;\n&lt;p&gt;\n	&lt;br /&gt;&lt;span style=&quot;font-size:14px;&quot;&gt;      Có nhiều khái niệm về thương mại điện tử (TMĐT), nhưng hiểu một cách tổng quát, TMĐT là việc tiến hành một phần hay toàn bộ hoạt động thương mại bằng những phương tiện điện tử. TMĐT vẫn mang bản chất như các hoạt động thương mại truyền thống. Tuy nhiên, thông qua các phương tiện điện tử mới, các hoạt động thương mại được thực hiện nhanh hơn, hiệu quả hơn, giúp tiết kiệm chi phí và mở rộng không gian kinh doanh.&lt;br /&gt;\n	    TMĐT càng được biết tới như một phương thức kinhdoanh hiệu quả từ khi Internet hình thành và phát triển. Chính vì vậy, nhiều người hiểu TMĐT theo nghĩa cụ thể hơn là giao dịch thương mại, mua sắm qua Internet và mạng (ví dụ mạng Intranet của doanh nghiệp)&lt;/span&gt;&lt;/p&gt;\n&lt;p&gt;\n	&lt;span style=&quot;font-size:14px;&quot;&gt;.&lt;/span&gt;&lt;br /&gt;&lt;span style=&quot;font-size:14px;&quot;&gt;&lt;strong&gt;2. Lợi ích của TMĐT&lt;/strong&gt;&lt;/span&gt;&lt;/p&gt;\n&lt;p&gt;\n	&lt;br /&gt;&lt;span style=&quot;font-size:14px;&quot;&gt;      Lợi ích lớn nhất màTMĐT đem lại chính là sự tiết kiệm chi phí và tạo thuận lợi cho các bên giao dịch. Giao dịch bằng phương tiện điện tử nhanh hơn so với giao dịch truyền thống, ví dụ gửi fax hay thư điện tử thì nội dung thông tin đến tay người nhận nhanh hơn gửi thư. Các giao dịch qua Internet có chi phí rất rẻ, một doanh nghiệp có thể gửi thư tiếp thị, chào hàng đến hàng loạt khách hàng chỉ với chi phí giống như gửi cho một khách hàng. Với TMĐT, các bên có thể tiến hành giao dịch khi ở cách xa nhau, giữa thành phố với nông thôn, từ nước này sang nước kia, hay nói cách khác là không bị giới hạn bởi không gian địa lý. Điều này cho phép các doanh nghiệp tiết kiệm chi phí đi lại, thời gian gặp mặt trong khi mua bán. Với người tiêu dùng, họ có thể ngồi tại nhà để đặt hàng, mua sắm nhiều loại hàng hóa, dịch vụ thật nhanh chóng.&lt;/span&gt;&lt;/p&gt;\n&lt;p&gt;\n	&lt;br /&gt;&lt;span style=&quot;font-size:14px;&quot;&gt;      Những lợi ích nhưtrên chỉ có được với những doanh nghiệp thực sự nhận thức được giá trị của TMĐT. Vì vậy, TMĐT góp phần thúc đẩy sự cạnh tranh giữa các doanh nghiệp để thu được nhiều lợi ích nhất. Điều này đặc biệt quan trọng trong bối cảnh hội nhập kinh tế quốc tế, khi các doanh nghiệp trong nước phải cạnh tranh một cách bình đẳng với các doanh nghiệp nước ngoài.&lt;/span&gt;&lt;/p&gt;\n&lt;p&gt;\n	&lt;br /&gt;&lt;span style=&quot;font-size:14px;&quot;&gt;&lt;strong&gt;3. Các loại hình ứng dụng TMĐT&lt;/strong&gt;&lt;/span&gt;&lt;/p&gt;\n&lt;p&gt;\n	&lt;br /&gt;&lt;span style=&quot;font-size:14px;&quot;&gt;      Dựa vào chủ thể của thương mại điện tử, có thể phân chia thương mại điện tử ra các loại hình phổ biến như sau:&lt;br /&gt;\n	    - Giao dịch giữa doanh nghiệp với doanh nghiệp -&lt;strong&gt; B2B &lt;/strong&gt;(business to business);&lt;/span&gt;&lt;/p&gt;\n&lt;p&gt;\n	&lt;br /&gt;&lt;span style=&quot;font-size:14px;&quot;&gt;    - Giao dịch giữa doanh nghiệp với khách hàng - &lt;strong&gt;B2C&lt;/strong&gt; (business to consumer);&lt;/span&gt;&lt;/p&gt;\n&lt;p&gt;\n	&lt;br /&gt;&lt;span style=&quot;font-size:14px;&quot;&gt;    - Giao dịch giữa doanh nghiệp với cơ quan nhà nước &lt;strong&gt;- B2G&lt;/strong&gt; (business to government);&lt;/span&gt;&lt;/p&gt;\n&lt;p&gt;\n	&lt;br /&gt;&lt;span style=&quot;font-size:14px;&quot;&gt;    - Giao dịch trực tiếp giữa các cá nhân với nhau - &lt;strong&gt;C2C&lt;/strong&gt; (consumer to consumer);&lt;/span&gt;&lt;/p&gt;\n&lt;p&gt;\n	&lt;br /&gt;&lt;span style=&quot;font-size:14px;&quot;&gt;     - Giao dịch giữa cơ quan nhà nước với cá nhân - &lt;strong&gt;G2C&lt;/strong&gt; (government to consumer).&lt;/span&gt;&lt;/p&gt;\n&lt;p&gt;\n	&lt;br /&gt;&lt;span style=&quot;font-size:14px;&quot;&gt;&lt;strong&gt;      B2B&lt;/strong&gt; là loại hình giao dịch qua các phương tiện điện tử giữa doanh nghiệp với doanh nghiệp. Theo Tổ chức Liên hợp quốc về Hợp tác và Phát triển kinh tế (UNCTAD), TMĐT &lt;strong&gt;B2B&lt;/strong&gt; chiếm tỷ trọng lớn trong TMĐT (khoảng 90%). Các giao dịch&lt;strong&gt; B2B&lt;/strong&gt; chủ yếu được thực hiện trên các hệ thống ứng dụng TMĐT như mạng giá trị gia tăng (VAN); dây chuyền cung ứng hàng hoá, dịch vụ (SCM), các sàn giao dịch TMĐT… Các doanh nghiệp có thể chào hàng, tìm kiếm bạn hàng, đặt hàng, ký kết hợp đồng, thanh toán qua các hệ thống này. Ở một mức độ cao, các giao dịch này có thể diễn ra một cách tự động. TMĐT &lt;strong&gt;B2B&lt;/strong&gt; đem lại nhiều lợi ích thực tế cho doanh nghiệp, đặc biệt giúp giảm các chi phí về thu thập thông tin tìm hiểu thị trường, quảng cáo, tiếp thị, đàm phán, tăng các cơ hội kinh doanh,…&lt;br /&gt;&lt;strong&gt;B2C&lt;/strong&gt; là loại hình giao dịch giữa doanh nghiệp và người tiêu dùng qua các phương tiện điện tử. Doanh nghiệp sử dụng các phương tiện điện tử để bán hàng hóa, dịch vụ tới người tiêu dùng. Người tiêu dùng thông qua các phương tiện điện tử để lựa chọn, mặc cả, đặt hàng, thanh toán, nhận hàng. Giao dịch &lt;strong&gt;B2C&lt;/strong&gt; tuy chiếm tỷ trọng ít (khoảng 10%) trong TMĐT nhưng có sự phạm vi ảnh hưởng rộng. Để tham gia hình thức kinh doanh này, thông thường doanh nghiệp sẽ thiết lập website, hình thành cơ sở dữ liệu về hàng hoá, dịch vụ; tiến hành các quy trình tiếp thị, quảng cáo, phân phối trực tiếp tới người tiêu dùng. TMĐT&lt;strong&gt; B2C&lt;/strong&gt; đem lại lợi ích cho cả doanh nghiệp lẫn người tiêu dùng. Doanh nghiệp tiết kiệm nhiều chi phí bán hàng do không cần phòng trưng bày hay thuê người giới thiệu bán hàng, chi phí quản lý cũng giảm hơn. Người tiêu dùng sẽ cảm thấy thuận tiện vì không phải tới tận cửa hàng, có khả năng lựa chọn và so sánh nhiều mặt hàng cùng một lúc.&lt;br /&gt;&lt;br /&gt;&lt;strong&gt;      B2G&lt;/strong&gt; là loại hình giao dịch giữa doanh nghiệp với cơ quan nhà nước, trong đó cơ quan nhà nước đóng vai trò khách hàng. Quá trình trao đổi thông tin giữa doanh nghiệp với cơ quan nhà nước được tiến hành qua các phương tiện điện tử. Cơ quan nhà nước cũng có thể thiết lập những website tại đó đăng tải thông tin về nhu cầu mua hàng của các cơ quan nhà nước, tiến hành việc đấu thầu hàng hoá, dịch vụ và lựa chọn nhà cung cấp trên website. Điều này một mặt giúp tiết kiệm các chi phí tìm nhà cung cấp, đồng thời giúp tăng cường tính minh bạch trong hoạt động mua sắm công.&lt;br /&gt;&lt;strong&gt;     C2C&lt;/strong&gt; là loại hình giao dịch giữa các cá nhân với nhau. Sự phát triển của các phương tiện điện tử làm cho nhiều cá nhân có thể tham gia hoạt động thương mại với tư cách là người bán, người cung cấp dịch vụ. Một cá nhân có thể tự thiết lập website để kinh doanh những mặt hàng do mình làm ra hoặc sử dụng một website có sẵn để đấu giá một số món hàng mình có. &lt;strong&gt;C2C&lt;/strong&gt; góp phần tạo nên sự đa dạng của thị trường.&lt;br /&gt;&lt;strong&gt;      G2C&lt;/strong&gt; là loại hình giao dịch giữa cơ quan nhà nước với cá nhân. Đây chủ yếu là các giao dịch mang tính hành chính, nhưng có thể mang những yếu tố của TMĐT. Ví dụ khi người dân đóng tiền thuế qua mạng, trả phí khi đăng ký hồ sơ trực tuyến, v.v...&lt;/span&gt;&lt;/p&gt;\n&lt;p&gt;\n	&lt;br /&gt;&lt;span style=&quot;font-size:14px;&quot;&gt;&lt;strong&gt;4. Pháp luật về thương mại điện tử&lt;/strong&gt;&lt;/span&gt;&lt;/p&gt;\n&lt;p&gt;\n	&lt;br /&gt;&lt;span style=&quot;font-size:14px;&quot;&gt;      Ngày 1/3/2006, Luật Giao dịch điện tử Việt Nam chính thức có hiệu lực. Đến cuối năm 2007, bốn trong số năm nghị định hướng dẫn Luật Giao dịch điện tử đã được ban hành, về cơ bản hoàn thành khung pháp lý cho việc triển khai ứng dụng giao dịch điện tử trong các lĩnh vực lớn của đời sống xã hội.&lt;br /&gt;\n	Ngày 9/6/2006, Chính phủ ban hành Nghị định về Thương mại điện tử với việc thừa nhận chứng từ điện tử có giá trị pháp lý tương đương chứng từ truyền thống trong mọi hoạt động thương mại từ chào hàng, chấp nhận chào hàng, giao kết hợp đồng cho đến thực hiện hợp đồng.&lt;br /&gt;\n	      Ngày 15/2/2007, Nghị định số 26/2007/NĐ-CP quy định chi tiết về Chữ ký số và Dịch vụ chứng thực chữ ký số được ban hành. Nghị định này quy định về chữ ký số và các nội dung cần thiết liên quan đến sử dụng chữ ký số, bao gồm chứng thư số và việc quản lý, cung cấp và sử dụng dịch vụ chứng thực chữ ký số. Đây là những quy định nền tảng để thiết lập một cơ chế đảm bảo an ninh an toàn cũng như độ tin cậy của các giao dịch điện tử, là điều kiện tiên quyết về mặt kỹ thuật để thúc đẩy ứng dụng thương mại điện tử rộng rãi trong xã hội.&lt;/span&gt;&lt;/p&gt;\n&lt;p&gt;\n	&lt;br /&gt;&lt;span style=&quot;font-size:14px;&quot;&gt;      Ngày 23/2/2007,Chính phủ ban hành Nghị định số 27/2007/NĐ-CP quy định chi tiết thi hành Luật Giao dịch điện tử trong hoạt động tài chính. Nghị định này ra đời nhằm đảm bảo các điều kiện cần thiết để hình thành và phát triển một môi trường giao dịch điện tử an toàn, hiệu quả; giúp Chính phủ quản lý được giao dịch điện tử trong hoạt động nghiệp vụ tài chính, giảm thiểu hậu quả xấu phát sinh trong giao dịch điện tử như trốn thuế, gian lận khi lập hóa đơn chứng từ.&lt;/span&gt;&lt;/p&gt;\n&lt;p&gt;\n	&lt;br /&gt;&lt;span style=&quot;font-size:14px;&quot;&gt;      Ngày 8/3/2007, Nghị định số 35/2007/NĐ-CP về Giao dịch điện tử trong hoạt động ngân hàng được ban hành tập trung hướng dẫn việc áp dụng Luật Giao dịch điện tử cho các hoạt động ngân hàng cụ thể, bảo đảm những điều kiện cần thiết về môi trường pháp lý để củng cố, phát triển các giao dịch điện tử an toàn và hiệu quả đối với hệ thống ngân hàng.&lt;/span&gt;&lt;/p&gt;\n&lt;p&gt;\n	&lt;br /&gt;&lt;span style=&quot;font-size:14px;&quot;&gt;&lt;strong&gt;5. Thanh toán điện tử&lt;/strong&gt;&lt;/span&gt;&lt;/p&gt;\n&lt;p&gt;\n	&lt;br /&gt;&lt;span style=&quot;font-size:14px;&quot;&gt;      Thanh toán điện tử là hình thức thanh toán tiếnhành trên môi trường internet, thông qua hệ thống thanh toán điện tử người sử dụng mạng có thể tiến hành các hoạt động thanh toán, chi trả, chuyển tiền,&lt;br /&gt;\n	Thanh toán điện tửđược sử dụng khi chủ thể tiến hành mua hàng trên các siêu thị ảo và thanh toán qua mạng. Để thực hiện việc thanh toán, thì hệ thống máy chủ của siêu thị phải có được phầm mềm thanh toán trong website của mình.&lt;/span&gt;&lt;/p&gt;\n&lt;p&gt;\n	&lt;br /&gt;&lt;span style=&quot;font-size:14px;&quot;&gt;&lt;strong&gt;6. Quảng cáo trên Internet&lt;/strong&gt;&lt;/span&gt;&lt;/p&gt;\n&lt;p&gt;\n	&lt;br /&gt;&lt;span style=&quot;font-size:14px;&quot;&gt;     Cũng như các hình thức quảng cáo khác, quảng cáo trên mạng nhằm cung cấp thông tin đẩy nhanh tiến độ giao dịch giữa người bán và người mua. Tuy nhiên, quảng cao trên mạng khác hẳn với quảng cáo trên các phương tiện thông tin đại chúng khác vì nó giúp người tiêu dùng có thể tương tác với quảng cáo. Trên mạng mọi thứ đều có thể đưa vào quảng cáo, từ bố trí sản phẩm tới thiết kế các ảnh nền phía sau nội dung quảng cáo, làm cho logo hoặc bất cứ nhãn hiệu sản phẩm nào cũng trở nên nổi bật. Quảng cáo trên Internet cũng tạo cơ hội cho các nhà quảng cáo nhắm chính xác vào đối tượng khách hàng của mình và giúp họ quảng cáo với đúng sở thích và thị hiếu người dùng. Ngoài ra, quảng cáo trên mạng còn là sự kết hợp của quảng cáo truyền thống và tiếp thị trực tiếp. Đó là sự kết hợp giữa cung cấp nhãn hiệu, cung cấp thông tin và trao đổi buôn bán ở cùng một nơi.&lt;/span&gt;&lt;/p&gt;\n&lt;p&gt;\n	&lt;br /&gt;&lt;span style=&quot;font-size:14px;&quot;&gt;    * Các hình thức quảng cáo trên Internet&lt;/span&gt;&lt;/p&gt;\n&lt;p&gt;\n	&lt;br /&gt;&lt;span style=&quot;font-size:14px;&quot;&gt;    - Quảng cáo bằng các banner, đườn&lt;/span&gt;g link qua các website khác&lt;/p&gt;\n&lt;p&gt;\n	&lt;br /&gt;\n	      - Quảng cáo qua E-mail&lt;/p&gt;\n', '', '', NULL, 1, '2011-11-21 16:39:52', 1, 0, NULL, NULL, 1, 15);

-- --------------------------------------------------------

--
-- Table structure for table `dos_module_handbook_cat`
--

CREATE TABLE IF NOT EXISTS `dos_module_handbook_cat` (
  `cat_id` int(11) NOT NULL auto_increment,
  `cat_parent_id` int(11) NOT NULL default '0',
  `cat_title` varchar(45) NOT NULL,
  `cat_titleen` varchar(45) default NULL,
  `cat_titlefr` varchar(45) default NULL,
  `cat_order` int(11) NOT NULL default '1',
  `cat_enable` tinyint(1) NOT NULL default '1',
  PRIMARY KEY  (`cat_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=16 ;

--
-- Dumping data for table `dos_module_handbook_cat`
--

INSERT INTO `dos_module_handbook_cat` (`cat_id`, `cat_parent_id`, `cat_title`, `cat_titleen`, `cat_titlefr`, `cat_order`, `cat_enable`) VALUES
(14, 0, 'Tài liệu', '', '', 1, 1),
(15, 14, 'Thương Mại Điện Tử', '', '', 2, 1);

-- --------------------------------------------------------

--
-- Table structure for table `dos_module_message`
--

CREATE TABLE IF NOT EXISTS `dos_module_message` (
  `recipient` varchar(45) NOT NULL,
  `id_content` int(11) NOT NULL,
  `status` tinyint(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `dos_module_message`
--


-- --------------------------------------------------------

--
-- Table structure for table `dos_module_message_content`
--

CREATE TABLE IF NOT EXISTS `dos_module_message_content` (
  `record_id` int(11) NOT NULL auto_increment,
  `sender` varchar(45) NOT NULL,
  `title` varchar(100) NOT NULL,
  `content` text NOT NULL,
  `datetime` timestamp NOT NULL default CURRENT_TIMESTAMP,
  PRIMARY KEY  (`record_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=22 ;

--
-- Dumping data for table `dos_module_message_content`
--


-- --------------------------------------------------------

--
-- Table structure for table `dos_module_news`
--

CREATE TABLE IF NOT EXISTS `dos_module_news` (
  `record_id` int(11) NOT NULL auto_increment,
  `pic_thumb` varchar(45) default NULL,
  `title` varchar(100) NOT NULL,
  `titleen` varchar(100) default NULL,
  `titlefr` varchar(100) default NULL,
  `preview` text NOT NULL,
  `previewen` text,
  `previewfr` text,
  `content` text NOT NULL,
  `contenten` text,
  `contentfr` text,
  `author` varchar(45) default NULL,
  `hits` int(11) NOT NULL default '1',
  `postdate` timestamp NULL default CURRENT_TIMESTAMP,
  `record_order` int(11) NOT NULL default '1',
  `record_type` tinyint(1) NOT NULL default '0',
  `extra_field1` varchar(45) default NULL,
  `extra_field2` varchar(45) default NULL,
  `enable` tinyint(1) NOT NULL default '1',
  `dos_module_news_cat_cat_id` int(11) NOT NULL,
  PRIMARY KEY  (`record_id`),
  KEY `fk_dos_module_news_dos_module_news_cat` (`dos_module_news_cat_cat_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `dos_module_news`
--

INSERT INTO `dos_module_news` (`record_id`, `pic_thumb`, `title`, `titleen`, `titlefr`, `preview`, `previewen`, `previewfr`, `content`, `contenten`, `contentfr`, `author`, `hits`, `postdate`, `record_order`, `record_type`, `extra_field1`, `extra_field2`, `enable`, `dos_module_news_cat_cat_id`) VALUES
(1, '20111116_183626.jpg', 'NGÀY HOẠT ĐỘNG CỦA CÔNG TY 19/11/2011', '', '', '&lt;p style=&quot;text-align:center;&quot;&gt;\n	&lt;span style=&quot;font-size:16px;&quot;&gt;&lt;strong&gt;(v/v:  đi vào hoạt động của Công Ty Cổ Phần TM – DV Víp Tầm Nhìn Việt ).&lt;/strong&gt;&lt;/span&gt;&lt;/p&gt;\n&lt;p&gt;\n	&lt;span style=&quot;font-size:14px;&quot;&gt;    &lt;/span&gt;&lt;/p&gt;\n', '', '', '&lt;p&gt;\n	                  &lt;span style=&quot;font-size:20px;&quot;&gt;&lt;strong&gt;CÔNG TY CP TMDV&lt;br /&gt;\n	           VÍP TẦM NHÌN VIỆT&lt;/strong&gt;&lt;/span&gt;&lt;br /&gt;\n	     &lt;br /&gt;\n	                       &lt;span style=&quot;font-size:14px;&quot;&gt;&lt;span style=&quot;font-size:16px;&quot;&gt;Số: 001/11/VTNV                               Biên Hòa, ngày 16 .tháng 11.năm 2011&lt;/span&gt;&lt;/span&gt;&lt;br /&gt;&lt;span style=&quot;font-size:16px;&quot;&gt;       &lt;/span&gt;&lt;/p&gt;\n&lt;p style=&quot;text-align:center;&quot;&gt;\n	&lt;span style=&quot;font-size:26px;&quot;&gt;&lt;strong&gt;THÔNG BÁO&lt;/strong&gt;&lt;/span&gt;&lt;/p&gt;\n&lt;p style=&quot;text-align:center;&quot;&gt;\n	&lt;span style=&quot;font-size:18px;&quot;&gt;&lt;strong&gt;(v/v:đi vào hoạt động của Công Ty Cổ Phần TM – DV Víp Tầm Nhìn Việt)&lt;/strong&gt;.&lt;/span&gt;&lt;/p&gt;\n&lt;p&gt;\n	&lt;span style=&quot;font-size:16px;&quot;&gt;           Công Ty chúng tôi xin thông báo đến các thành viên và tất cả khách hàng,nhà đầu tư của công ty. Công Ty sẽ bắt đầu hoạt động vào: Lúc 9h thứ 7 ngày 19 tháng 11 năm 2011.&lt;/span&gt;&lt;/p&gt;\n&lt;p&gt;\n	&lt;span style=&quot;font-size:16px;&quot;&gt;  Đặc biệt đây là thời điểm sẽ bắt đầu kích hoạt thông tin của các Thành Viên đã đăng ký với Công Ty.&lt;br /&gt;\n	          Để chuẩn bị cho sự kiện ngày khai trương Công Ty VÍP TẦM NHÌN VIỆT, Công ty có chương trình khích lệ cho các khách hàng và thành viên tham gia.&lt;/span&gt;&lt;/p&gt;\n&lt;p&gt;\n	&lt;span style=&quot;font-size:16px;&quot;&gt;           Chương trình khích lệ như sau:&lt;/span&gt;&lt;/p&gt;\n&lt;p&gt;\n	&lt;span style=&quot;font-size:16px;&quot;&gt;      - Thành viên khi tham gia một gian hàng sẽ được một vé tham dự sự kiện khai trương của công ty.&lt;br /&gt;\n	      -  Thời gian tính từ ngày 19 tháng 11 năm 2011 cho đến ngày công ty khai trương                       ( Ngày khai trương xin thông báo sau).&lt;/span&gt;&lt;/p&gt;\n&lt;p&gt;\n	&lt;span style=&quot;font-size:16px;&quot;&gt;Trân trọng thông báo.                                &lt;/span&gt;&lt;/p&gt;\n&lt;p&gt;\n	&lt;span style=&quot;font-size:16px;&quot;&gt;Gửi đến:                                                                                     GIÁM ĐỐC&lt;br /&gt;\n	               - Ban Giám Đốc                                                              (Đã ký)&lt;br /&gt;\n	               - Văn thư công ty&lt;br /&gt;\n	               - Thành Viên&lt;br /&gt;\n	               - Khách Hàng&lt;br /&gt;\n	               - Các nhà đầu tư                                                                                                                                    &lt;br /&gt;\n	                                                                                              Đinh Quốc Huân&lt;/span&gt;&lt;br /&gt;\n	 &lt;/p&gt;\n', '', '', NULL, 1, '2011-11-16 10:23:20', 1, 1, NULL, NULL, 1, 13),
(2, '20111116_1836265.jpg', 'LỊCH LÀM VIỆC TẠI CÔNG TY', '', '', '&lt;p&gt;\n	&lt;span style=&quot;font-size:16px;&quot;&gt;LỊCH LÀM VIỆC TRONG THÁNG&lt;/span&gt;&lt;/p&gt;\n', '', '', '&lt;p&gt;\n	&lt;img alt=&quot;&quot; src=&quot;/public/userfiles/images/lich%20moi.jpg&quot; style=&quot;width:700px;height:514px;&quot; /&gt;&lt;/p&gt;\n', '', '', NULL, 1, '2011-11-16 10:51:10', 2, 0, NULL, NULL, 1, 13),
(3, '20111116_1836268.jpg', ' Làm thẻ thành viên và card ', '', '', '&lt;p&gt;\n	&lt;span style=&quot;font-size:18px;&quot;&gt;&lt;strong&gt;THÔNG BÁO&lt;/strong&gt;&lt;/span&gt;&lt;/p&gt;\n&lt;p&gt;\n	&lt;strong&gt;                                                                         &lt;/strong&gt;&lt;/p&gt;\n&lt;p&gt;\n	&lt;strong&gt;       &lt;/strong&gt;&lt;/p&gt;\n&lt;p&gt;\n	 &lt;/p&gt;\n&lt;p&gt;\n	&lt;strong&gt;                                                                            &lt;br /&gt;\n	                                                                                                                                &lt;/strong&gt;&lt;/p&gt;\n&lt;p&gt;\n	&lt;br /&gt;\n	 &lt;/p&gt;\n', '', '', '&lt;p&gt;\n	&lt;span style=&quot;font-size:14px;&quot;&gt;&lt;strong&gt;Công Ty CP TM – DV                                                                                   &lt;br /&gt;\n	Víp Tầm Nhìn Việt&lt;/strong&gt;&lt;/span&gt;&lt;/p&gt;\n&lt;p&gt;\n	        &lt;strong&gt;&lt;em&gt;Số: 002/11&lt;/em&gt;&lt;/strong&gt;&lt;br /&gt;\n	                                                                                    &lt;span style=&quot;font-size:20px;&quot;&gt;&lt;strong&gt; THÔNG BÁO&lt;/strong&gt;&lt;/span&gt;&lt;/p&gt;\n&lt;p&gt;\n	 &lt;/p&gt;\n&lt;p&gt;\n	                                                                     &lt;strong&gt;      ( v/v: Làm thẻ thành viên và card )&lt;/strong&gt;&lt;/p&gt;\n&lt;p&gt;\n	 &lt;/p&gt;\n&lt;p&gt;\n	&lt;strong&gt;       Công ty xin thông báo tới tất cả các Thành viên về việc làm thẻ và card của mỗi Thành viên, đây là một trong các thông tin quan trong khi các Thành viên đã đăng ký làm Thành viên với công ty.&lt;/strong&gt;&lt;/p&gt;\n&lt;p&gt;\n	&lt;br /&gt;&lt;strong&gt;Phí làm thẻ:      10.000đ/ một thẻ.&lt;/strong&gt;&lt;/p&gt;\n&lt;p&gt;\n	&lt;br /&gt;&lt;strong&gt;Phí làm card:    50.000đ/ một card.&lt;/strong&gt;&lt;/p&gt;\n&lt;p&gt;\n	&lt;br /&gt;&lt;strong&gt;( Thành viên đăng ký và nộp phí tại quầy thu ngân ).&lt;/strong&gt;&lt;/p&gt;\n&lt;p&gt;\n	&lt;strong&gt;                                               &lt;br /&gt;\n	                                                                                                           Biên Hòa, Ngày 19 tháng 11 năm 2011&lt;br /&gt;\n	                                                 &lt;br /&gt;\n	                                                                                                                                           Giám Đốc&lt;/strong&gt;&lt;/p&gt;\n&lt;p&gt;\n	 &lt;/p&gt;\n&lt;p&gt;\n	&lt;strong&gt;                                                                            &lt;br /&gt;\n	                                                                                                                                        Đinh Quốc Huân&lt;/strong&gt;&lt;/p&gt;\n&lt;p&gt;\n	&lt;br /&gt;\n	 &lt;/p&gt;\n', '', '', NULL, 1, '2011-11-20 08:47:39', 3, 0, NULL, NULL, 1, 13),
(4, '20111116_18362687.jpg', ' Tặng kèm sản phẩm cho các Thành viên ', '', '', '&lt;p&gt;\n	&lt;strong&gt;  &lt;/strong&gt;&lt;strong&gt;THÔNG BÁO&lt;/strong&gt;&lt;/p&gt;\n', '', '', '&lt;p&gt;\n	&lt;span style=&quot;font-size:14px;&quot;&gt;&lt;strong&gt;Công Ty CP TM – DV                                                                                Số: 004/11&lt;br /&gt;\n	  Víp Tầm Nhìn Việt&lt;/strong&gt;&lt;/span&gt;&lt;/p&gt;\n&lt;p style=&quot;text-align:center;&quot;&gt;\n	&lt;br /&gt;&lt;strong&gt;&lt;span style=&quot;font-size:18px;&quot;&gt;THÔNG BÁO&lt;/span&gt;&lt;/strong&gt;&lt;/p&gt;\n&lt;p style=&quot;text-align:center;&quot;&gt;\n	 &lt;/p&gt;\n&lt;p style=&quot;text-align:center;&quot;&gt;\n	&lt;strong&gt;&lt;span style=&quot;font-size:14px;&quot;&gt;( v/v: Sản phẩm tặng cho các Thành viên )&lt;/span&gt;&lt;/strong&gt;&lt;/p&gt;\n&lt;p style=&quot;text-align:center;&quot;&gt;\n	 &lt;/p&gt;\n&lt;p&gt;\n	         &lt;span style=&quot;font-size:14px;&quot;&gt;  Công ty xin thông báo tới tất cả các Thành viên về việc nhận sản phẩm tặng kèm theo gian hàng.&lt;br /&gt;\n	         Tất cả các thành viên khi đăng ký gian hàng sẽ được nhận bộ sản phẩm Công ty tặng vào ngày khai trương Công ty ( Ngày khai trương xin thông báo sau ).&lt;/span&gt;&lt;/p&gt;\n&lt;p&gt;\n	&lt;span style=&quot;font-size:14px;&quot;&gt;   Trân trọng thông báo                                    &lt;/span&gt;&lt;/p&gt;\n&lt;p&gt;\n	&lt;span style=&quot;font-size:14px;&quot;&gt;                                                                                  Biên Hòa, ngày 16 tháng 11 năm 2011&lt;br /&gt;\n	    &lt;/span&gt;&lt;/p&gt;\n&lt;p&gt;\n	&lt;span style=&quot;font-size:14px;&quot;&gt;        Gửi đến                                                                               Giám Đốc&lt;/span&gt;&lt;/p&gt;\n&lt;p&gt;\n	&lt;span style=&quot;font-size:14px;&quot;&gt;     Ban Giám Đốc                                                                         ( Đã Ký )&lt;br /&gt;\n	     Văn thư&lt;br /&gt;\n	     Thành Viên&lt;/span&gt;&lt;/p&gt;\n&lt;p&gt;\n	&lt;span style=&quot;font-size:14px;&quot;&gt;                                                                                                Đinh Quốc Huân.&lt;/span&gt;&lt;/p&gt;\n', '', '', NULL, 1, '2011-11-21 15:30:47', 4, 0, NULL, NULL, 1, 13),
(5, '20111116_18362688.jpg', '( v/v: Nộp thuế VAT và thu nhập cá nhân )', '', '', '&lt;p&gt;\n	&lt;span style=&quot;font-size:16px;&quot;&gt;&lt;strong&gt;THÔNG BÁO&lt;/strong&gt;&lt;/span&gt;&lt;/p&gt;\n', '', '', '&lt;p&gt;\n	&lt;span style=&quot;font-size:14px;&quot;&gt;&lt;strong&gt;Công Ty CP TM – DV                                                                                Số: 003/11&lt;br /&gt;\n	  Víp Tầm Nhìn Việt&lt;/strong&gt;&lt;/span&gt;&lt;/p&gt;\n&lt;p style=&quot;text-align:center;&quot;&gt;\n	&lt;br /&gt;&lt;strong&gt;&lt;span style=&quot;font-size:18px;&quot;&gt;THÔNG BÁO&lt;/span&gt;&lt;/strong&gt;&lt;/p&gt;\n&lt;p style=&quot;text-align:center;&quot;&gt;\n	&lt;span style=&quot;font-size:14px;&quot;&gt;&lt;strong&gt;( v/v: Nộp thuế VAT và thu nhập cá nhân &lt;/strong&gt;&lt;/span&gt;)&lt;/p&gt;\n&lt;p&gt;\n	         &lt;span style=&quot;font-size:14px;&quot;&gt;Công ty xin thông báo tới tất cả các Thành viên về việc nộp thuế giá trị gia tăng ( VAT ) và làm tờ khai thuế thu nhập cá nhân.&lt;br /&gt;\n	       Tất cả các thành viên công ty có phát sinh hoa hồng dịch vụ ( tiền Thương Mại Điện Tử ) đều phải nộp lại 10% thuế giá trị gia tăng theo qui định Nhà Nước. Các khoản khấu trừ trên sẽ được trừ lại trước khi thanh toán cho các Thành viên tại Phòng Hành Chính.&lt;br /&gt;\n	       Thuế thu nhập cá nhân: Các thành viên nào có mã số thuế thu nhập cá nhân rồi thì nộp lại thông tin cho kế toán, thành viên nào chưa có mã số thuế thì mỗi người nộp một chứng minh thư phô tô và điền thông tin theo mẫu đăng ký &lt;strong&gt;( mẫu đăng ký liên hệ Phòng Hành Chính )&lt;/strong&gt;.&lt;/span&gt;&lt;/p&gt;\n&lt;p&gt;\n	&lt;span style=&quot;font-size:14px;&quot;&gt;             Trân trọng thong báo                                          Biên Hòa, Ngày 21 tháng 11 năm 2011&lt;br /&gt;\n	                                  &lt;br /&gt;\n	                     Gửi đến                                                                               Giám Đốc&lt;br /&gt;\n	                                                                                                                 ( Đã ký )&lt;br /&gt;\n	                   Ban Giám Đốc&lt;br /&gt;\n	                   Văn Thư&lt;br /&gt;\n	                   Thành Viên&lt;br /&gt;\n	                                                                                                             Đinh Quốc&lt;/span&gt; Huân.&lt;/p&gt;\n&lt;p&gt;\n	 &lt;/p&gt;\n', '', '', NULL, 1, '2011-11-21 17:00:23', 5, 0, NULL, NULL, 1, 13);

-- --------------------------------------------------------

--
-- Table structure for table `dos_module_news_cat`
--

CREATE TABLE IF NOT EXISTS `dos_module_news_cat` (
  `cat_id` int(11) NOT NULL auto_increment,
  `cat_parent_id` int(11) NOT NULL default '0',
  `cat_title` varchar(45) NOT NULL,
  `cat_titleen` varchar(45) default NULL,
  `cat_titlefr` varchar(45) default NULL,
  `cat_order` int(11) NOT NULL default '1',
  `cat_enable` tinyint(1) NOT NULL default '1',
  PRIMARY KEY  (`cat_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=14 ;

--
-- Dumping data for table `dos_module_news_cat`
--

INSERT INTO `dos_module_news_cat` (`cat_id`, `cat_parent_id`, `cat_title`, `cat_titleen`, `cat_titlefr`, `cat_order`, `cat_enable`) VALUES
(12, 0, 'Tin tức- sự kiện', '', '', 2, 1),
(13, 0, 'THÔNG BÁO', '', '', 3, 1);

-- --------------------------------------------------------

--
-- Table structure for table `dos_module_payment`
--

CREATE TABLE IF NOT EXISTS `dos_module_payment` (
  `record_id` int(11) NOT NULL auto_increment,
  `title` varchar(45) default NULL,
  `titleen` varchar(45) default NULL,
  `titlefr` varchar(45) default NULL,
  `content` text,
  `contenten` text,
  `contentfr` text,
  `hits` int(11) default '1',
  `posted_date` timestamp NULL default CURRENT_TIMESTAMP,
  `record_order` int(11) default '1',
  `extra_field1` varchar(45) default NULL,
  `extra_field2` varchar(45) default NULL,
  `hot` tinyint(1) NOT NULL default '0',
  `enable` tinyint(1) default '1',
  PRIMARY KEY  (`record_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `dos_module_payment`
--


-- --------------------------------------------------------

--
-- Table structure for table `dos_module_product`
--

CREATE TABLE IF NOT EXISTS `dos_module_product` (
  `record_id` int(11) NOT NULL auto_increment,
  `postdate` timestamp NOT NULL default CURRENT_TIMESTAMP,
  `pic_thumb` varchar(45) default NULL,
  `pic_full` varchar(45) default NULL,
  `pic_desc` varchar(1000) default NULL,
  `title` varchar(100) NOT NULL,
  `titleen` varchar(100) default NULL,
  `titlefr` varchar(100) default NULL,
  `detail` text NOT NULL,
  `detailen` text,
  `detailfr` text,
  `hits` int(11) default '0',
  `record_order` int(11) default '1',
  `extra_field1` varchar(45) default NULL,
  `extra_field2` varchar(45) default NULL,
  `extra_field3` varchar(45) default NULL,
  `extra_field4` varchar(45) default NULL,
  `unit` int(11) NOT NULL default '0',
  `hot` tinyint(1) default '0',
  `enable` tinyint(1) default '1',
  `dos_module_product_cat_cat_id` int(11) NOT NULL,
  `dos_sys_users_username` varchar(45) NOT NULL,
  PRIMARY KEY  (`record_id`),
  KEY `fk_dos_module_product_dos_module_product_cat` (`dos_module_product_cat_cat_id`),
  KEY `fk_dos_module_product_dos_sys_users` (`dos_sys_users_username`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=65 ;

--
-- Dumping data for table `dos_module_product`
--

INSERT INTO `dos_module_product` (`record_id`, `postdate`, `pic_thumb`, `pic_full`, `pic_desc`, `title`, `titleen`, `titlefr`, `detail`, `detailen`, `detailfr`, `hits`, `record_order`, `extra_field1`, `extra_field2`, `extra_field3`, `extra_field4`, `unit`, `hot`, `enable`, `dos_module_product_cat_cat_id`, `dos_sys_users_username`) VALUES
(21, '2011-11-11 02:21:32', '8814053396839nx90jq_200x200_small.jpg', '8814053396839nx90jq_200x200_small1.jpg', NULL, 'ASUS NX90JQ - YZ054V', '', '', '&lt;p&gt;\n	ASUS NX90JQ - YZ054V&lt;br /&gt;&lt;br /&gt;\n	ASUS NX90JQ - YZ054V (KHÔNG TẶNG TÚI)&lt;br /&gt;\n	- Intel Core i7-720M 1.6GHz&lt;br /&gt;\n	- DDRAM 8GB/1333&lt;br /&gt;\n	- HDD 1TB SATA&lt;br /&gt;\n	- NVIDIA GF G335 1G upto 4095MB&lt;br /&gt;\n	- Blue-ray Combo&lt;br /&gt;\n	- Card Reader - eSATA&lt;br /&gt;\n	- 18.4&quot; FULL HD LED - HDMI - Webcam&lt;br /&gt;\n	- LAN 10/100/1000 - Wireless N - Bluetooth&lt;br /&gt;\n	- Weight 3.2Kg - Battery 6 Cell&lt;br /&gt;\n	- OS WIN 7 Premium 64Bits&lt;/p&gt;\n&lt;p&gt;\n	LIÊN HỆ ĐẶT HÀNG&lt;/p&gt;\n&lt;p&gt;\n	IMAI: viptamnhinviet@gmai.com&lt;/p&gt;\n&lt;p&gt;\n	ĐT: 0987976879&lt;/p&gt;\n', '', '', 0, 1, '', '', '', '', 46818000, 1, 1, 13, 'viptamnhinviet'),
(22, '2011-11-11 02:24:16', '2554449998274g51j_200x200_small.jpg', '2554449998274g51j_200x200_small5.jpg', NULL, 'ASUS G51J i7-720QM', '', '', '&lt;p&gt;\n	ASUS G51J i7-720QM&lt;br /&gt;\n	- Intel Core i7-720M 1.6GHz&lt;br /&gt;\n	- DDRAM 2GB/1066&lt;br /&gt;\n	- HDD 500GB SATA&lt;br /&gt;\n	- NVIDIA GF GTS360 1GB&lt;br /&gt;\n	- DVD-RW&lt;br /&gt;\n	- Card Reader - eSATA&lt;br /&gt;\n	- 15.6&quot; FULL HD LED - HDMI - Webcam 2.0&lt;br /&gt;\n	- LAN 10/100/1000 - Wireless N - Bluetooth&lt;br /&gt;\n	- Weight 3.2Kg - Battery 6 Cell&lt;br /&gt;\n	- OS Option&lt;/p&gt;\n&lt;p&gt;\n	LIÊN HỆ ĐẶT HÀNG&lt;/p&gt;\n&lt;p&gt;\n	IMAIL: viptamnhinviet@gmail.com&lt;/p&gt;\n&lt;p&gt;\n	ĐT: 0987976879&lt;/p&gt;\n', '', '', 0, 1, '', '', '', '', 29455000, 1, 1, 13, 'viptamnhinviet'),
(23, '2011-11-11 02:26:12', '4511719353141np300_200x200_small.jpg', '4511719353141np300_200x200_small5.jpg', NULL, 'SAMSUNG NP300V4Z-S04VN', '', '', '&lt;p&gt;\n	SAMSUNG NP300V4Z-S04VN&lt;br /&gt;\n	- Intel Core i5-2430 2.2GHz - 3M&lt;br /&gt;\n	- DDRAM 4GB/1333&lt;br /&gt;\n	- HDD 640GB SATA&lt;br /&gt;\n	- NVIDIA GF GT520MX 1GB&lt;br /&gt;\n	- DVD-RW&lt;br /&gt;\n	- Card Reader 4.1&lt;br /&gt;\n	- 14.0&quot; HD LED - HDMI - Webcam&lt;br /&gt;\n	- LAN 10/100/1000 - Wireless N - Bluetooth&lt;br /&gt;\n	- Weight 2.16Kg - Battery 6 Cells&lt;br /&gt;\n	- OS Option&lt;/p&gt;\n&lt;p&gt;\n	LIÊN HỆ ĐẶT HÀNG&lt;/p&gt;\n&lt;p&gt;\n	IMAIL:viptamnhinviet@gmail.com&lt;/p&gt;\n&lt;p&gt;\n	ĐT: 0987976879&lt;/p&gt;\n', '', '', 0, 2, '', '', '', '', 14000000, 1, 1, 12, 'viptamnhinviet'),
(24, '2011-11-11 02:29:49', '2574266581046dv4_200x200_small.jpg', '2574266581046dv4_200x200_small4.jpg', NULL, 'HP DV4 3002TX LN338PA', '', '', '&lt;p&gt;\n	HP DV4 3002TX LN338PA&lt;br /&gt;\n	- Intel Core i3-2310M 2.1GHz&lt;br /&gt;\n	- DDRAM 2GB/1333&lt;br /&gt;\n	- HDD 500GB&lt;br /&gt;\n	- ATI HD 6750M 1GB//Intel HD&lt;br /&gt;\n	- DVD-RW&lt;br /&gt;\n	- Card Reader 5.1 - 2x USB 3.0&lt;br /&gt;\n	- 14&quot; WXGA - Webcam&lt;br /&gt;\n	- LAN 10/100/1000 - Wireless N - Bluetooth&lt;br /&gt;\n	- Weight 2.63Kg - Battery 6 Cell&lt;br /&gt;\n	- OS Win 7 Basic&lt;/p&gt;\n&lt;p&gt;\n	LIÊN HỆ ĐẶT HÀNG&lt;/p&gt;\n&lt;p&gt;\n	IMAIL: viptamnhinviet@gmail.com&lt;/p&gt;\n&lt;p&gt;\n	ĐT: 0987976879&lt;/p&gt;\n', '', '', 0, 1, '', '', '', '', 15091000, 1, 1, 11, 'viptamnhinviet'),
(26, '2011-11-11 05:03:21', 'small_win1317713285.jpg', 'small_win13177132855.jpg', NULL, 'Apple iPhone 4S 32GB White (Bản quốc tế)', '', '', '&lt;p&gt;\n	Apple iPhone 4S 32GB White (Bản quốc tế)&lt;br /&gt;\n	Giá chưa VAT: 21.490.000 VNĐ&lt;br /&gt;\n	Phải +10% VAT: 2.149.000 VNĐ&lt;br /&gt;\n	Giá bán cuối: 23.639.000 VNĐ&lt;br /&gt;\n	(Phải lấy VAT)&lt;br /&gt;\n	Báo sai giá Báo hết hàng&lt;br /&gt;\n	Cập nhật: 06/11/2011 - 08:53 AM&lt;br /&gt;\n	Đặt hàng: / 1 sản phẩm&lt;br /&gt;\n	Tình trạng: Mới&lt;br /&gt;\n	Xuất xứ: Chính hãng&lt;br /&gt;\n	LIÊN HỆ ĐẶT HÀNG&lt;/p&gt;\n&lt;p&gt;\n	IMAIL: viptamnhinviet@gmail.com&lt;/p&gt;\n', '', '', 0, 6, '', '', '', '', 23639000, 1, 1, 7, 'viptamnhinviet'),
(27, '2011-11-11 05:05:57', 'small_oau1313054972.jpg', 'small_oau13130549729.jpg', NULL, ' Điện thoại - PDA Sharp 003sh', '', '', '&lt;p&gt;\n	Giá chưa VAT: 5.909.100 VNĐ&lt;br /&gt;\n	Phải +10% VAT: 590.900 VNĐ&lt;br /&gt;\n	Giá bán cuối: 6.500.000 VNĐ&lt;br /&gt;\n	(Phải lấy VAT)&lt;br /&gt;\n	Báo sai giá Báo hết hàng&lt;br /&gt;\n	Cập nhật: 10/11/2011 - 15:15 PM &lt;br /&gt;\n	Đặt hàng: / 10 sản phẩm&lt;br /&gt;\n	Bảo hành: 1 Tháng&lt;br /&gt;\n	Tình trạng: Mới&lt;br /&gt;\n	Xuất xứ: Xách tay&lt;br /&gt;\n	LIÊN HỆ ĐẶT HÀNG&lt;/p&gt;\n&lt;p&gt;\n	GMAIL:viptamnhinviet@gmail.com&lt;/p&gt;\n&lt;p&gt;\n	ĐT:0987976879&lt;/p&gt;\n', '', '', 0, 7, '', '', '', '', 6650000, 1, 1, 7, 'viptamnhinviet'),
(33, '2011-11-11 08:01:35', '5158044945931wildfire-s_200x200_small.jpg', '5158044945931wildfire-s_200x200_small1.jpg', NULL, 'HTC WILDFIRE S A510', '', '', '&lt;p&gt;\n	* Hệ điều hành Android 2.3&lt;br /&gt;\n	* Máy ảnh 5.0 MP với auto focus&lt;br /&gt;\n	* Đài FM radio với RD, nghe nhạc, xem phim&lt;br /&gt;\n	* Bộ nhớ trng 512 MB hỗ trợ thẻ lên đến 32 GB&lt;br /&gt;\n	* Google Search, Maps, Gmail, YouTube, Google Talk...&lt;br /&gt;\n	* Kết nối 3G, Wi-Fi, Bluetooth tốc độ cao&lt;br /&gt;\n	* Định vị toàn cầu với A-GP&lt;br /&gt;\n	* Hỗ trợ xem file văn bản&lt;/p&gt;\n&lt;p&gt;\n	LIÊN HỆ ĐẶT HÀNG: CONG TY VIP TẦM NHÌN VIỆT&lt;/p&gt;\n&lt;p&gt;\n	MAIL: VIPTAMNHINVIET@GMAIL.COM&lt;/p&gt;\n&lt;p&gt;\n	ĐT: 098,79,76,879&lt;/p&gt;\n&lt;p&gt;\n	 &lt;/p&gt;\n', '', '', 0, 9, '', '', '', '', 6000000, 1, 1, 7, 'viptamnhinviet'),
(34, '2011-11-11 08:05:41', '4569644793964galaxy-sii_200x200_small.jpg', '4569644793964galaxy-sii_200x200_small9.jpg', NULL, 'SAMSUNG I9100 GALAXY S II Black', '', '', '&lt;p&gt;\n	 &lt;/p&gt;\n&lt;table border=&quot;0&quot; cellpadding=&quot;0&quot; cellspacing=&quot;2&quot; width=&quot;100%&quot;&gt;&lt;tbody&gt;&lt;tr valign=&quot;top&quot;&gt;&lt;td class=&quot;thongtinsp&quot;&gt;\n				 &lt;/td&gt;\n		&lt;/tr&gt;&lt;tr valign=&quot;top&quot;&gt;&lt;td class=&quot;thongtinsp&quot;&gt;\n				&lt;ul&gt;&lt;li&gt;\n						Điện thoại thiết kế cực mỏng&lt;/li&gt;\n					&lt;li&gt;\n						Màn hình Super AMOLED Plus 16 triệu màu&lt;/li&gt;\n					&lt;li&gt;\n						Sử dụng hệ điều hành Android 2.3&lt;/li&gt;\n					&lt;li&gt;\n						Máy ảnh 8.0 MP tự động lấy nét, nhận diện khuôn mặt và nụ cười&lt;/li&gt;\n					&lt;li&gt;\n						Hỗ trợ quay phim chuẩn HD 1080p&lt;/li&gt;\n					&lt;li&gt;\n						Định vị toàn cầu với A-GPS&lt;/li&gt;\n					&lt;li&gt;\n						Kết nối 3G, Wifi, Bluetooth, HDMI&lt;/li&gt;\n					&lt;li&gt;\n						Google Search, Maps, Gmail, YouTube, Calendar, Google Talk&lt;/li&gt;\n					&lt;li&gt;\n						Hỗ trợ đọc và soạn thảo văn bản&lt;/li&gt;\n					&lt;li&gt;\n						LIÊN HỆ ĐĂT HÀNG\n						&lt;p&gt;\n							IMAIL: viptamnhinviet@gmail.com&lt;/p&gt;\n						ĐT: 0987 976 879&lt;/li&gt;\n				&lt;/ul&gt;&lt;/td&gt;\n		&lt;/tr&gt;&lt;/tbody&gt;&lt;/table&gt;&lt;p&gt;\n	 &lt;/p&gt;\n', '', '', 0, 12, '', '', '', '', 12999000, 1, 1, 7, 'viptamnhinviet'),
(35, '2011-11-11 08:11:00', '1208781dcrpj5.jpg', '1208781dcrpj58.jpg', NULL, 'MÁY QUAY PHIM SONY KTS ', '', '', '&lt;p&gt;\n	&lt;br /&gt;\n	* Trình chiếu hình ảnh lên đến kích thước 60inch lên bề mặt phẳng (trong môi trường hoàn toàn tối)&lt;br /&gt;\n	* Loa Stereo mạnh mẽ giúp bạn thưởng thức từng hành động thật trọn vẹn&lt;br /&gt;\n	* CCD 1/8” 800.000 Pixel&lt;br /&gt;\n	* Bộ xử lý hình ảnh Sony Imaging Processor&lt;br /&gt;\n	* Ống kính Sony với Zoom quang học 57x&lt;br /&gt;\n	* Zoom mở rộng lên đến 67x&lt;br /&gt;\n	* Chống rung và ổn định hình ảnh quang học&lt;br /&gt;\n	* Màn hình 2.7 inch Clear Photo LCD, 230.400 điểm ảnh, điều khiển bằng Joint Stick trên khung LCD&lt;br /&gt;\n	* iAuto – Tự động thay đổi cài đặt thông minh&lt;br /&gt;\n	* Face detection – cân đỉnh độ phơi sáng khuôn mặt&lt;br /&gt;\n	* Độ phân giải ảnh tỉnh tối đa 560.000 pixels (4:3)&lt;br /&gt;\n	* Copy trực tiếp vào ổ đĩa cứng ngoài (HDD, USB)&lt;br /&gt;\n	* Phần mềm PMB Portable&lt;br /&gt;\n	* Cổng kết nối : AV/ USB 2.0&lt;br /&gt;\n	* Phụ kiện đi kèm: AC adaptor, Bộ pin sạc, Dây AV, Cáp USB&lt;/p&gt;\n&lt;p&gt;\n	LIÊN HỆ ĐẶT HÀNG&lt;/p&gt;\n&lt;p&gt;\n	IMAIL:viptamnhinviet@gmail.com&lt;/p&gt;\n&lt;p&gt;\n	ĐT: 0987976879&lt;/p&gt;\n&lt;p&gt;\n	 &lt;/p&gt;\n', '', '', 0, 18, '', '', '', '', 8990000, 1, 1, 9, 'viptamnhinviet'),
(37, '2011-11-11 08:30:53', '74338_lcd_sony_kdl_40ex520_me6.jpg', '74338_lcd_sony_kdl_40ex520_me64.jpg', NULL, 'LCD SONY KDL-40EX520 SP1', '', '', '&lt;p&gt;\n	Tivi LCD BRAVIA Full HD 40 inch dòng EX520&lt;/p&gt;\n&lt;p&gt;\n	Thưởng thức hàng ngàn bộ phim, video và âm nhạc trên chiếc Tivi Full HD dòng EX520 tuyệt đẹp. Hãy truy cập đến những nội dung trực tuyến với Sony Internet Tivi hoặc đơn giản để chia sẻ nội dung qua DLNA hay thưởng thức chức năng phát qua USB thật thú vị.&lt;/p&gt;\n&lt;p&gt;\n	* Màn hình LED 40&quot;&lt;br /&gt;\n	* Sử dụng công nghệ đèn nền LED&lt;br /&gt;\n	* Kết nối Internet qua Bravia Internet Video (cần trang bị thêm wireless USB)&lt;br /&gt;\n	* Hình ảnh chất lượng cao Full HD 1080 với đèn nền Edge LED&lt;br /&gt;\n	* Hội thoại trực tuyến với Skype™ sẵn sàng (cần trang bị thêm camera CMU-BR100)&lt;br /&gt;\n	* Xem phim, tin tức trực tuyến với tính năng BRAVIA Internet Video và BRAVIA Internet Widgets&lt;br /&gt;\n	* Kết nối mạng không dây và Wi-fi trực tiếp (cần trang bị thêm Wi-fi UWA-BR100)&lt;br /&gt;\n	* Bộ xử lý hình ảnh vượt trội X-Reality™&lt;br /&gt;\n	* Công nghệ tái tạo màu sắc trung thực Live Colour™ nâng cao độ tương phản tiên tiến&lt;br /&gt;\n	* Đồng bộ BRAVIA Sync, Chức năng hình trong hình (PIP)&lt;/p&gt;\n&lt;p&gt;\n	BRAVIA Internet Video&lt;/p&gt;\n&lt;p&gt;\n	LIÊN HỆ ĐĂT HÀNG&lt;/p&gt;\n&lt;p&gt;\n	IMAIL: viptamnhinviet@gmail.com&lt;br /&gt;\n	ĐT: 0987 976 879&lt;/p&gt;\n', '', '', 0, 27, '', '', '', '', 18999000, 1, 1, 16, 'viptamnhinviet'),
(42, '2011-11-11 08:59:13', 'sr270r_450_1.jpg', 'sr270r_450_17.jpg', NULL, 'Tủ lạnh Sanyo SR-270R', '', '', '&lt;p&gt;\n	* Dung tich 270 Lít&lt;br /&gt;\n	* Loại tủ 2 cửa, không đóng tuyết&lt;br /&gt;\n	* Công nghệ khử mùi và diệt khuẩn Nano Fresh+&lt;br /&gt;\n	* Thiết kế mới với ngăn lạnh 170L nằm trên cùng&lt;br /&gt;\n	* khay kính chịu lực&lt;/p&gt;\n&lt;p&gt;\n	LIÊN HỆ ĐĂT HÀNG&lt;/p&gt;\n&lt;p&gt;\n	IMAIL: viptamnhinviet@gmail.com&lt;/p&gt;\n&lt;p&gt;\n	ĐT: 0987 976 879&lt;/p&gt;\n', '', '', 0, 19, '', '', '', '', 10640000, 1, 1, 9, 'viptamnhinviet'),
(43, '2011-11-11 09:06:38', 'buystrip_ipads_20111005.png', 'buystrip_ipads_201110054.png', NULL, 'MÁY iPad 2. From $499', '', '', '&lt;p&gt;\n	Shop online.&lt;/p&gt;\n&lt;p&gt;\n	Order your iPad online and have it engraved and shipped to your door — free.&lt;br /&gt;\n	Buy iPad 2 now&lt;/p&gt;\n&lt;p&gt;\n	LIÊN HỆ ĐĂT HÀNG&lt;/p&gt;\n&lt;p&gt;\n	IMAIL: viptamnhinviet@gmail.com&lt;br /&gt;\n	ĐT: 0987 976 879&lt;/p&gt;\n', '', '', 0, 11, '', '', '', '', 12000000, 1, 1, 7, 'viptamnhinviet'),
(53, '2011-11-16 01:59:33', 'xang_4ml_m71.jpg', 'toroi2_483x1035.jpg', NULL, ' CÔNG NGHỆ TIẾT KIỆM XĂNG, DẦU', '', '', '&lt;p style=&quot;text-align:center;&quot;&gt;\n	&lt;strong&gt;SẢN PHẨM CÔNG NGHỆ TIẾT KIỆM XĂNG, DẦU&lt;/strong&gt;&lt;/p&gt;\n&lt;p style=&quot;text-align:center;&quot;&gt;\n	&lt;strong&gt;GIẢM TIẾT KIỆM 15% - 25% NHIÊN LIỆU BẰNG CÔNG NGHỆ NANO CỦA MỸ&lt;/strong&gt;&lt;/p&gt;\n&lt;p style=&quot;text-align:center;&quot;&gt;\n	&lt;strong&gt;ĐÂY LÀ MỘT TRONG NHỮNG CÔNG NGHỆ NỔI TIẾNG ĐƯỢC NHẬP KHẨU TỪ MỸ VỀ VIỆT NAM.&lt;/strong&gt;&lt;/p&gt;\n&lt;p style=&quot;text-align:center;&quot;&gt;\n	&lt;img alt=&quot;&quot; src=&quot;/public/userfiles/images/2.jpg&quot; style=&quot;width:422px;height:594px;&quot; /&gt;&lt;/p&gt;\n&lt;p style=&quot;text-align:center;&quot;&gt;\n	&lt;img alt=&quot;&quot; src=&quot;/public/userfiles/images/3.jpg&quot; style=&quot;width:419px;height:576px;&quot; /&gt;&lt;/p&gt;\n&lt;p style=&quot;text-align:center;&quot;&gt;\n	&lt;img alt=&quot;&quot; src=&quot;/public/userfiles/images/4.jpg&quot; style=&quot;width:415px;height:586px;&quot; /&gt;&lt;/p&gt;\n&lt;p style=&quot;text-align:center;&quot;&gt;\n	&lt;img alt=&quot;&quot; src=&quot;/public/userfiles/images/2011-11-14_113258.jpg&quot; style=&quot;width:416px;height:587px;&quot; /&gt;&lt;/p&gt;\n&lt;p style=&quot;text-align:center;&quot;&gt;\n	&lt;img alt=&quot;&quot; src=&quot;/public/userfiles/images/6.jpg&quot; style=&quot;width:451px;height:550px;&quot; /&gt;&lt;/p&gt;\n&lt;p style=&quot;text-align:center;&quot;&gt;\n	&lt;img alt=&quot;&quot; src=&quot;/public/userfiles/images/HoSoPhapLy_06.jpg&quot; style=&quot;width:419px;height:592px;&quot; /&gt;&lt;/p&gt;\n&lt;p style=&quot;text-align:center;&quot;&gt;\n	&lt;img alt=&quot;&quot; src=&quot;/public/userfiles/images/HoSoPhapLy_07.jpg&quot; style=&quot;width:417px;height:589px;&quot; /&gt;&lt;/p&gt;\n&lt;p style=&quot;text-align:center;&quot;&gt;\n	&lt;img alt=&quot;&quot; src=&quot;/public/userfiles/images/HoSoPhapLy_08.jpg&quot; style=&quot;width:438px;height:620px;&quot; /&gt;&lt;img alt=&quot;&quot; src=&quot;/public/userfiles/images/HoSoPhapLy_09.jpg&quot; style=&quot;width:444px;height:626px;&quot; /&gt;&lt;/p&gt;\n&lt;p style=&quot;text-align:center;&quot;&gt;\n	&lt;img alt=&quot;&quot; src=&quot;/public/userfiles/images/HoSoPhapLy_10.jpg&quot; style=&quot;width:419px;height:592px;&quot; /&gt;&lt;/p&gt;\n&lt;p style=&quot;text-align:center;&quot;&gt;\n	&lt;img alt=&quot;&quot; src=&quot;/public/userfiles/images/HoSoPhapLy_14.jpg&quot; style=&quot;width:440px;height:621px;&quot; /&gt;&lt;/p&gt;\n&lt;p style=&quot;text-align:center;&quot;&gt;\n	&lt;img alt=&quot;&quot; src=&quot;/public/userfiles/images/HoSoPhapLy_15.jpg&quot; style=&quot;width:438px;height:619px;&quot; /&gt;&lt;/p&gt;\n&lt;p style=&quot;text-align:center;&quot;&gt;\n	&lt;img alt=&quot;&quot; src=&quot;/public/userfiles/images/HoSoPhapLy_16moi.jpg&quot; style=&quot;width:413px;height:583px;&quot; /&gt;&lt;/p&gt;\n&lt;p style=&quot;text-align:center;&quot;&gt;\n	&lt;img alt=&quot;&quot; src=&quot;/public/userfiles/images/HoSoPhapLy_17m.jpg&quot; style=&quot;width:414px;height:584px;&quot; /&gt;&lt;/p&gt;\n&lt;p style=&quot;text-align:center;&quot;&gt;\n	&lt;img alt=&quot;&quot; src=&quot;/public/userfiles/images/HoSoPhapLy_23.jpg&quot; style=&quot;width:432px;height:609px;&quot; /&gt;&lt;/p&gt;\n&lt;p style=&quot;text-align:center;&quot;&gt;\n	 &lt;/p&gt;\n&lt;p style=&quot;text-align:center;&quot;&gt;\n	&lt;img alt=&quot;&quot; src=&quot;/public/userfiles/images/Toroi3_483x1035.jpg&quot; style=&quot;width:341px;height:729px;&quot; /&gt;&lt;/p&gt;\n&lt;p style=&quot;text-align:center;&quot;&gt;\n	&lt;strong&gt;&lt;span style=&quot;font-size:22px;&quot;&gt;PHÂN TÍCH SẢN PHẨM MPG&lt;/span&gt;&lt;/strong&gt;&lt;/p&gt;\n&lt;p style=&quot;text-align:center;&quot;&gt;\n	&lt;br /&gt;&lt;img alt=&quot;&quot; src=&quot;/public/userfiles/images/2011-11-16_125715.jpg&quot; style=&quot;width:284px;height:145px;&quot; /&gt; Lợi ích đầu tiên là khả năng của lớp màng được tạo ra bởi MPG để chống lại sự hình thành của lớp lắng đọng có hại. Điều này đặc biệt quan trọng trong việc nhìn nhận của các ảnh hưởng mà sự điều chỉnh của EPA đã có trong ngành công nghiệp xe hơi. Để tuân theo chỉ thị của EPA để giảm lượng khí thải, các nhà sản xuất nhiên liệu đã bỏ Chì và Lưu huỳnh cho thêm ôxy vào nhiên liệu. Hậu quả là sự hình thành của lớp lắng đọng độc hại có thể thấm vào nhiên liệu và tạo ra các vấn đề về hoạt động. Giảm phạm vi của các lớp lắng đọng đó là một lợi ích khác của sản phẩm của chúng tôi.&lt;/p&gt;\n&lt;p&gt;\n	&lt;br /&gt;&lt;img alt=&quot;&quot; src=&quot;/public/userfiles/images/2011-11-16_125757.jpg&quot; style=&quot;width:278px;height:136px;&quot; /&gt; Lợi ích thứ hai, MPG thay đổi bề mặt hấp thụ nhiệt đặc trưng của kim loại. Hỗn hợp nhiên liệu và không khí tạo ra năng lượng ở trạng thái của nhiệt năng có thể tạo ra sự giãn nở để hạ pít tông xuống, và lớp màng mỏng chống lại việc di chuyển của sự tản nhiệt. Việc này có hiệu quả trực tiếp trong việc đốt cháy ở nhiệt độ cao hơn, sự giãn nở tốt hơn và mạnh mẽ hơn.&lt;/p&gt;\n&lt;p&gt;\n	&lt;br /&gt;&lt;img alt=&quot;&quot; src=&quot;/public/userfiles/images/2011-11-16_125923.jpg&quot; style=&quot;width:162px;height:356px;&quot; /&gt; Lợi ích thứ 3 của lớp màng là bằng cách hoạt động như là một tiền thân của sự kích thích để phản ứng lại với thành phần chất xúc tác trong MPG. Các hợp chất hoạt động của MPG trong sự kết hợp với nhiệt trong xy lanh gây ra một phản ứng xúc tác để phát huy tốt hơn trong việc phân tán các chất hóa học và tốt hơn trong việc đốt cháy. Sự phản ứng kích thích cũng là một sự tỏa nhiệt và tạo ra nhiệt năng. Nói chung, tất cả 3 lợi ích trên cho kết quả trong tổng số của 30% đến 40% khả năng mở rộng hơn trong xy lanh với một lượng nhiên liệu như nhau. Lớp màng MPG cung cấp là một ảnh hưởng của bề mặt được đánh bóng cho phép phân phối nhiên liệu tốt hơn. Nó có thể được so sánh như việc nước đọng lại trên lớp sơn được đánh bóng. Lớp màng rất nhỏ thu hút nhiên liệu lỏng cho kết quả tốt hơn trong việc phân phối nhiên liệu để tạo thành việc tích điện để sinh ra nhiều năng lượng hơn.&lt;/p&gt;\n&lt;p&gt;\n	&lt;br /&gt;\n	Ngoài ra, cũng có lẽ là quan trọng nhất đó là việc làm giảm khí thải, kết quả từ việc sử dụng MPG. Quá trình xúc tác được tìm thấy trong các bộ chuyển xúc tác ở trong hệ thống thoát khí được bắt đầu ở trong xy lanh nổ, nó làm giảm sự hình thành của khí nitơ ôxít (NOX). Công việc của bộ chuyển đổi được giảm xuống, và tuổi thọ của bộ chuyển đổi được tăng lên.&lt;/p&gt;\n&lt;p&gt;\n	&lt;br /&gt;&lt;strong&gt;&lt;span style=&quot;font-size:20px;&quot;&gt;LÝ DO SỬ DỤNG LIÊN TỤC SẢN PHẨM MPG TỪ 3&lt;br /&gt;\n	BÌNH NHIÊN LIỆU MỚI CÓ KẾT QUẢ&lt;/span&gt;&lt;/strong&gt;&lt;/p&gt;\n&lt;p&gt;\n	&lt;br /&gt;&lt;strong&gt;1. TÁC DỤNG CỦA BÌNH NHIÊN LIỆU THỨ I:&lt;/strong&gt;&lt;/p&gt;\n&lt;p&gt;\n	&lt;br /&gt;\n	LÀM SẠCH ĐỘNG CƠ (BằNG CÁCH TIÊU HỦY VÀ LOẠI BỎ HẾT LƯỢNG NITƠ ÔXÍT (NO), MONOXÍT CÁCBON (CO) VÀ NHỮNG CẶN NHIÊN LIÊU KHÔNG CHÁY ĐƯỢC “LỚP MUỐI ĐEN”, RA KHỎI BUỒNG ĐỐT.TĂNG HIỆU QUẢ ĐỐT CHÁY NHIÊN LIỆU. GIẢM DẦN LƯỢNG KHÍ THẢI.TIẾT KIỆM ĐƯỢC TỪ 7% ĐẾN 10% LƯỢNG NHIÊN LIỆU TIÊU THỤ, TÙY THUỘC VÀO TỪNG LOẠI ĐỘNG CƠ.&lt;/p&gt;\n&lt;p&gt;\n	&lt;br /&gt;&lt;strong&gt;2. TÁC DỤNG CỦA BÌNH NHIÊN LIỆU THỨ 2 VÀ THỨ 3:&lt;/strong&gt;&lt;/p&gt;\n&lt;p&gt;\n	&lt;br /&gt;\n	SAU KHI LÀM SẠCH ĐỘNG CƠ, MPG SẼ TẠO RA LỚP MÀNG CỰC MỎNG ĐỂ BẢO VỆ ĐỘNG CƠ.&lt;br /&gt;\n	LỚP MÀNG MỎNG BẢO VỆ ĐỘNG CƠ CÓ TÁC DỤNG:&lt;/p&gt;\n&lt;p&gt;\n	&lt;br /&gt;\n	-  LÀM KÍN VÀ NHẴN BỀ MẶT PÍTTÔNG, XILANH&lt;/p&gt;\n&lt;p&gt;\n	&lt;br /&gt;\n	-  TẠO ĐỘ TRƠN LÁNG TRONG BUỒNG ĐỐT, GIÚP ĐỘNG CƠ HOẠT ĐỘNG&lt;/p&gt;\n&lt;p&gt;\n	&lt;br /&gt;\n	-  GIẢM MA SÁT KHI ĐỘNG CƠ HOẠT ĐỘNG&lt;/p&gt;\n&lt;p&gt;\n	&lt;br /&gt;\n	-  TẠO RA LỚP MÀNG CÁCH NHIỆT VÀ CÓ TÁC DỤNG NGĂN CẢN SỰ TRUYỀN NHIỆT XUỐNG PÍTTÔNG, XILANH. LÀM GIẢM NHIỆT ĐỘ TỪ BUỐNG ĐỐT RA NGOÀI NÊN ĐỘNG CƠ SẼ BỚT NÓNG VÀ LÀM CHO NHIÊN LIỆU Ở ĐÓ NGUỘI ĐI.&lt;/p&gt;\n&lt;p&gt;\n	&lt;br /&gt;\n	-  TĂNG HIỆU SUẤT ĐỐT CHÁY NHIÊN LIỆU, GIẢM THỜI GIAN ĐỐT CHÁY NHIÊN LIỆU.&lt;br /&gt;\n	CÔNG SUẤT HOẠT ĐỘNG CỦA ĐỘNG CƠ SẼ TĂNG LÊN. GIẢM TIÊU HAO NHIÊN LIỆU&lt;br /&gt;\n	GIẢM LƯỢNG KHÍ THẢI. KÉO DÀI TUỔI THỌ ĐỘNG CƠ.&lt;/p&gt;\n&lt;p&gt;\n	&lt;br /&gt;\n	-  TIẾT KIỆM ĐƯỢC TỪ 12% - 18% LƯỢNG NHIÊN LIỆU TIÊU THỤ, TÙY VÀO LOẠI ĐỘNG CƠ.&lt;/p&gt;\n&lt;p&gt;\n	&lt;br /&gt;&lt;strong&gt;3. TÁC DỤNG CỦA BÌNH NHIÊN LIỆU THỪ 4 TRỞ LÊN:&lt;/strong&gt;&lt;/p&gt;\n&lt;p&gt;\n	&lt;br /&gt;\n	-  SAU KHI TẠO RA LỚP MÀNG BẢO VỆ ĐỘNG CƠ, GIẢM NHIỆT LƯỢNG CỦA BUỒNG ĐỐT RA BÊN -  -  -  NGOÀI DO ĐÓ LƯỢNG TIÊU HAO NHIÊN LIỆU SẼ GIẢM.&lt;br /&gt;\n	-  CÔNG SUẤT HOẠT ĐỘNG CỦA ĐỘNG CƠ TĂNG LÊN.&lt;br /&gt;\n	-  TĂNG HIỆU QUẢ ĐỐT CHÁY NHIÊN LIỆU LÊN MỨC TỐI ĐA.&lt;/p&gt;\n&lt;p style=&quot;text-align:center;&quot;&gt;\n	&lt;strong&gt;LIÊN HỆ: CÔNG TY VIP TẦM NHÌN VIỆT&lt;/strong&gt;&lt;/p&gt;\n&lt;p style=&quot;text-align:center;&quot;&gt;\n	&lt;strong&gt;MAIL: viptamnhinviet@gmail.com&lt;/strong&gt;&lt;/p&gt;\n&lt;p style=&quot;text-align:center;&quot;&gt;\n	&lt;strong&gt;WEB: VIPTAMNHINVIET.COM&lt;/strong&gt;&lt;/p&gt;\n&lt;p style=&quot;text-align:center;&quot;&gt;\n	&lt;strong&gt;ĐT: 0987976879&lt;/strong&gt;&lt;/p&gt;\n&lt;p style=&quot;text-align:center;&quot;&gt;\n	&lt;strong&gt;ĐỊA CHỈ: LÔ L4, ĐƯỜNG N1, KP1, P.BỬU LONG, BIÊN HÒA, ĐỒNG NAI.&lt;/strong&gt;&lt;/p&gt;\n', '', '', 0, 30, '', '', '', '', 6000, 1, 1, 36, 'viptamnhinviet'),
(54, '2011-11-16 06:31:20', '20111116_141435.jpg', '20111116_1414358.jpg', NULL, ' CÔNG NGHỆ TIẾT KIỆM GAS', '', '', '&lt;p style=&quot;text-align:center;&quot;&gt;\n	&lt;strong&gt;&lt;span style=&quot;font-size:16px;&quot;&gt;&lt;img alt=&quot;&quot; src=&quot;/public/userfiles/images/2011-11-16_141339.jpg&quot; style=&quot;width:339px;height:468px;&quot; /&gt;&lt;/span&gt;&lt;/strong&gt;&lt;/p&gt;\n&lt;p&gt;\n	&lt;strong&gt;&lt;span style=&quot;font-size:16px;&quot;&gt;Chúng tôi chuyên cung cấp các sản phẩm mang tính giải pháp cao về tiết kiệm năng lượng ứng dụng trong đời sống sinh hoạt hàng ngày hoặc sản xuất kinh doanh của Quý khách hàng.&lt;/span&gt;&lt;/strong&gt;&lt;/p&gt;\n&lt;p&gt;\n	&lt;br /&gt;\n	Chúng tôi xin trân trọng giới thiệu đến Quý khách hàng một dòng sản phẩm mới sau :&lt;br /&gt;\n	Thiết bị tiết kiệm gas – EcoMaX.&lt;/p&gt;\n&lt;p&gt;\n	&lt;br /&gt;\n	EcoMaX là thiết bị được lắp đặt vào bếp gas công nghiệp hoặc bếp gas gia đình nhằm tác động trực tiếp lên chuỗi phân tử Hydrocacbon trong gas làm cho Oxy dễ tiếp xúc với gas hơn, nhờ đó gas dễ cháy và cháy triệt để hơn. Với những tính năng đạt được sau :&lt;/p&gt;\n&lt;p&gt;\n	&lt;br /&gt;\n	            - Ngọn lửa cháy xanh và đều hơn.&lt;br /&gt;\n	            - Tăng hiệu suất nhiệt của bếp gas.&lt;br /&gt;\n	            - Giảm thời gian đun nấu.&lt;br /&gt;\n	            - Giảm mùi gas sống. Giảm khí thải độc hại.&lt;br /&gt;\n	            - Tiết kiệm đến 30% gas.&lt;br /&gt;\n	            - An toàn hơn với bộ phận chống cháy ngược được thiết kế bên trong.&lt;br /&gt;\n	            - Dễ dàng lắp đặt, không cần bảo trì.&lt;br /&gt;\n	            - Được chế tạo bằng thép không rỉ.&lt;/p&gt;\n&lt;p&gt;\n	&lt;br /&gt;&lt;strong&gt;EcoMaX – Tiết kiệm 30% chi phí cho bạn.&lt;br /&gt;\n	+ Sản phẩm được bảo hiểm trên phạm vi toàn quốc bởi bảo hiểm Viễn Đông.&lt;/strong&gt;&lt;/p&gt;\n&lt;p&gt;\n	 &lt;/p&gt;\n&lt;p style=&quot;text-align:center;&quot;&gt;\n	&lt;strong&gt;&lt;img alt=&quot;&quot; src=&quot;/public/userfiles/images/2011-11-16_141435.jpg&quot; style=&quot;width:393px;height:541px;&quot; /&gt;&lt;/strong&gt;&lt;/p&gt;\n&lt;p style=&quot;text-align:center;&quot;&gt;\n	&lt;img alt=&quot;&quot; src=&quot;/public/userfiles/images/2011-11-16_141410.jpg&quot; style=&quot;width:396px;height:555px;&quot; /&gt;&lt;/p&gt;\n&lt;p style=&quot;text-align:center;&quot;&gt;\n	&lt;img alt=&quot;&quot; src=&quot;/public/userfiles/images/2011-11-16_141504.jpg&quot; style=&quot;width:397px;height:551px;&quot; /&gt;&lt;/p&gt;\n&lt;p style=&quot;text-align:center;&quot;&gt;\n	&lt;strong&gt;&lt;span style=&quot;font-size:22px;&quot;&gt;GIẢI PHÁP BÀI TOÁN KINH TẾ&lt;/span&gt;&lt;/strong&gt;&lt;/p&gt;\n&lt;p style=&quot;text-align:center;&quot;&gt;\n	 &lt;/p&gt;\n&lt;p&gt;\n	&lt;span style=&quot;font-size:16px;&quot;&gt;  &lt;strong&gt;1. Đối với hộ gia đình, quán ăn nhỏ, ...&lt;/strong&gt;  &lt;/span&gt;                                                                                                                                                     &lt;br /&gt;\n	        Dùng bình gas 12 kg dùng sản phẩm: Ecogas-E25 = 390.000đMỗi tháng bạn tốn 340.000đ cho 01 bình gas . Khi bạn dùng Sản phẩm thiết bị tiết kiệm gas Ecogas giúp bạn &lt;strong&gt;tiết kiệm&lt;/strong&gt; &lt;strong&gt;35% &lt;/strong&gt;lượng gas tương đương:                                                           &lt;br /&gt;&lt;strong&gt;        119.000đ / tháng x 12 tháng = 1.428.000đ/năm.&lt;/strong&gt;&lt;/p&gt;\n&lt;p&gt;\n	     &lt;strong&gt;  &lt;em&gt;Sản phẩm bảo hành 2 năm và độ bền lên đến 15 năm&lt;/em&gt;.&lt;/strong&gt; Vậy trong 15 năm bạn chỉ phải bỏ ra 390.000đ cho sản phẩm. Nhưng sẽ giúp ta kiết kiệm được:                                                           &lt;/p&gt;\n&lt;p&gt;\n	       &lt;strong&gt;1.428.000đ x 15 năm = 21.420.000đ/15 năm.&lt;/strong&gt;&lt;/p&gt;\n&lt;p&gt;\n	   &lt;strong&gt;&lt;span style=&quot;font-size:16px;&quot;&gt;2. Đối với nhà hàng, khách sạn.  bếp ăn công nghiệp… &lt;/span&gt;&lt;/strong&gt;                                                                                                                                                                                                                                &lt;br /&gt;\n	        Dùng Ecogas-E32 = 990.000đ; EcogaS E50= 1.500.000đ.Cơ quan của bạn (nhà hàng , khách sạn, bếp ăn công nghiệp, lò nung, sấy…) phải chi trả tương đối lớn cho chi phí dùng gas hàng năm. Vậy khi dùng sản phẩm Ecogas E32 và E50 giúp bạn tiết kiệm được 35% lượng gas tiêu thụ tương đương hàng năm có thể giúp tiết kiệm được một khoảng tiền không hề nhỏ. Vậy với thời gian bảo hành 02 năm và độ bền của sản phẩm là 15 năm thì sẽ giúp bạn tiết kiệm lớn đến bao nhiêu ??? THIẾT BỊ TIẾT KIỆM GAS ECOGAS giúp bạn tiết kiệm đến 35% lượng gas tiêu thụ. Một giải pháp tiết kiệm năng lượng và mang đến lợi ích cực lớn về kinh tế.&lt;/p&gt;\n&lt;p style=&quot;text-align:center;&quot;&gt;\n	&lt;strong&gt;GIÁ BÁN LẺ CÔNG BỐ TRÊN TOÀN QUỐC 390.000VNĐ MỘT THIẾT BỊ&lt;/strong&gt;&lt;/p&gt;\n&lt;p style=&quot;text-align:center;&quot;&gt;\n	&lt;strong&gt;CÔNG TY CẦN NHIỀU ĐẠI LÍ PHÂN PHỐI TRÊN TOÀN QUỐC&lt;/strong&gt;&lt;/p&gt;\n&lt;p style=&quot;text-align:center;&quot;&gt;\n	&lt;strong&gt; LIÊN HỆ CÔNG TY CỔ PHẦN TM - DV VIP TẦM NHÌN VIỆT&lt;/strong&gt;&lt;/p&gt;\n&lt;p style=&quot;text-align:center;&quot;&gt;\n	&lt;strong&gt;ĐC: LÔ L4, ĐƯỜNG 4, KP1, P.BỬU LONG, BIÊN HÒA, ĐỒNG NAI&lt;/strong&gt;&lt;/p&gt;\n&lt;p style=&quot;text-align:center;&quot;&gt;\n	&lt;strong&gt;MAIL: viptamnhinviet@gamil.com&lt;/strong&gt;&lt;/p&gt;\n&lt;p style=&quot;text-align:center;&quot;&gt;\n	&lt;strong&gt;WEB: VIPTAMNHINVIET.COM&lt;/strong&gt;     &lt;/p&gt;\n&lt;p style=&quot;text-align:center;&quot;&gt;\n	&lt;span style=&quot;font-size:14px;&quot;&gt;&lt;strong&gt;ĐT: 0987976879&lt;/strong&gt;&lt;/span&gt;&lt;/p&gt;\n&lt;p&gt;\n	 &lt;/p&gt;\n', '', '', 0, 28, '', '', '', '', 390000, 1, 1, 36, 'viptamnhinviet'),
(55, '2011-11-16 07:41:10', '20111116_153237.jpg', '20111116_1532373.jpg', NULL, ' CÔNG NGHỆ TIẾT KIỆM ĐIỆN', '', '', '&lt;p&gt;\n	   Như Quý khách hàng ân nhân đã biết, giá điện ngày càng tăng cao, mà nhu cầu sử dụng điện của gia đình mình thì không thể cắt giảm bớt được thậm chí ngày càng dùng nhiều hơn theo sự phát triển của xã hội. Chia sẻ sự trăn trở của người tiêu dùng, chính phủ và nhiều tổ chức, cá nhân đã khuyến khích tiết kiệm điện nhiều hình thức … và Trung tâm Dạy nghề &amp;amp; giải quyết việc làm cho Thanh niên Khuyết tật cùng chung tay cho ra đời sản phẩm TỤ BÙ TIẾT KIỆM ĐIỆN CHO CÔNG SUẤT PHÁT SINH hỗ trợ cho các thiết bị điện giảm tối thiểu và bảo vệ thiết bị trong quá trình sử dụng.&lt;/p&gt;\n&lt;p&gt;\n	&lt;span style=&quot;font-size:18px;&quot;&gt;&lt;strong&gt;TẠI SAO ĐIỆN NĂNG HAO HỤT VÀ CÁCH KHẮC PHỤC HIỆU QUẢ&lt;/strong&gt;&lt;/span&gt;&lt;/p&gt;\n&lt;p&gt;\n	            Khi xuất xưởng các thiết bị điện, nhà sản xuất đã tối ưu hóa về công suất tối thiểu để sử dụng thiết bị hiệu quả cao nhất và bền nhất. Nhưng trong quá trình sử dụng có những vấn đề  tăng công suất phát sinh:&lt;/p&gt;\n&lt;p&gt;\n	            1. Nguồn điện tăng giảm ở nước ta không ổn định làm các thiết bị đang sử dụng tăng giảm đột ngột dẫn đến công suất thật của thiết bị sẽ phát sinh thêm công suất vượt chỉ số cho phép của nhà sản xuất thiết bị.&lt;/p&gt;\n&lt;p&gt;\n	            2. Môi trường nóng ẩm ô nhiễm khách quan làm các linh kiện trong thiết bị tăng trở kháng rất cao, nhất là các thiết bị chuyển động có cảm ứng như máy lạnh, quạt gió, máy bơm nước, các loại máy may …&lt;/p&gt;\n&lt;p&gt;\n	            3. Hệ thống dây dẫn trong gia đình chồng chéo và cỡ dây không theo một thông số nhất định nào cả... thông thường chúng ta cứ chọn dây có tiết diện lớn cho chắc ăn tránh cháy nổ.. (dây truyền tải) chưa kể là các dây điện chúng ta sử dụng là loại đồng không đúng kỹ thuật mà bị pha trộn… (Dù rằng từ đầu dây nhà nước đã có các trạm và phần hao hụt đó không tính đồng hồ điện kế).&lt;/p&gt;\n&lt;p&gt;\n	- Từ 03 yếu tố trên cho ta thấy vô hình dung chúng ta đã mất đi một lượng điện đáng kể và một ví dụ dễ hiểu: Khi mua một quạt treo tường 60W lúc mới về sử dụng theo đúng thông số mỗi giờ sử dụng bao nhiêu thì chúng ta phải trả cho nhà nước số tiền tương ứng 60W chúng ta đã sử dụng, nhưng với các yếu tố trên sau thời gian ngắn thay vì 60W như ban đầu thì chắc chắn sẽ bị tăng thêm công suất từ 65W trở lên và như vậy lượng điện đã bị hao hụt là rõ và không những tốn thêm tiền điện mà ngay cả tuổi thọ của sản phẩm giảm đi. Thay vì 01 năm sau mới mua sản phẩm mới thì 9 tháng đã phải thay thế sản phẩm khác….Như vậy để tiết kiệm điện không phải là phải chế ra một thiết bị làm giảm công suất thực sẽ hư thiết bị ngay còn nếu chế thiết bị từ làm đồng hồ chạy chậm lại là ăn cắp điện nhà nước sẽ bị truy tố.&lt;/p&gt;\n&lt;p&gt;\n	+ Với suy nghĩ trăn trở đó Trung Tâm chúng tôi đã tham khảo, thử nghiệm từ năm 2004 đến nay đã  hoàn thiện tự tin cho ra đời Thiết bị Tụ bù Tiết kiệm điện và làm tăng tuổi thọ sản phẩm bằng cách giảm tối thiểu công suất phát sinh đưa các thiết bị sử dụng điện về gần công suất thực ban đầu của nhà sản xuất theo cơ chế mạch điện tử giảm sóng răng cưa của dòng điện xoay chiều hình sin và Tụ ngậm nạp xả. Kết luận giám định Tụ bù đúng tiêu chuẩn của Phân viện khoa học hình sự , Bộ công an số 627/C2 B ngày 17 tháng 2 năm 2006.&lt;/p&gt;\n&lt;p&gt;\n	Xin cám ơn Quý ân nhân khách hàng đã tham khảo tờ rơi tư vấn kỹ thuật của Trung Tâm dạy nghề và Việc làm cho Thanh niên Khuyết tật Việt nam và mong được nhận sự hợp tác chia sẻ của Quý vị góp phần tiết kiệm điện năng. Mọi chi tiết mong quí vị góp ý xây dựng.&lt;/p&gt;\n&lt;p&gt;\n	&lt;strong&gt;Xin Trân trọng cám ơn !&lt;/strong&gt;&lt;/p&gt;\n&lt;p style=&quot;text-align:center;&quot;&gt;\n	&lt;strong&gt;&lt;img alt=&quot;&quot; src=&quot;/public/userfiles/images/GDINH%20DIEN.JPG&quot; style=&quot;width:460px;height:680px;&quot; /&gt;&lt;/strong&gt;&lt;/p&gt;\n&lt;p style=&quot;text-align:center;&quot;&gt;\n	&lt;img alt=&quot;&quot; src=&quot;/public/userfiles/images/GIAI%20CAU%20VANG.JPG&quot; style=&quot;width:474px;height:746px;&quot; /&gt;&lt;/p&gt;\n&lt;p style=&quot;text-align:center;&quot;&gt;\n	&lt;img alt=&quot;&quot; src=&quot;/public/userfiles/images/HCV%20DIEN%20KHKT-1.JPG&quot; style=&quot;width:464px;height:686px;&quot; /&gt;&lt;/p&gt;\n&lt;p style=&quot;text-align:center;&quot;&gt;\n	&lt;img alt=&quot;&quot; src=&quot;/public/userfiles/images/SVD%20VIET.JPG&quot; style=&quot;width:437px;height:664px;&quot; /&gt;&lt;/p&gt;\n&lt;p style=&quot;text-align:center;&quot;&gt;\n	&lt;strong&gt;MỘT BỘ THIẾT BỊ LẮP ĐẶT GIÁ BÁN LẺ TRÊN TOÀN QUỐC 350.000VNĐ&lt;/strong&gt;&lt;/p&gt;\n&lt;p style=&quot;text-align:center;&quot;&gt;\n	&lt;strong&gt;LIÊN HỆ CÔNG TY CỔ PHẦN TM - DV VIP TẦM NHÌN VIỆT&lt;/strong&gt;&lt;/p&gt;\n&lt;p style=&quot;text-align:center;&quot;&gt;\n	&lt;strong&gt;ĐC: LÔ L4, ĐƯỜNG 4, KP1, P.BỬU LONG, ĐỒNG NAI, BIÊN HÒA&lt;/strong&gt;&lt;/p&gt;\n&lt;p style=&quot;text-align:center;&quot;&gt;\n	&lt;strong&gt;MAIL: viptamnhinviet@gmail.com&lt;/strong&gt;&lt;/p&gt;\n&lt;p style=&quot;text-align:center;&quot;&gt;\n	&lt;strong&gt;WEB: VIPTAMNHINVIET.COM&lt;/strong&gt;&lt;/p&gt;\n&lt;p style=&quot;text-align:center;&quot;&gt;\n	&lt;strong&gt;ĐT: 0987976879&lt;/strong&gt;&lt;/p&gt;\n&lt;p style=&quot;text-align:center;&quot;&gt;\n	 &lt;/p&gt;\n&lt;p style=&quot;text-align:center;&quot;&gt;\n	 &lt;/p&gt;\n&lt;p&gt;\n	 &lt;/p&gt;\n', '', '', 0, 29, '', '', '', '', 350000, 1, 1, 36, 'viptamnhinviet'),
(56, '2011-11-17 02:13:48', '2596522154100s23a750d_200x200_small.jpg', '2596522154100s23a750d_200x200_small6.jpg', NULL, '23&quot; SAMSUNG LED 3D S23A750D', '', '', '&lt;p&gt;\n	Full HD 1920 x 1080, Display port, HDMI, Độ tương phản 1.000:1, thời gian đáp ứng 2ms, 3D Hyper Real Engine,Real 120Hz input 2D -&amp;gt; 3D Converting,Eco Motion, Eco Light.&lt;/p&gt;\n&lt;p&gt;\n	LIÊN HỆ ĐẶT HÀNG&lt;/p&gt;\n&lt;p&gt;\n	IMAIL:viptamnhinviet@gmail.com&lt;/p&gt;\n&lt;p&gt;\n	ĐT: 0987976879&lt;/p&gt;\n&lt;p&gt;\n	&lt;br /&gt;\n	 &lt;/p&gt;\n', '', '', 0, 1, '', '', '', '', 10350000, 1, 1, 6, 'viptamnhinviet'),
(57, '2011-11-17 03:30:02', 'icdoinguon.jpg', 'icdoinguon5.jpg', NULL, 'IC ĐỔI NGUỒN ĐIỆN (Khi mất điện)', '', '', '&lt;p&gt;\n	&lt;span style=&quot;font-size:14px;&quot;&gt;&lt;strong&gt;&lt;span style=&quot;color:rgb(255,0,0);&quot;&gt;IC ĐỔI NGUỒN ĐIỆN TRÊN XE MÁY, ÔTÔ, GHE THUYỀN, BÌNH ACCU RỜI (12VDC - 220VAC chống giật)&lt;/span&gt;&lt;/strong&gt;&lt;/span&gt;&lt;/p&gt;\n&lt;p&gt;\n	&lt;span style=&quot;font-size:12px;&quot;&gt;Cơ chế hoạt động:  IC Đổi nguồn điện 12VDC sang 220VAC Công suất 20W (INVERTER )&lt;br /&gt;\n	- Khi dùng, bật công tắc điện đèn left sáng báo có điện là bạn có thể sử dụng và có thể sử dụng khi tắt máy không bật công tắc khóa xe.&lt;/span&gt;&lt;/p&gt;\n&lt;p&gt;\n	&lt;span style=&quot;font-size:12px;&quot;&gt;Sử dụng: &lt;span style=&quot;color:rgb(255,0,0);&quot;&gt; Gắn vào vị trí bất kỳ thích hợp&lt;/span&gt;, tốt nhất là ở dưới yên xe hoặc có thể mua bình accu sử dụng lâu dài.... Dây đỏ gắn vào cọc dương của bình Accu, dây đen gắn vào cọc âm của bình Accu (dây đỏ cho vào dương bình và dây đen vào âm bình).&lt;/span&gt;&lt;/p&gt;\n&lt;p&gt;\n	&lt;span style=&quot;font-size:12px;&quot;&gt;&lt;span style=&quot;color:rgb(255,0,0);&quot;&gt;Chức năng và hiệu quả ưu việt của sản phẩm duy nhất trên thế giới do các bạn khuyết tật Việt nam sản xuất:&lt;/span&gt;&lt;br /&gt;\n	1.Khi gia đình bị cúp điện hoặc về những vùng nông thôn không có điện,đi dã ngoại...Bạn chỉ cần mua bóng đèn 2U 220VAC 7W - 15W là có thể sử dụng thỏa mái tự nhiên có nguồn điện chiếu sáng từ 4 tiếng đến 6 tiếng. Nếu muốn kéo xa chỉ cần mua thêm dây ổ cắm tại các tiệm điện.&lt;br /&gt;\n	2. Bạn có ĐTDĐ nhưng sử dụng nhiều, Pin yếu hoặc quên sạc ĐTDĐ nên mất liên lạc ảnh hưởng lớn đến công việc của bạn. Bạn chỉ cần trong cốp xe bao giờ cũng có cục sạc theo máy. Khi cần sử dụng chỉ cắm sạc vào Bộ đổi nguồn ICEVN như cắm vào điện gia đình và sử dụng thỏa mái khi đã sạc đầy máy tự động ngắt nguồn...&lt;br /&gt;\n	3. Bạn đi công tác xa hoặc dã ngoại yên tâm sử dụng các loại máy MP3-MP4, Radio mini..sử dụng như đang ở gia đình dùng điện lưới quốc gia..&lt;/span&gt;&lt;/p&gt;\n&lt;p style=&quot;text-align:center;&quot;&gt;\n	&lt;span style=&quot;font-size:14px;&quot;&gt;&lt;span style=&quot;color:rgb(255,0,0);&quot;&gt;BẢO HÀNH 12 THÁNG (HOÀN TOÀN ĐỔI MỚI)&lt;/span&gt;&lt;/span&gt;&lt;/p&gt;\n&lt;p style=&quot;text-align:center;&quot;&gt;\n	&lt;span style=&quot;font-size:14px;&quot;&gt;&lt;span style=&quot;color:rgb(255,0,0);&quot;&gt;LIÊN HỆ CÔNG TY CỔ PHẦN TM - DV VIP TẦM NHÌN VIỆT&lt;/span&gt;&lt;/span&gt;&lt;/p&gt;\n&lt;p style=&quot;text-align:center;&quot;&gt;\n	&lt;span style=&quot;font-size:14px;&quot;&gt;&lt;span style=&quot;color:rgb(255,0,0);&quot;&gt;ĐC: LÔ L4, ĐƯỜNG 4, KP1, P.BỬU LONG, ĐỒNG NAI, BIÊN HÒA&lt;/span&gt;&lt;/span&gt;&lt;/p&gt;\n&lt;p style=&quot;text-align:center;&quot;&gt;\n	&lt;span style=&quot;font-size:14px;&quot;&gt;&lt;span style=&quot;color:rgb(255,0,0);&quot;&gt;MAIL: viptamnhinviet@gmail.com&lt;/span&gt;&lt;/span&gt;&lt;/p&gt;\n&lt;p style=&quot;text-align:center;&quot;&gt;\n	&lt;span style=&quot;font-size:14px;&quot;&gt;&lt;span style=&quot;color:rgb(255,0,0);&quot;&gt;WEB: VIPTAMNHINVIET.COM&lt;/span&gt;&lt;/span&gt;&lt;/p&gt;\n&lt;p style=&quot;text-align:center;&quot;&gt;\n	&lt;span style=&quot;font-size:14px;&quot;&gt;&lt;span style=&quot;color:rgb(255,0,0);&quot;&gt;ĐT: 0987976879&lt;/span&gt;&lt;/span&gt;&lt;/p&gt;\n', '', '', 0, 31, '', '', '', '', 99000, 1, 1, 36, 'viptamnhinviet'),
(58, '2011-11-18 00:57:04', 'chong-trom.jpg', 'chong-trom4.jpg', NULL, 'IC Chống trộm xe máy', '', '', '&lt;p&gt;\n	&lt;strong&gt;CHỨC NĂNG:&lt;/strong&gt;&lt;/p&gt;\n&lt;p&gt;\n	&lt;br /&gt;\n	* Chống chìa vạn năng ( vam phá khoá ):&lt;br /&gt;\n	- Với chức năng này khi xe của bạn bị bẻ khoá bằng chìa vạn năng ( hoặc vam ) hệ thống sẽ ngắt nguồn điện đồng thời còi báo động và xe không nổ máy được.&lt;br /&gt;\n	* Báo động khi bị bẻ khoá:&lt;br /&gt;\n	- Khi xe của bạn bị bẻ khoá lập tức hệ thống sẽ báo động cho bạn biết.&lt;br /&gt;\n	* Chống cướp xe:&lt;br /&gt;\n	- Bạn vô ý để chìa khóa ở trên xe hoặc khi đang đi đường mà bị cướp xe chộm có khoá xe cũng không thể đi được khi chưa mở khoá từ ra và còi sẽ báo động (hú).&lt;br /&gt;\n	- Vì Chế độ khóa tự động chống trộm này được sử dụng khi ta tắt máy xe thì lập tức chế độ bảo vệ tự động bật lên.&lt;br /&gt;\n	* Trộm có chìa khóa cũng không đi được.&lt;/p&gt;\n&lt;p&gt;\n	&lt;br /&gt;&lt;strong&gt;ĐẶC ĐIỂM:&lt;/strong&gt;&lt;/p&gt;\n&lt;p&gt;\n	&lt;br /&gt;\n	- Sản phẩm được lập trình trên chip điện tử nên tránh bị kẻ gian dùng nam châm phá&lt;br /&gt;\n	- Công tắc mở khóa là chạm vào điểm bí mật nên không sợ bị chạm khi rửa xe, và chịu được thời tiết mưa nắng bên ngoài.&lt;br /&gt;\n	- Động tác giải mã đơn giản như vô tình chạm điểm bí mật nên không ai nghĩ rằng xe đang được bảo vệ.&lt;br /&gt;\n	- Không hao bình, không bị hú còi khi đụng vào xe.&lt;br /&gt;\n	- An toàn, đơn giản, dễ dàng lắp ráp.&lt;/p&gt;\n&lt;p style=&quot;text-align:center;&quot;&gt;\n	  - Bảo hành 06 tháng (Hoàn toàn đổi mới)                                                                                                                            &lt;/p&gt;\n&lt;p style=&quot;text-align:center;&quot;&gt;\n	&lt;br /&gt;&lt;span style=&quot;color:rgb(255,0,0);&quot;&gt;LIÊN HỆ CÔNG TY CỔ PHẦN TM - DV VIP TẦM NHÌN VIỆT&lt;/span&gt;&lt;/p&gt;\n&lt;p style=&quot;text-align:center;&quot;&gt;\n	&lt;span style=&quot;color:rgb(255,0,0);&quot;&gt;ĐC: LÔ L4, ĐƯỜNG 4, KP1, P.BỬU LONG, ĐỒNG NAI, BIÊN HÒA&lt;/span&gt;&lt;/p&gt;\n&lt;p style=&quot;text-align:center;&quot;&gt;\n	&lt;span style=&quot;color:rgb(255,0,0);&quot;&gt;MAIL: viptamnhinviet@gmail.com&lt;/span&gt;&lt;/p&gt;\n&lt;p style=&quot;text-align:center;&quot;&gt;\n	&lt;span style=&quot;color:rgb(255,0,0);&quot;&gt;WEB: VIPTAMNHINVIET.COM&lt;/span&gt;&lt;/p&gt;\n&lt;p style=&quot;text-align:center;&quot;&gt;\n	&lt;span style=&quot;color:rgb(255,0,0);&quot;&gt;ĐT: 0987976879&lt;/span&gt;&lt;/p&gt;\n&lt;p&gt;\n	 &lt;/p&gt;\n', '', '', 0, 32, '', '', '', '', 149000, 1, 1, 36, 'viptamnhinviet'),
(59, '2011-11-18 01:06:42', '4.jpg', '46.jpg', NULL, 'Đèn năng lượng mặt trời', '', '', '&lt;p&gt;\n	Đèn năng lượng mặt trời, trang trí nhà, ban công, hàng rào, sân vườn, biệt thự, khách sạn, resort...&lt;br /&gt;\n	Đèn tự nạp điện bằng năng lượng mặt trời, tự động bật khi trời tối, không phí điện, hiện đại, thân thiện môi trường, đèn LED siêu sáng, chịu nước. Màu sáng trắng, đỏ, vàng, xanh và đổi màu theo yêu cầu của khách hàng...&lt;br /&gt;\n	- Cường độ ánh sáng cao.&lt;br /&gt;\n	- Thời gian sạc 6 - 8 giờ&lt;br /&gt;\n	- Thời gian chiếu sáng : 24 giờ&lt;br /&gt;\n	- Không dây dẫn&lt;br /&gt;\n	- Lắp đặt đơn giản, thuận tiện&lt;/p&gt;\n&lt;p style=&quot;text-align:center;&quot;&gt;\n	&lt;span style=&quot;color:rgb(255,0,0);&quot;&gt;LIÊN HỆ CÔNG TY CỔ PHẦN TM - DV VIP TẦM NHÌN VIỆT&lt;/span&gt;&lt;/p&gt;\n&lt;p style=&quot;text-align:center;&quot;&gt;\n	&lt;span style=&quot;color:rgb(255,0,0);&quot;&gt;ĐC: LÔ L4, ĐƯỜNG 4, KP1, P.BỬU LONG, ĐỒNG NAI, BIÊN HÒA&lt;/span&gt;&lt;/p&gt;\n&lt;p style=&quot;text-align:center;&quot;&gt;\n	&lt;span style=&quot;color:rgb(255,0,0);&quot;&gt;MAIL: viptamnhinviet@gmail.com&lt;/span&gt;&lt;/p&gt;\n&lt;p style=&quot;text-align:center;&quot;&gt;\n	&lt;span style=&quot;color:rgb(255,0,0);&quot;&gt;WEB: VIPTAMNHINVIET.COM&lt;/span&gt;&lt;/p&gt;\n&lt;p style=&quot;text-align:center;&quot;&gt;\n	&lt;span style=&quot;color:rgb(255,0,0);&quot;&gt;ĐT: 0987976879&lt;/span&gt;&lt;/p&gt;\n', '', '', 0, 33, '', '', '', '', 499000, 1, 1, 36, 'viptamnhinviet'),
(60, '2011-11-18 01:11:38', '7_1.jpg', '7_14.jpg', NULL, 'Sản phẩm mới Ổ cắm chống sét ', '', '', '&lt;p&gt;\n	&lt;span style=&quot;color:rgb(255,0,0);&quot;&gt;&lt;strong&gt;Sau 5 năm nghiên cứu, Công ty CP Thanh Niên Việt Nam đã chế tạo thành công ổ cắm PC Care (đã đăng ký bằng sáng chế Quốc tế, đơn chấp nhận ngày 19/11/2008) với tính năng vượt trội so với các sản phẩm cùng loai như sau:&lt;/strong&gt;&lt;/span&gt;&lt;/p&gt;\n&lt;p&gt;\n	- N&lt;span style=&quot;color:rgb(0,0,205);&quot;&gt;hịp đàn hồi theo dạng hai vòng cung có rãnh giữa kẹp chặt phích cắm điện đa năng (Tuyệt đối không làm lỏng phích cắm điện đa năng) nên không gây ra hiện tượng chập chờn di chuyển, tạo tia lửa điện gây cháy máy tính và các thiết bị điện tử khác.&lt;/span&gt;&lt;/p&gt;\n&lt;p&gt;\n	&lt;span style=&quot;color:rgb(0,0,205);&quot;&gt;- Trong sản phẩm thiết bị có hạn chế chống sốc và sét máy tính bằng tụ (Giám định KHHS của Bộ Công an 672/C21B số ngày 17/2/2006).&lt;/span&gt;&lt;/p&gt;\n&lt;p&gt;\n	&lt;span style=&quot;color:rgb(0,0,205);&quot;&gt;- Vỏ bằng nhựa chống cháy.&lt;/span&gt;&lt;/p&gt;\n&lt;p&gt;\n	&lt;span style=&quot;color:rgb(0,0,205);&quot;&gt;- Bảo vệ, nâng tuổi thọ cho các thiết bị điện.&lt;/span&gt;&lt;/p&gt;\n&lt;p style=&quot;text-align:center;&quot;&gt;\n	&lt;span style=&quot;color:rgb(255,0,0);&quot;&gt;LIÊN HỆ CÔNG TY CỔ PHẦN TM - DV VIP TẦM NHÌN VIỆT&lt;/span&gt;&lt;/p&gt;\n&lt;p style=&quot;text-align:center;&quot;&gt;\n	&lt;span style=&quot;color:rgb(255,0,0);&quot;&gt;ĐC: LÔ L4, ĐƯỜNG 4, KP1, P.BỬU LONG, ĐỒNG NAI, BIÊN HÒA&lt;/span&gt;&lt;/p&gt;\n&lt;p style=&quot;text-align:center;&quot;&gt;\n	&lt;span style=&quot;color:rgb(255,0,0);&quot;&gt;MAIL: viptamnhinviet@gmail.com&lt;/span&gt;&lt;/p&gt;\n&lt;p style=&quot;text-align:center;&quot;&gt;\n	&lt;span style=&quot;color:rgb(255,0,0);&quot;&gt;WEB: VIPTAMNHINVIET.COM&lt;/span&gt;&lt;/p&gt;\n&lt;p style=&quot;text-align:center;&quot;&gt;\n	&lt;span style=&quot;color:rgb(255,0,0);&quot;&gt;ĐT: 0987976879&lt;/span&gt;&lt;/p&gt;\n', '', '', 0, 35, '', '', '', '', 119000, 1, 1, 36, 'viptamnhinviet'),
(61, '2011-11-19 09:29:40', '3.jpg', '32.jpg', NULL, 'Máy Công nghệ O3 (Ozone)', '', '', '&lt;p&gt;\n	* Công dụng:&lt;/p&gt;\n&lt;p&gt;\n	1. Ngâm rửa rau quả&lt;/p&gt;\n&lt;p&gt;\n	2. Xử lý nước kim loại nặng&lt;/p&gt;\n&lt;p&gt;\n	3. Khử mùi cá, hải sản và thịt&lt;/p&gt;\n&lt;p&gt;\n	4. Khử mùi không khí&lt;/p&gt;\n&lt;p&gt;\n	5. Rửa chén bát và ly cốc&lt;/p&gt;\n&lt;p&gt;\n	6. Rửa tay&lt;/p&gt;\n&lt;p&gt;\n	7. Dùng sát trùng và vệ sinh chống lão hóa da&lt;/p&gt;\n&lt;p style=&quot;text-align:center;&quot;&gt;\n	&lt;span style=&quot;color:rgb(255,0,0);&quot;&gt;LIÊN HỆ CÔNG TY CỔ PHẦN TM - DV VIP TẦM NHÌN VIỆT&lt;/span&gt;&lt;/p&gt;\n&lt;p style=&quot;text-align:center;&quot;&gt;\n	&lt;span style=&quot;color:rgb(255,0,0);&quot;&gt;ĐC: LÔ L4, ĐƯỜNG 4, KP1, P.BỬU LONG, ĐỒNG NAI, BIÊN HÒA&lt;/span&gt;&lt;/p&gt;\n&lt;p style=&quot;text-align:center;&quot;&gt;\n	&lt;span style=&quot;color:rgb(255,0,0);&quot;&gt;MAIL: viptamnhinviet@gmail.com&lt;/span&gt;&lt;/p&gt;\n&lt;p style=&quot;text-align:center;&quot;&gt;\n	&lt;span style=&quot;color:rgb(255,0,0);&quot;&gt;WEB: VIPTAMNHINVIET.COM&lt;/span&gt;&lt;/p&gt;\n&lt;p style=&quot;text-align:center;&quot;&gt;\n	&lt;span style=&quot;color:rgb(255,0,0);&quot;&gt;ĐT: 0987976879&lt;/span&gt;&lt;/p&gt;\n', '', '', 0, 34, '', '', '', '', 1299000, 1, 1, 36, 'viptamnhinviet');
INSERT INTO `dos_module_product` (`record_id`, `postdate`, `pic_thumb`, `pic_full`, `pic_desc`, `title`, `titleen`, `titlefr`, `detail`, `detailen`, `detailfr`, `hits`, `record_order`, `extra_field1`, `extra_field2`, `extra_field3`, `extra_field4`, `unit`, `hot`, `enable`, `dos_module_product_cat_cat_id`, `dos_sys_users_username`) VALUES
(62, '2011-11-19 09:57:20', 'komasukm539.jpg', 'komasukm5397.jpg', NULL, 'Bếp Hồng Ngoại  Komasu KM-539', '', '', '&lt;p&gt;\n	&lt;span style=&quot;font-size:14px;&quot;&gt;&lt;span style=&quot;color:rgb(0,0,205);&quot;&gt;                                                               &lt;img alt=&quot;&quot; src=&quot;/public/userfiles/images/komasu-km-539.jpg&quot; style=&quot;width:265px;height:205px;&quot; /&gt;&lt;br /&gt;\n	1. Mô tả các chức năng trên phím bấm:&lt;br /&gt;\n	* Khi khởi động bếp tự động đưa về chế độ “Hot Pot” với mức công suất cao nhất 2000W. Tăng giảm công suất tùy ý bằng 2 phím “Reduce” và “Increase”.&lt;br /&gt;\n	* Phím hẹn giờ tắt “Timing” : Kích hoạt phím “Timing” và tăng giảm thời gian hẹn giờ bằng 2 phím “Reduce” và “Increase”. Thời gia tối đa 120 phút.&lt;br /&gt;\n	* Phím báo mức tiêu thụ điện năng “Power” : bếp báo cho bạn biết mức tiêu thụ điện với con số : - 0: 00 (đơn vị tính 1000W = 1kw/ giờ) .&lt;br /&gt;\n	2. Nguyên tắc hoạt động:&lt;br /&gt;&lt;br /&gt;\n	B. ĐẶC ĐIỂM CẤU TẠO:&lt;br /&gt;&lt;br /&gt;\n	- Trong quá trình sử dụng nếu màn hình bếp phát tín hiệu Failure (báo sự cố) , bạn tắt bếp và kiểm tra xem có vật lạ rơi vào trong bếp hoặc&lt;br /&gt;\n	quạt gió bị kẹt, cửa thông thoát gió bị bẩn hoặc bị che chắn. Để yên tâm, bạn có thể mang đến trạm bảo hành để được trợ giúp.&lt;br /&gt;\n	- Khi khởi động bếp mặc nhiên bếp tự động khởi động nút hẹn giờ tắt (sau 120 phút). Hết thời gian 120 phút, nếu bạn vẫn muốn nấu tiếp thì bạn khởi động lại.&lt;br /&gt;\n	- Trong quá trình sử dụng bếp có thể lúc sáng lúc tối (lúc mạnh lúc yếu). Đây là thiết kế mặc định nhằm đảm bảo lượng nhiệt hồng ngoại sinh ra có hiệu quả nhất (tiết kiệm năng lượng)&lt;br /&gt;\n	- Mặt bếp được cấu tạo bởi chất liệu thủy tinh hữu cơ được tích hợp nhiều thấu kính hội tụ (16 thấu kính/ cm2) với mục đích truyền thẳng năng lượng vào đáy nồi theo phương vuông góc với mặt bếp do đó hiệu suấtsử dụng nhiệt rất cao.&lt;br /&gt;\n	- Độ bền cơ học của mặt bếp cao và không bị rạn vỡ khi có nước lạnh đột ngột dội vào&lt;br /&gt;\n	- Khi tắt bếp bằng phím điều khiển trên mặt bếp, quạt gió vẫn tiếp tục hoạt động để làm nguội bếp. Vì vậy, nên rút dây điện sau khi quạt gió ngừng hoạt động để đảm bảo bếp đã được tỏa nhiệt hết.&lt;br /&gt;\n	- Nút F màu đỏ phía trái không phải là phím bấm mà chỉ nhắc bạn dùng 1 ngón tay để điều khiển bếp..&lt;br /&gt;\n	                                            &lt;/span&gt;&lt;/span&gt;&lt;img alt=&quot;&quot; src=&quot;/public/userfiles/images/rubiluck-hc-12.jpg&quot; style=&quot;width:286px;height:199px;&quot; /&gt;&lt;/p&gt;\n&lt;p&gt;\n	&lt;span style=&quot;font-size:14px;&quot;&gt;&lt;span style=&quot;color:rgb(0,0,205);&quot;&gt;C. MỘT SỐ LƯU Ý KHI SỬ DỤNG:&lt;br /&gt;\n	- Không được sờ tay vào mặt bếp cả sau khi đun (nhất là ở vòng tròn phát huy tác dụng của tia hồng ngoại).&lt;br /&gt;\n	- Cố gắng sử dụng nồi có đáy bao trùm lên vùng ảnh hưởng của tia hồng ngoại (vòng tròn mặt bếp) để phát huy hết công suất bếp&lt;br /&gt;\n	- Không nên nhìn lâu vào mặt bếp đã khởi động khi chưa có nồi dễ gây chói mắt nhất là ở nhiệt độ cao.&lt;br /&gt;\n	- Bảo quản bếp: dùng giẻ mềm lau vệ sinh thân và mặt bếp. Để xa nơi ẩm ướt và môi trường không có hóa chất.&lt;br /&gt;\n	- Đặt bếp ở nơi bằng phẳng, lỗ thoát gió ở đáy bếp và xung quanh luôn thông thoáng.&lt;br /&gt;\n	D. HƯỚNG DẪN CÁCH NẤU CƠM BẰNG BẾP HỒNG NGOẠI KOMASU&lt;br /&gt;\n	Tùy theo lượng gạo để sử dụng mức công suất ở chế độ “Hot pot”. Khi cơm cạn cũng tùy lượng gạo để sử dụng nút “Keep warm” hoặc nút “Soup” (như động tác bớt lửa – nhiệt ở bếp củi - điện). Nếu chưa ăn ngay khi cơm đã chín nên sử dụng nút “Hot milk” để giữ cơm nóng.&lt;br /&gt;\n	Mẹo dùng bếp:&lt;br /&gt;\n	- Do nguồn hống ngoại là tia bức xạ nhiệt có bước sóng hồng ngoại nên có thể sử dụng để làm giảm đau các vết thương hoặc nhức mỏi cơ bắp (thay thế đèn chiếu tia hồng ngoại giá bán cao - trong trường hợp bác sĩ chỉ định dùng và điều khiển ở mức năng lượng hợp lý)&lt;/span&gt;&lt;/span&gt;&lt;/p&gt;\n&lt;p&gt;\n	&lt;span style=&quot;font-size:14px;&quot;&gt;&lt;span style=&quot;color:rgb(0,0,205);&quot;&gt;.&lt;/span&gt;&lt;/span&gt;&lt;span style=&quot;color:#0000cd;&quot;&gt;&lt;span style=&quot;font-size:14px;&quot;&gt;Bảo hành: 12 Tháng&lt;br /&gt;\n	Tình trạng: Mới&lt;br /&gt;\n	Xuất xứ: Chính hãng&lt;/span&gt;&lt;/span&gt;&lt;/p&gt;\n&lt;p&gt;\n	&lt;span style=&quot;color:#ff0000;&quot;&gt;&lt;span style=&quot;font-size:14px;&quot;&gt;                     LIÊN HỆ CÔNG TY CỔ PHẦN TM - DV VIP TẦM NHÌN VIỆT&lt;/span&gt;&lt;/span&gt;&lt;/p&gt;\n&lt;p&gt;\n	&lt;span style=&quot;color:#ff0000;&quot;&gt;&lt;span style=&quot;font-size:14px;&quot;&gt;                     ĐC: LÔ L4, ĐƯỜNG 4, KP1, P.BỬU LONG, ĐỒNG NAI, BIÊN HÒA&lt;/span&gt;&lt;/span&gt;&lt;/p&gt;\n&lt;p&gt;\n	&lt;span style=&quot;color:#ff0000;&quot;&gt;&lt;span style=&quot;font-size:14px;&quot;&gt;                     MAIL: viptamnhinviet@gmail.com&lt;/span&gt;&lt;/span&gt;&lt;/p&gt;\n&lt;p&gt;\n	&lt;span style=&quot;color:#ff0000;&quot;&gt;&lt;span style=&quot;font-size:14px;&quot;&gt;                     WEB: VIPTAMNHINVIET.COM&lt;/span&gt;&lt;/span&gt;&lt;/p&gt;\n&lt;p&gt;\n	&lt;span style=&quot;color:#ff0000;&quot;&gt;&lt;span style=&quot;font-size:14px;&quot;&gt;                     ĐT: 0987976879&lt;/span&gt;&lt;/span&gt;&lt;/p&gt;\n', '', '', 0, 27, '', '', '', '', 1067000, 1, 1, 36, 'viptamnhinviet'),
(63, '2011-11-20 10:50:54', NULL, NULL, '', 'herbalife', '', '', '&lt;p&gt;\n	Thuc pham chuc nang&lt;/p&gt;\n', '', '', 0, 36, '', '', '', '', 450, 0, 0, 36, 'dongvu'),
(64, '2011-11-21 20:44:34', '20111118_092544.jpg', 'hh.jpg', '', 'thyhyfhh', '', '', '&lt;p&gt;\n	thyuiuuuyy&lt;/p&gt;\n&lt;p&gt;\n	 &lt;/p&gt;\n', '', '', 0, 37, '', '', '', '', 100, 0, 0, 30, 'trieuphu');

-- --------------------------------------------------------

--
-- Table structure for table `dos_module_product_cat`
--

CREATE TABLE IF NOT EXISTS `dos_module_product_cat` (
  `cat_id` int(11) NOT NULL auto_increment,
  `cat_parent_id` int(11) NOT NULL default '0',
  `pic_thumb` varchar(45) default NULL,
  `pic_full` varchar(45) default NULL,
  `pic_desc` varchar(1000) default NULL,
  `cat_title` varchar(45) NOT NULL,
  `cat_titleen` varchar(45) default NULL,
  `cat_titlefr` varchar(45) default NULL,
  `preview` text,
  `previewen` text,
  `previewfr` text,
  `cat_order` int(11) NOT NULL default '1',
  `cat_extra1` varchar(45) default NULL,
  `cat_extra2` varchar(45) default NULL,
  `cat_extra3` varchar(45) default NULL,
  `cat_extra4` varchar(45) default NULL,
  `cat_enable` tinyint(1) NOT NULL default '1',
  PRIMARY KEY  (`cat_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=39 ;

--
-- Dumping data for table `dos_module_product_cat`
--

INSERT INTO `dos_module_product_cat` (`cat_id`, `cat_parent_id`, `pic_thumb`, `pic_full`, `pic_desc`, `cat_title`, `cat_titleen`, `cat_titlefr`, `preview`, `previewen`, `previewfr`, `cat_order`, `cat_extra1`, `cat_extra2`, `cat_extra3`, `cat_extra4`, `cat_enable`) VALUES
(6, 0, '2596522154100s23a750d_200x200_small.jpg', NULL, NULL, 'Laptop - Máy Vi Tính', NULL, NULL, NULL, NULL, NULL, 2, NULL, NULL, NULL, NULL, 1),
(7, 0, 'buystrip_ipads_20111005.png', NULL, NULL, 'Điện thoại -PDA', NULL, NULL, NULL, NULL, NULL, 3, NULL, NULL, NULL, NULL, 1),
(8, 0, 't632510.jpg', NULL, NULL, 'Ôtô - Xe máy', NULL, NULL, NULL, NULL, NULL, 11, NULL, NULL, NULL, NULL, 1),
(9, 0, '1208781dcrpj5.jpg', NULL, NULL, 'Điện tử - Điện lạnh', NULL, NULL, NULL, NULL, NULL, 4, NULL, NULL, NULL, NULL, 1),
(10, 6, NULL, NULL, '', 'Lenovo', NULL, NULL, NULL, NULL, NULL, 5, NULL, NULL, NULL, NULL, 1),
(11, 6, NULL, NULL, '', 'HP - Compaq', NULL, NULL, NULL, NULL, NULL, 6, NULL, NULL, NULL, NULL, 1),
(12, 6, NULL, NULL, '', 'Samsung', NULL, NULL, NULL, NULL, NULL, 7, NULL, NULL, NULL, NULL, 1),
(13, 6, NULL, NULL, '', 'Acer', NULL, NULL, NULL, NULL, NULL, 8, NULL, NULL, NULL, NULL, 1),
(14, 0, '00113_4e325ef86b26c_200x2001.jpg', NULL, NULL, 'Thời Trang, Trang Sức', NULL, NULL, NULL, NULL, NULL, 12, NULL, NULL, NULL, NULL, 1),
(15, 9, NULL, NULL, '', 'Tivi', NULL, NULL, NULL, NULL, NULL, 10, NULL, NULL, NULL, NULL, 1),
(16, 0, '74338_lcd_sony_kdl_40ex520_me6.jpg', NULL, NULL, 'Điện Tử', NULL, NULL, NULL, NULL, NULL, 9, NULL, NULL, NULL, NULL, 1),
(17, 0, '0014340_sonysscrp7600andstrk7600s.jpg', NULL, NULL, 'Âm Thanh, Hình Ảnh', NULL, NULL, NULL, NULL, NULL, 13, NULL, NULL, NULL, NULL, 1),
(18, 0, 'komasukm5397.jpg', NULL, NULL, 'Đồ Gia Dụng', NULL, NULL, NULL, NULL, NULL, 18, NULL, NULL, NULL, NULL, 1),
(19, 0, 'h_57820533srmcholochanlongto120.jpg', NULL, NULL, 'Mỹ Phẩm, Làm Đẹp', NULL, NULL, NULL, NULL, NULL, 14, NULL, NULL, NULL, NULL, 1),
(20, 0, 'images.jpg', NULL, NULL, 'Hoa, Qùa Tặng, Đồ Chơi', NULL, NULL, NULL, NULL, NULL, 15, NULL, NULL, NULL, NULL, 1),
(21, 0, 'images8.jpg', NULL, NULL, 'Sách Báo, Tạp Chí', NULL, NULL, NULL, NULL, NULL, 16, NULL, NULL, NULL, NULL, 1),
(22, 0, 'ke-3-tang-mika.jpg', NULL, NULL, 'Văn Phòng Phẩm', NULL, NULL, NULL, NULL, NULL, 19, NULL, NULL, NULL, NULL, 1),
(23, 0, NULL, NULL, '', 'Đặc Sản Dân Tộc', NULL, NULL, NULL, NULL, NULL, 17, NULL, NULL, NULL, NULL, 1),
(24, 0, '9_1271151131.jpg', NULL, NULL, 'Thực Phẩm, Đồ Uống', NULL, NULL, NULL, NULL, NULL, 20, NULL, NULL, NULL, NULL, 1),
(25, 0, 'fabaplusc1ghoptuyp6.jpg', NULL, NULL, 'Y Tế, Dược Phẩm', NULL, NULL, NULL, NULL, NULL, 21, NULL, NULL, NULL, NULL, 1),
(26, 0, 'gi_ng_ng_4ca691d67d498_200x200.jpg', NULL, NULL, 'Nội Thất - Ngoại Thất', NULL, NULL, NULL, NULL, NULL, 22, NULL, NULL, NULL, NULL, 1),
(27, 0, 'doi_luc_binh_the_ky_19.jpg', NULL, NULL, 'Đồ Hiệu - Đồ Cổ', NULL, NULL, NULL, NULL, NULL, 23, NULL, NULL, NULL, NULL, 1),
(28, 0, 'gautruc_haitrai7.jpg', NULL, NULL, 'Dịch Vụ, Giải Trí', NULL, NULL, NULL, NULL, NULL, 24, NULL, NULL, NULL, NULL, 1),
(29, 0, '1275381837.jpg', NULL, NULL, 'Vật Nuôi, Cây Cảnh', NULL, NULL, NULL, NULL, NULL, 25, NULL, NULL, NULL, NULL, 1),
(30, 0, NULL, NULL, '', 'Công Nghiệp', NULL, NULL, NULL, NULL, NULL, 27, NULL, NULL, NULL, NULL, 1),
(32, 0, NULL, NULL, '', 'Bất Động Sản', NULL, NULL, NULL, NULL, NULL, 28, NULL, NULL, NULL, NULL, 1),
(33, 0, NULL, NULL, '', 'Tài Chính', NULL, NULL, NULL, NULL, NULL, 29, NULL, NULL, NULL, NULL, 1),
(34, 0, NULL, NULL, '', 'Điện Thoại Đại Gia', NULL, NULL, NULL, NULL, NULL, 30, NULL, NULL, NULL, NULL, 1),
(35, 0, NULL, NULL, '', 'Dịch Vụ Viễn Thông', NULL, NULL, NULL, NULL, NULL, 31, NULL, NULL, NULL, NULL, 1),
(36, 0, 'tien2copycopy.jpg', NULL, NULL, 'SẢN PHẨM VIP TẦM NHÌN VIỆT', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, NULL, NULL, 1),
(37, 0, NULL, NULL, '', 'ĐỒ GỐM MỸ NGHỆ', NULL, NULL, NULL, NULL, NULL, 32, NULL, NULL, NULL, NULL, 1),
(38, 0, NULL, NULL, '', 'RAO VẶT', NULL, NULL, NULL, NULL, NULL, 33, NULL, NULL, NULL, NULL, 1);

-- --------------------------------------------------------

--
-- Table structure for table `dos_module_services`
--

CREATE TABLE IF NOT EXISTS `dos_module_services` (
  `record_id` int(11) NOT NULL auto_increment,
  `title` varchar(45) default NULL,
  `titleen` varchar(45) default NULL,
  `titlefr` varchar(45) default NULL,
  `pic_full` varchar(100) default NULL,
  `preview` text,
  `previewen` text,
  `previewfr` text,
  `content` text,
  `contenten` text,
  `contentfr` text,
  `hits` int(11) NOT NULL default '1',
  `posted_date` timestamp NULL default CURRENT_TIMESTAMP,
  `record_order` int(11) default '1',
  `extra_field1` varchar(45) default NULL,
  `extra_field2` varchar(45) default NULL,
  `hot` tinyint(1) NOT NULL default '0',
  `enable` tinyint(1) default '1',
  PRIMARY KEY  (`record_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=13 ;

--
-- Dumping data for table `dos_module_services`
--


-- --------------------------------------------------------

--
-- Table structure for table `dos_module_studies`
--

CREATE TABLE IF NOT EXISTS `dos_module_studies` (
  `record_id` int(11) NOT NULL auto_increment,
  `pic_thumb` varchar(45) default NULL,
  `title` varchar(100) NOT NULL,
  `titleen` varchar(100) default NULL,
  `titlefr` varchar(100) default NULL,
  `preview` text NOT NULL,
  `previewen` text,
  `previewfr` text,
  `content` text NOT NULL,
  `contenten` text,
  `contentfr` text,
  `author` varchar(45) default NULL,
  `hits` int(11) NOT NULL default '1',
  `postdate` timestamp NULL default CURRENT_TIMESTAMP,
  `record_order` int(11) NOT NULL default '1',
  `record_type` tinyint(1) NOT NULL default '0',
  `extra_field1` varchar(45) default NULL,
  `extra_field2` varchar(45) default NULL,
  `enable` tinyint(1) NOT NULL default '1',
  `dos_module_studies_cat_cat_id` int(11) NOT NULL,
  PRIMARY KEY  (`record_id`),
  KEY `fk_dos_module_studies_dos_module_studies_cat` (`dos_module_studies_cat_cat_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `dos_module_studies`
--


-- --------------------------------------------------------

--
-- Table structure for table `dos_module_studies_cat`
--

CREATE TABLE IF NOT EXISTS `dos_module_studies_cat` (
  `cat_id` int(11) NOT NULL auto_increment,
  `cat_parent_id` int(11) NOT NULL default '0',
  `cat_title` varchar(45) NOT NULL,
  `cat_titleen` varchar(45) default NULL,
  `cat_titlefr` varchar(45) default NULL,
  `cat_order` int(11) NOT NULL default '1',
  `cat_enable` tinyint(1) NOT NULL default '1',
  PRIMARY KEY  (`cat_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=13 ;

--
-- Dumping data for table `dos_module_studies_cat`
--


-- --------------------------------------------------------

--
-- Table structure for table `dos_module_support`
--

CREATE TABLE IF NOT EXISTS `dos_module_support` (
  `support_id` int(11) NOT NULL auto_increment,
  `support_name` varchar(45) default NULL,
  `support_phone` varchar(45) default NULL,
  `support_value` varchar(45) NOT NULL,
  `support_order` smallint(6) NOT NULL default '1',
  `support_type` varchar(45) NOT NULL default 'yahoo',
  `support_part` tinyint(1) NOT NULL default '0',
  PRIMARY KEY  (`support_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=70 ;

--
-- Dumping data for table `dos_module_support`
--

INSERT INTO `dos_module_support` (`support_id`, `support_name`, `support_phone`, `support_value`, `support_order`, `support_type`, `support_part`) VALUES
(69, 'TRẦN QUANG TRUNG - 01666888358', '01666888358', 'quangtrung_manly', 1, ' quangtrung_manlyyahoo', 1);

-- --------------------------------------------------------

--
-- Table structure for table `dos_module_userlog`
--

CREATE TABLE IF NOT EXISTS `dos_module_userlog` (
  `record_id` int(11) NOT NULL auto_increment,
  `detail` varchar(320) NOT NULL,
  `time` timestamp NOT NULL default CURRENT_TIMESTAMP,
  `username` varchar(45) NOT NULL,
  `user_receive` varchar(45) NOT NULL,
  `value` float NOT NULL,
  PRIMARY KEY  (`record_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=22 ;

--
-- Dumping data for table `dos_module_userlog`
--

INSERT INTO `dos_module_userlog` (`record_id`, `detail`, `time`, `username`, `user_receive`, `value`) VALUES
(2, 'Hoa hồng trực tiếp', '2011-11-19 11:28:04', 'viptamnhinviet', 'viptamnhinviet', 400),
(3, 'Hoa hồng trực tiếp', '2011-11-19 11:51:10', 'viptamnhinviet', 'viptamnhinviet', 400),
(4, 'Hoa hồng trực tiếp', '2011-11-19 12:18:45', 'viptamnhinviet', 'viptamnhinviet', 400),
(5, 'Hoa hồng trực tiếp', '2011-11-19 12:25:21', 'viptamnhinviet', 'viptamnhinviet', 400),
(6, 'Hoa hồng trực tiếp', '2011-11-19 12:33:47', 'viptamnhinviet', 'viptamnhinviet', 400),
(7, 'Hoa hồng trực tiếp', '2011-11-19 13:43:27', 'viptamnhinviet', 'viptamnhinviet', 400),
(8, 'Hoa hồng trực tiếp', '2011-11-19 14:59:59', 'viptamnhinviet', 'viptamnhinviet', 400),
(9, 'Hoa hồng trực tiếp', '2011-11-19 15:08:45', 'viptamnhinviet', 'viptamnhinviet', 400),
(10, 'Hoa hồng trực tiếp', '2011-11-20 09:03:13', 'viptamnhinviet', 'viptamnhinviet', 400),
(11, 'Hoa hồng trực tiếp', '2011-11-20 09:10:45', 'viptamnhinviet', 'viptamnhinviet', 400),
(12, 'Hoa hồng trực tiếp', '2011-11-20 09:16:38', 'viptamnhinviet', 'viptamnhinviet', 400),
(13, 'Hoa hồng trực tiếp', '2011-11-20 09:24:03', 'viptamnhinviet', 'viptamnhinviet', 400),
(14, 'Hoa hồng trực tiếp', '2011-11-20 09:29:38', 'viptamnhinviet', 'viptamnhinviet', 400),
(15, 'Hoa hồng trực tiếp', '2011-11-20 09:42:53', 'viptamnhinviet', 'viptamnhinviet', 400),
(16, 'Hoa hồng trực tiếp', '2011-11-20 09:47:34', 'viptamnhinviet', 'viptamnhinviet', 400),
(17, 'Hoa hồng trực tiếp', '2011-11-20 09:52:34', 'viptamnhinviet', 'viptamnhinviet', 400),
(18, 'Hoa hồng trực tiếp', '2011-11-20 10:00:13', 'viptamnhinviet', 'viptamnhinviet', 400),
(19, 'Hoa hồng trực tiếp', '2011-11-20 10:05:56', 'viptamnhinviet', 'viptamnhinviet', 400),
(20, 'Hoa hồng trực tiếp', '2011-11-20 10:13:19', 'viptamnhinviet', 'viptamnhinviet', 400),
(21, 'Hoa hồng trực tiếp', '2011-11-20 10:49:19', 'viptamnhinviet', 'viptamnhinviet', 400);

-- --------------------------------------------------------

--
-- Table structure for table `dos_module_video`
--

CREATE TABLE IF NOT EXISTS `dos_module_video` (
  `record_id` int(11) NOT NULL auto_increment,
  `postdate` timestamp NOT NULL default CURRENT_TIMESTAMP,
  `title` varchar(45) NOT NULL,
  `titleen` varchar(45) default NULL,
  `titlefr` varchar(45) default NULL,
  `pic_full` varchar(100) default NULL,
  `url` varchar(100) NOT NULL,
  `record_order` int(11) default '1',
  `hits` int(11) default '1',
  `extra_field1` varchar(45) default NULL,
  `extra_field2` varchar(45) default NULL,
  `hot` tinyint(1) NOT NULL default '0',
  `enable` tinyint(1) NOT NULL default '1',
  `dos_module_video_cat_cat_id` int(11) NOT NULL,
  PRIMARY KEY  (`record_id`),
  KEY `fk_dos_module_video_dos_module_video_cat` (`dos_module_video_cat_cat_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `dos_module_video`
--

INSERT INTO `dos_module_video` (`record_id`, `postdate`, `title`, `titleen`, `titlefr`, `pic_full`, `url`, `record_order`, `hits`, `extra_field1`, `extra_field2`, `hot`, `enable`, `dos_module_video_cat_cat_id`) VALUES
(2, '2011-09-08 14:16:23', 'Giới thiệu khoa Thương Mại điện tử - ĐH Thươn', '', '', '20111118_092544.jpg', 'http://www.youtube.com/watch?v=QkyZPXnnwPg', 1, 1, NULL, NULL, 1, 1, 4);

-- --------------------------------------------------------

--
-- Table structure for table `dos_module_video_cat`
--

CREATE TABLE IF NOT EXISTS `dos_module_video_cat` (
  `cat_id` int(11) NOT NULL auto_increment,
  `cat_parent_id` int(11) default '0',
  `pic_thumb` varchar(45) default NULL,
  `cat_title` varchar(45) NOT NULL,
  `cat_titleen` varchar(45) default NULL,
  `cat_titlefr` varchar(45) default NULL,
  `cat_order` varchar(45) default '1',
  `cat_enable` tinyint(1) NOT NULL default '1',
  PRIMARY KEY  (`cat_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `dos_module_video_cat`
--

INSERT INTO `dos_module_video_cat` (`cat_id`, `cat_parent_id`, `pic_thumb`, `cat_title`, `cat_titleen`, `cat_titlefr`, `cat_order`, `cat_enable`) VALUES
(4, 0, NULL, 'Video', NULL, NULL, '1', 1),
(5, 4, NULL, 'Sub video', NULL, NULL, '2', 1);

-- --------------------------------------------------------

--
-- Table structure for table `dos_module_weblink`
--

CREATE TABLE IF NOT EXISTS `dos_module_weblink` (
  `record_id` int(11) unsigned NOT NULL auto_increment,
  `cat_id` smallint(5) unsigned default NULL,
  `title` varchar(255) default NULL,
  `titleen` varchar(255) default NULL,
  `titlefr` varchar(255) default NULL,
  `url` varchar(255) NOT NULL,
  `hits` int(11) unsigned NOT NULL default '0',
  `posted_date` timestamp NULL default CURRENT_TIMESTAMP,
  `record_order` int(11) unsigned NOT NULL default '1',
  `enable` tinyint(1) unsigned NOT NULL default '1',
  PRIMARY KEY  (`record_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `dos_module_weblink`
--

INSERT INTO `dos_module_weblink` (`record_id`, `cat_id`, `title`, `titleen`, `titlefr`, `url`, `hits`, `posted_date`, `record_order`, `enable`) VALUES
(3, NULL, 'Web', '', '', 'http://grouplaptrinh.com', 0, '2011-10-15 09:58:29', 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `dos_sys_configs`
--

CREATE TABLE IF NOT EXISTS `dos_sys_configs` (
  `config_name` varchar(45) NOT NULL,
  `config_value` varchar(45) NOT NULL,
  `config_choices` varchar(45) default NULL,
  PRIMARY KEY  (`config_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `dos_sys_configs`
--

INSERT INTO `dos_sys_configs` (`config_name`, `config_value`, `config_choices`) VALUES
('adv_height', '300', 'Quảng cáo - chiều cao'),
('adv_width', '218', 'Quảng cáo - chiều ngang'),
('banner_height', '221', 'Banner - Chiều cao'),
('banner_width', '517', 'Banner - Chiều ngang'),
('experiences_height_thumb', '115', 'Kinh nghiệm - Thu nhỏ - Chiều cao'),
('experiences_width_thumb', '200', 'Kinh nghiệm - Thu nhỏ - Chiều ngang'),
('gallery_height', '525', 'Gallery - Chiều cao'),
('gallery_height_cat', '124', 'Gallery - Danh mục - Chiều cao'),
('gallery_height_thumb', '72', 'Gallery - Thu nhỏ - Chiều cao'),
('gallery_width', '700', 'Gallery - Chiều ngang'),
('gallery_width_cat', '165', 'Gallery - Danh mục - Chiều ngang'),
('gallery_width_thumb', '90', 'Gallery - Thu nhỏ - Chiều ngang'),
('handbook_height_thumb', '215', 'Cẩm nang - Thu nhỏ - Chiều cao'),
('handbook_width_thumb', '200', 'Cẩm nang - Thu nhỏ - Chiều ngang'),
('job_height_thumb', '91', 'Công việc - Thu nhỏ - Chiều cao'),
('job_width_thumb', '145', 'Công việc - Thu nhỏ - Chiều ngang'),
('logo_height', '106', 'Logo - Chiều cao'),
('logo_width', '683', 'Logo - Chiều ngang'),
('news_height_thumb', '115', 'Tin tức - Thu nhỏ - Chiều cao'),
('news_width_thumb', '200', 'Tin tức - Thu nhỏ - Chiều ngang'),
('product_height', '700', 'Sản phẩm - Chiều cao'),
('product_height_cat', '200', 'Sản phẩm - Danh mục - Chiều cao'),
('product_height_cat_thumb', '200', 'Sản phẩm - Danh mục - Thu nhỏ - Chiều cao'),
('product_height_thumb', '101', 'Sản phẩm - Thu nhỏ - Chiều cao'),
('product_width', '730', 'Sản phẩm - Chiều ngang'),
('product_width_cat', '288', 'Sản phẩm - Danh mục - Chiều ngang'),
('product_width_cat_thumb', '288', 'Sản phẩm - Danh mục - Thu nhỏ - Chiều ngang'),
('product_width_thumb', '135', 'Sản phẩm - Thu nhỏ - Chiều ngang'),
('promotions_height_thumb', '109', 'Khuyến mãi - Thu nhỏ- Chiều cao'),
('promotions_width_thumb', '107', 'Khuyến mãi - Thu nhỏ- Chiều ngang'),
('services_height_thumb', '98', 'Dịch vụ - Thu nhỏ - Chiều cao'),
('services_width_thumb', '158', 'Dịch vụ - Thu nhỏ - Chiều ngang'),
('studies_height_thumb', '98', ''),
('studies_width_thumb', '158', ''),
('sys_key', 'OE3GsQrrfmGbhzyh0MV/LC1tR3EaISrnIYVjq9+w2ZE=', ''),
('sys_num_pagerange', '5', ''),
('sys_num_paging', '16', 'Phân trang'),
('sys_size_upload', '5000', 'Kích cỡ upload'),
('video_height', '124', 'Video - Chiều cao'),
('video_height_cat_thumb', '124', 'Video - Danh mục - Thu nhỏ - Chiều cao'),
('video_width', '165', 'Video - Chiều ngang'),
('video_width_cat_thumb', '165', 'Video - Danh mục - Thu nhỏ - Chiều ngang');

-- --------------------------------------------------------

--
-- Table structure for table `dos_sys_functions`
--

CREATE TABLE IF NOT EXISTS `dos_sys_functions` (
  `function_id` smallint(6) NOT NULL auto_increment,
  `model_name` varchar(20) NOT NULL,
  `model_load` varchar(45) default NULL,
  `action` varchar(45) default NULL,
  `varname` varchar(45) default NULL,
  `function_load` varchar(45) default NULL,
  PRIMARY KEY  (`function_id`),
  KEY `fk_dos_sys_functions_dos_sys_modules` (`model_name`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=12628 ;

--
-- Dumping data for table `dos_sys_functions`
--

INSERT INTO `dos_sys_functions` (`function_id`, `model_name`, `model_load`, `action`, `varname`, `function_load`) VALUES
(12594, 'about', 'About_Model_About', 'index', 'menu_about', 'getListmenu'),
(12595, 'about', 'About_Model_About', 'view', 'menu_about', 'getListmenu'),
(12596, 'account', 'Webadmin_Model_Account', 'add', 'menu_account', 'getListmenu'),
(12597, 'account', 'Webadmin_Model_Account', 'changepass', 'menu_account', 'getListmenu'),
(12598, 'account', 'Webadmin_Model_Account', 'index', 'menu_account', 'getListmenu'),
(12599, 'default', 'Product_Model_Product', 'index', 'product_hot', 'listHotItem'),
(12600, 'default', 'Adv_Model_Adv', 'index', 'adv_center', 'getListAdvCenter'),
(12601, 'gallery', 'Gallery_Model_GalleryCat', 'cat', 'menu_gallery', 'getListmenu'),
(12602, 'gallery', 'Support_Model_Support', 'cat', 'menu_support', 'getListmenu'),
(12603, 'gallery', 'Gallery_Model_GalleryCat', 'index', 'menu_gallery', 'getListmenu'),
(12604, 'gallery', 'Gallery_Model_GalleryCat', 'index', 'list_gallery_cat', 'getListGalleryCat'),
(12605, 'handbook', 'Handbook_Model_HandbookCat', 'cat', 'menu_handbook', 'getListmenu'),
(12606, 'handbook', 'Handbook_Model_HandbookCat', 'index', 'menu_handbook', 'getListmenu'),
(12607, 'handbook', 'Handbook_Model_Handbook', 'index', 'list_handbook_new', 'listHandbooknew'),
(12608, 'handbook', 'Handbook_Model_HandbookCat', 'view', 'menu_handbook', 'getListmenu'),
(12609, 'handbook', 'Gallery_Model_GalleryCat', 'view', 'gallery_cat_hot', 'getListCatHot'),
(12610, 'news', 'News_Model_NewsCat', 'cat', 'menu_news', 'getListmenu'),
(12611, 'news', 'News_Model_NewsCat', 'index', 'menu_news', 'getListmenu'),
(12612, 'news', 'News_Model_News', 'index', 'list_news_new', 'listNewsnew'),
(12613, 'news', 'News_Model_NewsCat', 'view', 'menu_news', 'getListmenu'),
(12614, 'setup', 'Webadmin_Model_Setup', 'config', 'menu_setup', 'getListmenu'),
(12615, 'setup', 'Webadmin_Model_Setup', 'function', 'menu_setup', 'getListmenu'),
(12616, 'setup', 'Webadmin_Model_Setup', 'index', 'menu_setup', 'getListmenu'),
(12617, 'setup', 'Webadmin_Model_Setup', 'lang', 'menu_setup', 'getListmenu'),
(12618, 'setup', 'Webadmin_Model_Setup', 'menu', 'menu_setup', 'getListmenu'),
(12619, 'setup', 'Webadmin_Model_Setup', 'title', 'menu_setup', 'getListmenu'),
(12620, 'setup', 'Webadmin_Model_Setup', 'web', 'menu_setup', 'getListmenu'),
(12621, 'tool', 'Webadmin_Model_Tool', 'analytics', 'menu_tool', 'getListmenu'),
(12622, 'tool', 'Webadmin_Model_Tool', 'index', 'menu_tool', 'getListmenu'),
(12623, 'tool', 'Webadmin_Model_Tool', 'seo', 'menu_tool', 'getListmenu'),
(12624, 'video', 'Video_Model_VideoCat', 'cat', 'menu_video', 'getListmenu'),
(12625, 'video', 'Gallery_Model_GalleryCat', 'cat', 'gallery_cat_hot', 'getListCatHot'),
(12626, 'video', 'Gallery_Model_GalleryCat', 'index', 'gallery_cat_hot', 'getListCatHot'),
(12627, 'video', 'Video_Model_VideoCat', 'index', 'menu_video', 'getListmenu');

-- --------------------------------------------------------

--
-- Table structure for table `dos_sys_groups`
--

CREATE TABLE IF NOT EXISTS `dos_sys_groups` (
  `group_name` varchar(45) NOT NULL,
  PRIMARY KEY  (`group_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `dos_sys_groups`
--

INSERT INTO `dos_sys_groups` (`group_name`) VALUES
('administrator'),
('member');

-- --------------------------------------------------------

--
-- Table structure for table `dos_sys_groups_has_dos_sys_models`
--

CREATE TABLE IF NOT EXISTS `dos_sys_groups_has_dos_sys_models` (
  `dos_sys_groups_group_name` varchar(45) NOT NULL,
  `dos_sys_models_model_id` varchar(45) NOT NULL,
  `permission` varchar(45) NOT NULL,
  PRIMARY KEY  (`dos_sys_groups_group_name`,`dos_sys_models_model_id`),
  KEY `fk_dos_sys_groups_has_dos_sys_models_dos_sys_models` (`dos_sys_models_model_id`),
  KEY `fk_dos_sys_groups_has_dos_sys_models_dos_sys_groups` (`dos_sys_groups_group_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `dos_sys_groups_has_dos_sys_models`
--

INSERT INTO `dos_sys_groups_has_dos_sys_models` (`dos_sys_groups_group_name`, `dos_sys_models_model_id`, `permission`) VALUES
('member', 'about', 'allow'),
('member', 'adv', 'allow'),
('member', 'banner', 'allow'),
('member', 'contact', 'allow'),
('member', 'gallery', 'allow'),
('member', 'handbook', 'allow'),
('member', 'news', 'allow'),
('member', 'payment', 'deny'),
('member', 'product', 'allow'),
('member', 'support', 'allow'),
('member', 'user', 'allow'),
('member', 'video', 'allow');

-- --------------------------------------------------------

--
-- Table structure for table `dos_sys_langs`
--

CREATE TABLE IF NOT EXISTS `dos_sys_langs` (
  `lang_name` varchar(30) NOT NULL,
  `lang` varchar(200) default NULL,
  `langen` varchar(200) default NULL,
  `langfr` varchar(200) default NULL,
  PRIMARY KEY  (`lang_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `dos_sys_langs`
--

INSERT INTO `dos_sys_langs` (`lang_name`, `lang`, `langen`, `langfr`) VALUES
('about', 'Giới thiệu', '', ''),
('about_extra1', 'Thông tin phụ 1', '', ''),
('about_extra2', 'Thông tin phụ 2', '', ''),
('action', 'Thao tác', '', ''),
('adv', 'Quảng cáo', '', ''),
('adv_description', 'Mô tả quảng cáo', '', ''),
('adv_end_date', 'Ngày kết thúc', '', ''),
('adv_position', 'Vị trí', '', ''),
('adv_position_center', 'Ở giữa', '', ''),
('adv_position_left', 'Bên trái', '', ''),
('adv_position_right', 'Bên phải', '', ''),
('adv_position_right_bottom', 'Bên phải - Dưới', '', ''),
('adv_position_right_top', 'Bên phải - Trên', '', ''),
('adv_start_date', 'Ngày bắt đầu', '', ''),
('adv_type', 'Loại quảng cáo', '', ''),
('adv_type_current', 'Trang hiện tại', '', ''),
('adv_type_new', 'Trang mới', '', ''),
('adv_url', 'Liên kết', '', ''),
('banner', 'Logo &amp;amp; Banner', '', ''),
('banner_link', 'Liên kết', '', ''),
('banner_position', 'Vị trí', '', ''),
('catparent', 'Phân loại cha', '', ''),
('confirmdel', 'Bạn có chắc chắn xóa', '', ''),
('contact', 'Liên hệ', '', ''),
('contact_msg', 'Quý khách có thể liên hệ với chúng tôi bằng cách điền đầy đủ thông tin vào mẫu sau:', '', ''),
('copyright', 'Copyright © 2011 by Azweb.vn. All rights reserved', '', ''),
('counter', 'Thống kê truy cập', '', ''),
('counter_online', 'Đang truy cập', '', ''),
('counter_today', 'Truy cập trong ngày', '', ''),
('counter_total', 'Tổng số lượt truy cập', '', ''),
('createdate', 'Ngày tạo', '', ''),
('default', 'Trang chủ', '', ''),
('developed', 'Developed by', '', ''),
('edit', 'Thay đổi thông tin', '', ''),
('end', 'Cuối cùng', '', ''),
('gallery', 'Hình ảnh', '', ''),
('handbook', 'Kiến thức TMĐT', '', ''),
('hit', 'Lần xem', '', ''),
('home', 'Trang chủ', '', ''),
('inbox', 'Hộp thư', '', ''),
('logout', 'Thoát', '', ''),
('namecat', 'Tên phân loại', '', ''),
('news', 'Tin tức &amp;amp; Sự kiện', '', ''),
('next', 'Tiếp', '', ''),
('norecord', 'Không tồn tại mẫu tin', '', ''),
('payment', 'Thanh toán', '', ''),
('picture_thumb', 'Hình thu nhỏ', '', ''),
('previous', 'Lùi', '', ''),
('product', 'Sản phẩm', '', ''),
('productnum', 'Số sản phẩm', '', ''),
('product_cat_extra1', 'Thông tin phụ 1', '', ''),
('product_cat_extra2', 'Thông tin phụ 2', '', ''),
('product_cat_extra3', 'Thông tin phụ 3', '', ''),
('product_cat_extra4', 'Thông tin phụ 4', '', ''),
('product_extra1', 'Thông tin phụ 1', '', ''),
('product_extra2', 'Thông tin phụ 2', '', ''),
('product_extra3', 'Thông tin phụ 3', '', ''),
('product_extra4', 'Thông tin phụ 4', '', ''),
('product_hot', 'Sản phẩm đối tác vàng', '', ''),
('product_new', 'Sản phẩm mới', '', ''),
('product_other', 'Sản phẩm khác', '', ''),
('product_unit', 'Đơn giá', '', ''),
('register', 'Đăng ký thành viên', '', ''),
('root', 'Gốc', '', ''),
('setup', 'Cài đặt &amp;amp; cấu hình', '', ''),
('start', 'Đầu tiên', '', ''),
('support', 'Hỗ trợ trực tuyến', '', ''),
('sys_account', 'Tài khoản của tôi', '', ''),
('sys_active', 'Hiển thị', '', ''),
('sys_actived', 'Kích hoạt', '', ''),
('sys_add', 'Thêm mới', '', ''),
('sys_addcat', 'Thêm phân loại', '', ''),
('sys_addpost', 'Thêm bài viết', '', ''),
('sys_addrow', 'Thêm dòng', '', ''),
('sys_cancel', 'Hủy bỏ', '', ''),
('sys_delete', 'Xóa', '', ''),
('sys_detail', 'Chi tiết', '', ''),
('sys_edit', 'Chỉnh sửa', '', ''),
('sys_editcat', 'Sửa phân loại', '', ''),
('sys_editpost', 'Sửa bài viết', '', ''),
('sys_erroraccess', 'Bạn không có quyền truy cập vì chức năng này dùng để cấu hình thông số cho web', '', ''),
('sys_func_static', 'Thống kê chức năng', '', ''),
('sys_hidden', 'Ẩn', '', ''),
('sys_hot', 'Nổi bật', '', ''),
('sys_lang', 'Cấu hình ngôn ngữ', '', ''),
('sys_menu', 'Cấu hình menu', '', ''),
('sys_nohot', 'Không nổi bật', '', ''),
('sys_order', 'Thứ tự', '', ''),
('sys_picture', 'Hình ảnh', '', ''),
('sys_preview', 'Mô tả', '', ''),
('sys_sort', 'Sắp xếp', '', ''),
('sys_title', 'Tiêu đề', '', ''),
('sys_tool', 'Công cụ &amp;amp; Báo cáo', '', ''),
('sys_web', 'Cấu hình website', '', ''),
('user', 'Quản lý thành viên', '', ''),
('video', 'Video', '', ''),
('video_url', 'Link video', '', ''),
('welcome_chat', 'Xin chào, tôi muốn hỏi về sản phẩm - dịch vụ của công ty bạn', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `dos_sys_models`
--

CREATE TABLE IF NOT EXISTS `dos_sys_models` (
  `model_id` varchar(45) NOT NULL,
  `record_order` tinyint(4) default NULL,
  PRIMARY KEY  (`model_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `dos_sys_models`
--

INSERT INTO `dos_sys_models` (`model_id`, `record_order`) VALUES
('about', 1),
('adv', 10),
('banner', 11),
('contact', 2),
('gallery', 6),
('handbook', 15),
('news', 5),
('payment', 8),
('product', 3),
('services', 4),
('support', 9),
('user', 20),
('video', 10),
('weblink', 18);

-- --------------------------------------------------------

--
-- Table structure for table `dos_sys_modules`
--

CREATE TABLE IF NOT EXISTS `dos_sys_modules` (
  `moduleid` varchar(20) NOT NULL,
  `module` varchar(50) NOT NULL,
  `moduleen` varchar(50) NOT NULL,
  `modulefr` varchar(50) default NULL,
  `url` varchar(100) NOT NULL,
  `target` varchar(20) default NULL,
  `position` tinyint(4) default '0',
  PRIMARY KEY  (`moduleid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `dos_sys_modules`
--

INSERT INTO `dos_sys_modules` (`moduleid`, `module`, `moduleen`, `modulefr`, `url`, `target`, `position`) VALUES
('about', 'Giới thiệu', '', '', 'about', '', 1),
('contact', 'Liên hệ', '', '', 'contact', '', 4),
('default', 'Trang chủ', '', '', 'default', '', 0),
('gallery', 'Hình ảnh', '', '', 'gallery', '', 3),
('news', 'Tin tức - Sự kiện', '', '', 'news', '', 2);

-- --------------------------------------------------------

--
-- Table structure for table `dos_sys_sc_main`
--

CREATE TABLE IF NOT EXISTS `dos_sys_sc_main` (
  `sc_name` varchar(255) NOT NULL,
  `sc_count` int(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (`sc_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `dos_sys_sc_main`
--

INSERT INTO `dos_sys_sc_main` (`sc_name`, `sc_count`) VALUES
('/home/viptamnhin/domains/viptamnhinviet.com/public_html/index.php', 7237),
('C:/xampp/htdocs/zend/mvc/index.php', 15212),
('C:/xampp/htdocs/zend/nhahangnamlong/index.php', 1),
('C:/xampp/htdocs/zend/viptamnhinviet-11-18-11/index.php', 6),
('C:/xampp/htdocs/zend/viptamnhinviet/index.php', 8542),
('E:/xampp/htdocs/viptamnhinviet/index.php', 11186),
('E:/xampp/htdocs/zend/viptamnhinviet/index.php', 2932),
('total', 444);

-- --------------------------------------------------------

--
-- Table structure for table `dos_sys_sc_users`
--

CREATE TABLE IF NOT EXISTS `dos_sys_sc_users` (
  `sc_ip` char(16) NOT NULL,
  `sc_time` int(10) unsigned NOT NULL,
  `sc_location` varchar(255) NOT NULL default '',
  PRIMARY KEY  (`sc_ip`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `dos_sys_sc_users`
--

INSERT INTO `dos_sys_sc_users` (`sc_ip`, `sc_time`, `sc_location`) VALUES
('1.52.28.205', 1321889230, '/home/viptamnhin/domains/viptamnhinviet.com/public_html/index.php'),
('1.54.23.194', 1321855624, '/home/viptamnhin/domains/viptamnhinviet.com/public_html/index.php'),
('113.161.144.160', 1321856873, '/home/viptamnhin/domains/viptamnhinviet.com/public_html/index.php'),
('113.161.194.101', 1321845949, '/home/viptamnhin/domains/viptamnhinviet.com/public_html/index.php'),
('113.161.194.21', 1321864735, '/home/viptamnhin/domains/viptamnhinviet.com/public_html/index.php'),
('113.162.225.214', 1321831154, '/home/viptamnhin/domains/viptamnhinviet.com/public_html/index.php'),
('113.169.26.36', 1321849196, '/home/viptamnhin/domains/viptamnhinviet.com/public_html/index.php'),
('113.169.37.239', 1321841152, '/home/viptamnhin/domains/viptamnhinviet.com/public_html/index.php'),
('113.169.41.230', 1321842060, '/home/viptamnhin/domains/viptamnhinviet.com/public_html/index.php'),
('113.169.44.253', 1321835072, '/home/viptamnhin/domains/viptamnhinviet.com/public_html/index.php'),
('113.169.62.133', 1321874074, '/home/viptamnhin/domains/viptamnhinviet.com/public_html/index.php'),
('113.169.76.238', 1321882706, '/home/viptamnhin/domains/viptamnhinviet.com/public_html/index.php'),
('115.73.212.218', 1321843105, '/home/viptamnhin/domains/viptamnhinviet.com/public_html/index.php'),
('115.77.131.233', 1321913043, '/home/viptamnhin/domains/viptamnhinviet.com/public_html/index.php'),
('118.69.30.36', 1321841855, '/home/viptamnhin/domains/viptamnhinviet.com/public_html/index.php'),
('123.20.26.69', 1321837470, '/home/viptamnhin/domains/viptamnhinviet.com/public_html/index.php'),
('123.20.33.24', 1321858270, '/home/viptamnhin/domains/viptamnhinviet.com/public_html/index.php'),
('123.22.73.127', 1321866166, '/home/viptamnhin/domains/viptamnhinviet.com/public_html/index.php'),
('123.22.77.67', 1321863329, '/home/viptamnhin/domains/viptamnhinviet.com/public_html/index.php'),
('123.22.79.234', 1321867733, '/home/viptamnhin/domains/viptamnhinviet.com/public_html/index.php'),
('123.28.89.185', 1321870229, '/home/viptamnhin/domains/viptamnhinviet.com/public_html/index.php'),
('141.0.9.254', 1321835218, '/home/viptamnhin/domains/viptamnhinviet.com/public_html/index.php'),
('171.243.169.111', 1321877321, '/home/viptamnhin/domains/viptamnhinviet.com/public_html/index.php'),
('171.243.224.75', 1321844701, '/home/viptamnhin/domains/viptamnhinviet.com/public_html/index.php'),
('171.245.62.16', 1321843216, '/home/viptamnhin/domains/viptamnhinviet.com/public_html/index.php'),
('183.80.0.250', 1321863578, '/home/viptamnhin/domains/viptamnhinviet.com/public_html/index.php'),
('183.80.192.125', 1321863481, '/home/viptamnhin/domains/viptamnhinviet.com/public_html/index.php'),
('203.210.239.119', 1321867605, '/home/viptamnhin/domains/viptamnhinviet.com/public_html/index.php'),
('27.74.34.241', 1321856837, '/home/viptamnhin/domains/viptamnhinviet.com/public_html/index.php'),
('42.119.150.199', 1321883430, '/home/viptamnhin/domains/viptamnhinviet.com/public_html/index.php'),
('42.119.208.40', 1321847637, '/home/viptamnhin/domains/viptamnhinviet.com/public_html/index.php'),
('42.119.228.177', 1321852480, '/home/viptamnhin/domains/viptamnhinviet.com/public_html/index.php'),
('42.119.228.78', 1321871475, '/home/viptamnhin/domains/viptamnhinviet.com/public_html/index.php'),
('42.119.241.7', 1321842407, '/home/viptamnhin/domains/viptamnhinviet.com/public_html/index.php'),
('42.119.246.131', 1321883925, '/home/viptamnhin/domains/viptamnhinviet.com/public_html/index.php'),
('42.119.61.175', 1321879647, '/home/viptamnhin/domains/viptamnhinviet.com/public_html/index.php'),
('42.119.63.88', 1321849604, '/home/viptamnhin/domains/viptamnhinviet.com/public_html/index.php'),
('64.233.182.84', 1321841055, '/home/viptamnhin/domains/viptamnhinviet.com/public_html/index.php'),
('64.233.182.85', 1321841052, '/home/viptamnhin/domains/viptamnhinviet.com/public_html/index.php'),
('66.249.68.21', 1321914998, '/home/viptamnhin/domains/viptamnhinviet.com/public_html/index.php'),
('66.249.69.156', 1321914465, '/home/viptamnhin/domains/viptamnhinviet.com/public_html/index.php'),
('72.14.202.81', 1321841052, '/home/viptamnhin/domains/viptamnhinviet.com/public_html/index.php'),
('72.14.202.87', 1321841065, '/home/viptamnhin/domains/viptamnhinviet.com/public_html/index.php'),
('72.14.202.90', 1321841064, '/home/viptamnhin/domains/viptamnhinviet.com/public_html/index.php'),
('72.14.202.91', 1321841059, '/home/viptamnhin/domains/viptamnhinviet.com/public_html/index.php');

-- --------------------------------------------------------

--
-- Table structure for table `dos_sys_seos`
--

CREATE TABLE IF NOT EXISTS `dos_sys_seos` (
  `seo_name` varchar(45) NOT NULL,
  `seo_content` text NOT NULL,
  PRIMARY KEY  (`seo_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `dos_sys_seos`
--

INSERT INTO `dos_sys_seos` (`seo_name`, `seo_content`) VALUES
('google_analytic', '<script type="text/javascript">\r\n\r\n  var _gaq = _gaq || [];\r\n  _gaq.push([''_setAccount'', ''UA-25177991-7'']);\r\n  _gaq.push([''_trackPageview'']);\r\n\r\n  (function() {\r\n    var ga = document.createElement(''script''); ga.type = ''text/javascript''; ga.async = true;\r\n    ga.src = (''https:'' == document.location.protocol ? ''https://ssl'' : ''http://www'') + ''.google-analytics.com/ga.js'';\r\n    var s = document.getElementsByTagName(''script'')[0]; s.parentNode.insertBefore(ga, s);\r\n  })();\r\n\r\n</script>');

-- --------------------------------------------------------

--
-- Table structure for table `dos_sys_users`
--

CREATE TABLE IF NOT EXISTS `dos_sys_users` (
  `username` varchar(45) NOT NULL default '',
  `create_date` timestamp NOT NULL default CURRENT_TIMESTAMP,
  `email` varchar(45) NOT NULL,
  `password` varchar(45) NOT NULL,
  `full_name` varchar(150) NOT NULL,
  `birthday` date default NULL,
  `address` varchar(200) default NULL,
  `cmnd` varchar(10) default NULL,
  `phone` varchar(15) default NULL,
  `bank_number` varchar(20) default NULL,
  `bank_name` varchar(100) default NULL,
  `user_gioithieu` varchar(45) NOT NULL,
  `user_baotro` varchar(45) NOT NULL,
  `user_quanly` text NOT NULL,
  `balance` varchar(45) NOT NULL default '0',
  `user_group` varchar(45) NOT NULL,
  `forgot_code` varchar(8) default NULL,
  `enable` tinyint(1) NOT NULL,
  `actived` tinyint(4) NOT NULL default '0',
  PRIMARY KEY  (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `dos_sys_users`
--

INSERT INTO `dos_sys_users` (`username`, `create_date`, `email`, `password`, `full_name`, `birthday`, `address`, `cmnd`, `phone`, `bank_number`, `bank_name`, `user_gioithieu`, `user_baotro`, `user_quanly`, `balance`, `user_group`, `forgot_code`, `enable`, `actived`) VALUES
('baoduy', '2011-11-19 13:42:48', 'phamthaibaoduy@gmail.com', 'e10adc3949ba59abbe56e057f20f883e', 'PHẠM THÁI BẢO DUY', '1992-09-29', '14/22 KHU PHỐ 4, HỐ NAI, BIÊN HÒA, ĐỒNG NAI', '272334613', '0908273266', '0121000634147', 'vietcombank chi nhánh đồng nai', 'viptamnhinviet', 'trieuphu', '', '0', 'user', NULL, 1, 1),
('dailybienhoa', '2011-11-20 09:51:54', 'linhlantrang_2305@yahoo.com', 'e47a17973a71bce96935d04545896cfa', 'ĐẶNG THỊ MỸ LINH', '1987-05-23', '12a/46.kp7.ho nai1.bien hoa.dong nai', '271913175', '01276844376', '0121000591306', 'vietcombank', 'viptamnhinviet', 'thienly', '', '0', 'user', NULL, 1, 1),
('daominhduc', '2011-11-20 09:42:11', 'minhduc@gmail.com', 'e10adc3949ba59abbe56e057f20f883e', 'ĐÀO MINH ĐỨC', '1990-09-18', 'yen hung, y yen, nam dinh', '163119201', '01659294138', '0121002243291', 'vietcombank', 'viptamnhinviet', 'quangvinh', '', '0', 'user', NULL, 1, 1),
('dongvu', '2011-11-20 10:05:09', 'vubachdong@gmail.com', '987974f9966d946d296df8684dd7371c', 'BẠCH ĐÔNG VŨ', '1978-01-28', 'kp1, tan nghia, ham tan, binh thuan', '260925549', '0907736241', '0621000392732', 'vietcombank', 'viptamnhinviet', 'vietuc', '', '0', 'user', NULL, 1, 1),
('grouplaptrinh', '0000-00-00 00:00:00', 'info@grouplaptrinh.com', 'b7a659e0c28c88b3ee01adf805fc228f', 'GroupLapTrinh', NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '0', 'administrator', NULL, 1, 1),
('hoinhapwto', '2011-11-20 09:09:18', 'aduonghoan24@gmaill.com', 'e10adc3949ba59abbe56e057f20f883e', 'NGUYỄN ĐẠI DƯƠNG', '1983-03-24', 'd5  khu pho4 ,tan hiep,bien hoa ,dong nai', '272449921', '01234811511', '67010000549075', 'bidv dong nai', 'viptamnhinviet', 'trieuphu', '', '0', 'user', NULL, 1, 1),
('maiphuoc', '2011-11-20 09:28:47', 'maiphuoccomputer@gmail.com', 'e10adc3949ba59abbe56e057f20f883e', 'MAI VĂN PHƯỚC', '1985-10-17', 'phu long, tuong linh, nong cong, thanh hoa', '172601136', '0902060825', '0291000430038', 'vietcombank gia lai', 'viptamnhinviet', 'hoinhapwto', '', '0', 'user', NULL, 1, 1),
('ngocngoc', '2011-11-19 15:08:25', 'huongnguyenbhip@gmail.com', 'e10adc3949ba59abbe56e057f20f883e', 'NGUYỄN THỊ HƯƠNG', '1954-04-23', 'lô A12.1 c/c trần quang diệu ,phường 13,q3,tp HCM', '020265348', '0907938981', '0071003791748', 'vietcombank', 'phuongquynh', 'phuckim', '', '0', 'user', NULL, 1, 1),
('phuckim', '2011-11-19 14:59:06', 'phuckim@gmail.com', '25f9e794323b453885f5181f1b624d0b', 'MÀN CHÁNH PHÚC', '1984-06-17', 'BẢO BÌNH, XUÂN LỘC, ĐỒNG NAI', '271614522', '0937395779', '14022729974011', 'techcombank', 'phuongquynh', 'phuongquynh', '', '0', 'user', NULL, 1, 1),
('phuongquynh', '2011-11-19 12:32:16', 'dinhquochuan1@gmail.com', 'e10adc3949ba59abbe56e057f20f883e', 'ĐINH QUỐC HUÂN', '1985-02-14', '91/108/30 KHU PHỐ 3, PHƯỜNG TÂN PHONG, BIÊN HÒA, ĐỒNG NAI', '271743118', '0902349839', '0621003809069', 'vietcombank', 'viptamnhinviet', 'typhu', '', '800', 'user', NULL, 1, 1),
('quangvinh', '2011-11-20 09:23:40', 'dovinh@gmail.com', '7b137f25fd27e325e2a53031d54b6b46', 'ĐỖ VĂN VINH', '1986-09-06', 'tuong son, nong cong, thanh hoa', '172633562', '0918019378', '711a43517724', 'viettinbank', 'viptamnhinviet', 'hoinhapwto', '', '0', 'user', NULL, 1, 1),
('thanhdat', '2011-11-20 09:02:22', 'vangioi_52@yahoo.com', '1aaef62d375a4e39bbf7799ab96e1a5d', 'HÀ VĂN GIỎI', '1953-01-01', 'thành phố hồ chí minh', '350686504', '01655298569', '0071000632989', 'vietcombank', 'viptamnhinviet', 'baoduy', '', '0', 'user', NULL, 1, 1),
('thanhduyen', '2011-11-20 09:59:05', 'meocon_2812@yahoo.com', 'e75dfbd8535ac02d9e89685b27e621f2', 'NGUYỄN THANH DUYÊN', '1987-12-28', '110/6a tổ 22,kp2 ,p long binh, bien hoa , dong nai', '271911790', '0982220390', '0481000641419', 'vc bank', 'viptamnhinviet', 'dailybienhoa', '', '0', 'user', NULL, 1, 1),
('thanhphat', '2011-11-19 12:24:36', 'thanhdanhmedical@yahoo.com.vn', 'e10adc3949ba59abbe56e057f20f883e', 'NGUYỄN THÀNH DANH', '1986-10-10', '13A/768 ấp vàm, thiên tân, vĩnh cửu, đồng nai', '271827629', '0919963819', '11923548938018', 'techcombank', 'viptamnhinviet', 'typhu', '', '0', 'user', NULL, 1, 1),
('thienly', '2011-11-20 09:46:48', 'thienly@gmail.com', 'e10adc3949ba59abbe56e057f20f883e', 'VŨ THỊ LÝ', '1991-06-04', 'ea sup, huyen ea sup, tinh dac lac', '241194830', '01688035229', '0121002243291', 'vietcombank', 'viptamnhinviet', 'daominhduc', '', '0', 'user', NULL, 1, 1),
('tranlinhlongthanh', '2011-11-20 10:48:21', 'trungnam_nguyen9@yahoo.com', '020f5665674491abb3978598bd0ec647', 'TRẦN NGỌC LINH', '1979-04-01', 'TỔ 5, CẨM ĐƯỜNG, LONG THÀNH, ĐỒNG NAI', '271382962', '0919894221', '0621000392732', 'vietcombank', 'viptamnhinviet', 'dongvu', '', '0', 'user', NULL, 1, 1),
('trieuphu', '2011-11-19 12:18:12', 'hoangnguyenspa@gmail.com', 'e10adc3949ba59abbe56e057f20f883e', 'HOÀNG QUỐC TRƯỞNG', '1982-10-08', '14B/86 khu phố 7, hố nai bien hòa, đồng nai', '031250554', '0933889357', '0621003861090', 'công thương phan thiết', 'viptamnhinviet', 'viptamnhinviet', '', '0', 'user', NULL, 1, 1),
('typhu', '2011-11-19 11:26:53', 'trungnam_nguyen9@yahoo.com', 'c0679872bdb03f7e157d4432c6f417bc', 'nguyen trung nam', '1983-06-01', 'tho loc, xuan tho, xuan loc, dong nai', '271520331', '0987976879', '0181001497227', 'vietcombank', 'viptamnhinviet', 'viptamnhinviet', '', '400', 'user', NULL, 1, 1),
('vietuc', '2011-11-20 09:15:43', 'dangnhankitchen@yahoo.com', 'f7e47deccf3a607845ae1325e8cd0424', 'ĐẶNG ĐÌNH NHÂN', '1984-04-24', 'ấp g2, xã thanh an ,huyện vịnh thanh,tp cần thơ', '361972542', '0903949986', '0103785438', 'ngan hang dong a', 'viptamnhinviet', 'thanhphat', '', '0', 'user', NULL, 1, 1),
('viptamnhinviet', '2011-11-15 06:51:58', 'info@viptamnhinviet.com', '17ad49a172f0f6e36d298adb816dacf4', 'Tầm nhìn Việt', NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '6800', 'member', NULL, 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `dos_sys_webs`
--

CREATE TABLE IF NOT EXISTS `dos_sys_webs` (
  `web_name` varchar(45) NOT NULL,
  `web_value` varchar(200) NOT NULL,
  PRIMARY KEY  (`web_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `dos_sys_webs`
--

INSERT INTO `dos_sys_webs` (`web_name`, `web_value`) VALUES
('admin_email', 'trungnam_nguyen69@yahoo.com'),
('admin_name', 'Nguyen Trung Nam'),
('description', 'Viptamnhinviet.com'),
('email_subject', 'Liên hệ từ website'),
('keywords', 'Viptamnhinviet.com'),
('titleweb', 'Viptamnhinviet.com'),
('type', '1');

--
-- Constraints for dumped tables
--

--
-- Constraints for table `dos_module_gallery`
--
ALTER TABLE `dos_module_gallery`
  ADD CONSTRAINT `fk_dos_module_gallery_dos_module_gallery_cat` FOREIGN KEY (`dos_module_gallery_cat_cat_id`) REFERENCES `dos_module_gallery_cat` (`cat_id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `dos_module_handbook`
--
ALTER TABLE `dos_module_handbook`
  ADD CONSTRAINT `fk_dos_module_handbook_dos_module_handbook_cat` FOREIGN KEY (`dos_module_handbook_cat_cat_id`) REFERENCES `dos_module_handbook_cat` (`cat_id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `dos_module_news`
--
ALTER TABLE `dos_module_news`
  ADD CONSTRAINT `fk_dos_module_news_dos_module_news_cat` FOREIGN KEY (`dos_module_news_cat_cat_id`) REFERENCES `dos_module_news_cat` (`cat_id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `dos_module_product`
--
ALTER TABLE `dos_module_product`
  ADD CONSTRAINT `fk_dos_module_product_dos_module_product_cat` FOREIGN KEY (`dos_module_product_cat_cat_id`) REFERENCES `dos_module_product_cat` (`cat_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_dos_module_product_dos_sys_users` FOREIGN KEY (`dos_sys_users_username`) REFERENCES `dos_sys_users` (`username`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `dos_module_studies`
--
ALTER TABLE `dos_module_studies`
  ADD CONSTRAINT `dos_module_studies_ibfk_1` FOREIGN KEY (`dos_module_studies_cat_cat_id`) REFERENCES `dos_module_studies_cat` (`cat_id`);

--
-- Constraints for table `dos_sys_groups_has_dos_sys_models`
--
ALTER TABLE `dos_sys_groups_has_dos_sys_models`
  ADD CONSTRAINT `dos_sys_groups_has_dos_sys_models_ibfk_1` FOREIGN KEY (`dos_sys_groups_group_name`) REFERENCES `dos_sys_groups` (`group_name`),
  ADD CONSTRAINT `dos_sys_groups_has_dos_sys_models_ibfk_2` FOREIGN KEY (`dos_sys_models_model_id`) REFERENCES `dos_sys_models` (`model_id`);
